<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>ProCash</title>
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico"/>

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="{{asset(activeTemplate(true) .'users/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset(activeTemplate(true) .'users/assets/css/plugins.css')}}" rel="stylesheet" type="text/css" />
   
    <!-- END GLOBAL MANDATORY STYLES -->
    <script src="{{asset(activeTemplate(true) .'users/assets/js/libs/jquery-3.1.1.min.js')}}"></script>
    <script src="{{asset(activeTemplate(true) .'users/bootstrap/js/popper.min.js')}}"></script>
    <script src="{{asset(activeTemplate(true) .'users/bootstrap/js/bootstrap.min.js')}}"></script>
</head>
     
    <link href="{{asset(activeTemplate(true) .'users/assets/css/loader.css')}}" rel="stylesheet" type="text/css" />
    <script src="{{asset(activeTemplate(true) .'users/assets/js/loader.js')}}"></script>
    <script>
        $(document).ready(function(){
            $(".dropdown, .dropdown-toggle").click();
        });
    </script>
<body class="alt-menu sidebar-noneoverflow">
@yield('panel')


<!-- @stack('script-lib') -->
<!-- Load toast -->
@include('partials.notify')

 <!-- @php echo twakchat() @endphp 
 @php echo googleAnalysis() @endphp
-->

@stack('script')
@stack('js')



    <!-- END GLOBAL MANDATORY SCRIPTS -->
  


</body>
</html>