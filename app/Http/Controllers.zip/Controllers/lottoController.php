<?php

namespace App\Http\Controllers;
use App\CompenstionPlan;
use App\GeneralSetting;
use App\NetworkContract;
use App\Product;
use App\Ticket;
use App\sorteo;
use App\Share;
use App\Buy_ticket;
use App\Trx;
use App\resul_loto;
use App\Auth;
use Carbon\Carbon;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;


class lottoController extends Controller
{
                    public function index()
                    {
                        $data['page_title'] = 'Lotto';
                        $sor = sorteo::orderBy('id', 'desc')->first();
                        $data['ticket'] = Buy_ticket::where('user_id',auth()->user()->id)->join('sorteos','buy_tickets.sorteo','sorteos.id')->select('buy_tickets.id', 'buy_tickets.cantidad', 'buy_tickets.id_tx',  'buy_tickets.price', 'buy_tickets.amount', 'buy_tickets.created_at', 'buy_tickets.status', 'sorteos.date as fecha_sorteo', 'buy_tickets.sorteo', 'sorteos.status as sorteo_status')->latest()->paginate(15);
                        $data['sorteo'] = $sor;
                        return view(activeTemplate() . 'user.lotto', $data);
                    }

                    public function valida_ticket(){
                        $sorteo = sorteo::where('status', '0')->first();
                        if($sorteo == null)
                        {
                           echo "error";
                        }else{
                           echo $sorteo->id;
                        }
                    }

                    public function participa(){
                        $sorteo = sorteo::where('status',0)->first();   
                        $data['page_title'] = 'Lotto participants';
                        $data['sorteo'] = $sorteo;
                        $total = ticket::where('sorteo',$sorteo->id)->sum('price');
                        $repa = $this->totales($total);
                        $data['participantes']   = ticket::where('sorteo',$sorteo->id)->count();
                        $data['total']           = $repa['total'];
                        $data['fundacion']       = $repa['fundacion'];
                        $data['participa']       = ticket::where('sorteo',$sorteo->id)->paginate(25);
                        $data['mes']             = date('W', strtotime($sorteo->date));
                        $data['ano']             = date('y',strtotime($sorteo->date));
                        return view(activeTemplate() . 'user.lotto_participa', $data); 
                    }
                    

                    public function resultados_search(request $request){               
                         $user = $request->username;
                         $usua = User::where('username',$user)->first();
                         if($usua == null)
                         {
                            $notify[] = ['error', 'User invalid!'];
                            return back()->withNotify($notify);
                         }

                         $sorteo = sorteo::where('status',1)->latest()->first();   
                         $data['page_title'] = 'Winner Lotto Result';
                         $data['sorteo'] = $sorteo;
                         $total = ticket::where('sorteo',$sorteo->id)->sum('price');
                         $repa = $this->totales($total);
                         $data['participantes']   = ticket::where('sorteo',$sorteo->id)->count();
                         $data['total']           = $repa['total'];
                         $data['fundacion']       = $repa['fundacion'];
                         $data['participa']       = resul_loto::where('sorteo',$sorteo->id)->where('user_id',$usua->id)->paginate(33);
                         return view(activeTemplate() .'user.lotto_resu', $data);
                    }

                    public function resultados_lotto(){
                        $sorteo = sorteo::where('status',1)->latest()->first();   
                        $data['page_title'] = 'Winner Result';
                        $data['sorteo'] = $sorteo;
                        $total = ticket::where('sorteo',$sorteo->id)->sum('price');
                        $repa = $this->totales($total);
                        $data['participantes']   = ticket::where('sorteo',$sorteo->id)->count();
                        $data['total']           = $repa['total'];
                        $data['fundacion']       = $repa['fundacion'];
                        $data['participa']       = resul_loto::where('sorteo',$sorteo->id)->paginate(33);
                        return view(activeTemplate() .'user.lotto_resu', $data);
                    }

             /* compra de ticket */       
                    public function buy(request $request){
                        $this->validate($request, [
                                'share' => 'required|integer|min:1'
                        ]);

                        $user = Auth()->User();

                        $sorteo = sorteo::where('status', '0')->where('secuencia','1')->first();
                        if($sorteo == null)
                        {
                            $notify[] = ['error', 'There are no draws'];
                            return back()->withNotify($notify);
                        }

                        $cant = $request->share;
                        $total = $cant * $sorteo->price;
                        
                        if($total > $user->balance_trx ){
                            $notify[] = ['error', 'insufficient balance'];
                            return back()->withNotify($notify);
                        } 


                        $user->balance_trx -= $total;
                        $user->save();

                        
                        $buy = new Buy_ticket();
                        $buy->user_id  = $user->id;
                        $buy->cantidad = $cant;
                        $buy->amount   = $total;
                        $buy->price    =  $sorteo->price;
                        $buy->sorteo   = $sorteo->id;
                        $buy->status   = 1;
                        $buy->moneda   = 2;
                        $buy->via      = 1;
                        $buy->id_tx    = '';
                        $buy->save();

                        
                        $sorteo->participantes += $buy->cantidad;
                        $sorteo->save(); 
                            
                            $user->transactions()->create([
                                    'trx' => getTrx(),
                                    'user_id' => $user->id,
                                    'amount' => 0,
                                    'main_amo' => 0,
                                    'amount_con' => $buy->amount,
                                    'main_amo_con' => $buy->amount,
                                    'balance' => $user->balance_trx,
                                    'title' =>  $buy->cantidad.' lotto Tickets Purchase ',
                                    'charge' => 0,
                                    'moneda' => $sorteo->moneda,
                                    'type' => 'ticket_buy'
                                ]); 
                            
                                for($i = 0; $i<$buy->cantidad; $i++)
                                {
                                        $tick = new Ticket();
                                        $tick->user_id =  $user->id;
                                        $tick->price =  $sorteo->price;
                                        $tick->sorteo = $sorteo->id;
                                        $tick->status = 0;
                                        $tick->id_tx = $buy->id_tx;
                                        $tick->save(); 
                                }
                            $details = $user->username . ' Buy ' . $buy->cantidad . ' lotto ticket.';
                                $refer = User::find($user->ref_id);
                        
                                if ($refer &&  $refer->account_type == 1 && $user->generate_com == 1) {
                                    if( $this->gana_ticket($refer) > 0)
                                    {
                                            $amount = ($buy->amount * 10) / 100;
                                            echo "<br> ============================ <br>";
                                            referralComission_compensation($user->id, formatter_money($amount), $details,2);
                                    }
                                } 

                        $notify[] = ['Success', 'Your Orden purcharse Lotto Success'];
                        return back()->withNotify($notify); 
                    }


    // fin de compra de ticket


                    public function cargar_ticket($numero){

                        $sorteo = sorteo::where('status', '0')->first();
                            for($i=0;$i<$numero;$i++){
                                $tick = new Ticket();
                                $tick->user_id =  $i;
                                $tick->price =  $sorteo->price;
                                $tick->sorteo = $sorteo->id;
                                $tick->status = 0;
                                $tick->id_tx = 'N/A';
                                $tick->save(); 
                            }
                    }

                    public function totales($total){
                        $primero               = ($total * 15) / 100;
                        $segundo               = ($total * 10) / 100;
                        $tercero               = ($total * 5) / 100;
                        $parte                 = ($total * 30) / 100;      
                        $gana                  = round($parte/30,2);
                        $solidario             = ($total * 15) / 100;
                        $procash               = ($total * 10) / 100;
                        $fundacion             = ($total * 5) / 100;
                        $bono_directo          = ($total * 10) / 100;
                        $data['total']         = $total;
                        $data['primero']        = $primero;
                        $data['segundo']       = $segundo;
                        $data['tercero']       = $tercero;
                        $data['total_2x']      = $parte;
                        $data['corto']         = $gana;
                        $data['solidario']     = $solidario;
                        $data['procash']       = $procash;
                        $data['fundacion']     = $fundacion;
                        return $data;
                }

                function gana_ticket($user){
                    $sort = sorteo::where('status',0)->first();
                    if($sort == null) 
                    return 0;
                    $tick = ticket::where('sorteo',$sort->id)->where('user_id',$user->id)->count();
                    if($tick <1 ) 
                    return 0;
                    else
                    return 1;
               }
  
}