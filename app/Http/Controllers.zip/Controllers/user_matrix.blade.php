
@extends(activeTemplate() .'layouts.app')


@push('css')
    <link href="{{asset(activeTemplate(true) .'users/css/tree.css')}}" rel="stylesheet">
@endpush


@section('content')
    <div class="row" style="margin-top:55px;">
       <div class="col-2 bg-primary"><h4></h4></div>
       <div class="col-2 bg-primary"><h4></h4></div>
       <div class="col-8">
          <div class="pull-right">
              <button class="btn btn-success floats" data-toggle="modal" data-target="#modal_participa" > Buy matrix</button>
          </div>  
       </div>
    </div>
      
    <div class="row zona_matriz">
                          
                         @foreach($los_plan as $valor)
                          <div class="col-2"> 
                              
                                @if($valor['cantidad'] > 0)
                                
                                  <a href='{{url("user/acceleration/matrix/s/$valor[id_plan]/0")}}'>
                                    @if($plan_matrix == $valor['id_plan'])
                                       <div style="border-color:#fff" class=" circulo text-primary bg-primary  text-center d-flex justify-content-center align-items-center">
                                    @else
                                    <div class=" circulo text-center d-flex justify-content-center align-items-center">
                                    @endif
                                    {{$valor['precio']}}</div>
                                    </a>
                                @else
                                 <div class=" circulo_ina text-center d-flex justify-content-center align-items-center"
                                    >{{$valor['precio']}}</div>
                                @endif 
                          </div>
                          
                          @endforeach
                    
        </div>

        <div class="body_matriz">
            
              <div class="row">
                    <div class="col-12 bor-matriz text-center   d-flex justify-content-center align-items-center">
                         <div class="item circulo2 tama1 text-center d-flex justify-content-center align-items-center">
                            @if ($matrix_ini != "")
                               <img src="{{url($imagen_ini)}}" style="width:auto">  
                            @endif
                         </div>
                    </div>
              </div>

              <div class="row">
                  <div class="col-6 bor-matriz text-center   d-flex justify-content-center align-items-center">
                        <div class="item circulo2 tama2 text-center   d-flex justify-content-center align-items-center">
                        @if($poci[1]['id_matrix'] != "")
                        
                             <img src="{{url($poci[1]['imagen'])}}" style="width:auto" 
                             data-toggle="tooltip" data-placement="bottom" title="{{$poci[1]['username']}}">  
                           
                        @endif
                        </div>
                  </div>
                  <div class="col-6 bor-matriz text-center   d-flex justify-content-center align-items-center">
                        <div class="item circulo2 tama2 text-center   d-flex justify-content-center align-items-center">
                        @if($poci[2]['id_matrix'] != "")
                           <img src="{{url($poci[2]['imagen'])}}" style="width:auto" 
                             data-toggle="tooltip" data-placement="bottom" title="{{$poci[2]['username']}}">
                        @endif
                        </div>
                  </div>
              </div>

              <div class="row">
                  <div class="col-3 bor-matriz text-center   d-flex justify-content-center align-items-center">
                         <div class="item circulo2 tama3 text-center d-flex justify-content-center align-items-center">
                         @if($poci[3]['id_matrix'] != "")
                           <img src="{{url($poci[3]['imagen'])}}" style="width:auto" 
                             data-toggle="tooltip" data-placement="bottom" title="{{$poci[2]['username']}}">
                            @endif
                         </div>
                  </div>
                  <div class="col-3 bor-matriz text-center   d-flex justify-content-center align-items-center">
                        <div class="item circulo2 tama3 text-center   d-flex justify-content-center align-items-center">
                        @if($poci[4]['id_matrix'] != "")
                             <img src="{{url($poci[4]['imagen'])}}" style="width:auto" 
                             data-toggle="tooltip" data-placement="bottom" title="{{$poci[3]['username']}}">
                        @endif
                        </div>
                  </div>
                  <div class="col-3 bor-matriz text-center   d-flex justify-content-center align-items-center">
                            <div class="item circulo2 tama3 text-center   d-flex justify-content-center align-items-center">
                            @if($poci[5]['id_matrix'] != "")
                                <img src="{{url($poci[5]['imagen'])}}" style="width:auto" 
                                data-toggle="tooltip" data-placement="bottom" title="{{$poci[4]['username']}}">
                            @endif
                            </div>
                  </div>
                  <div class="col-3 bor-matriz text-center   d-flex justify-content-center align-items-center">
                              <div class="item circulo2 tama3 text-center   d-flex justify-content-center align-items-center">
                              @if($poci[6]['id_matrix'] != "")
                                      <img src="{{url($poci[6]['imagen'])}}" style="width:auto" 
                                       data-toggle="tooltip" data-placement="bottom" title="{{$poci[5]['username']}}">
                              @endif
                             </div>
                  </div>
              </div>

        </div>


        <div class="row pie_matriz">
        <span class="separa"></span><span class="separa"></span><span class="separa"></span><span class="separa"></span>
           @foreach($lis_mat as $valor)

            <span class="circulo_pie text-center   d-flex justify-content-center align-items-center">
            <a href='{{url("user/acceleration/matrix/s/$plan_matrix/$valor[id_matrix]")}}' style="color:#fff">
            {{$valor['posi']}}
            </a>
                
            </span>
            <span class="separa"></span><span class="separa"></span><span class="separa"></span><span class="separa"></span><span class="separa"></span>
           @endforeach
        </div>

        <div class="modal fade" id="modal_participa" tabindex="-1" role="dialog"
                 aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel">Aceleration Matrix</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                    </div>
                                    <div class="modal-body">
                                      @foreach($plans as $data) 
                                            <div class="mat1">
                                                   <div class = "row">
                                                      <div class="col-9">
                                                                     <h4 style="margin-top:1px"> @lang($data->name) </h4>
                                                                     <p> {{formatter_money($data->price)+0}} {{$general->cur_text}} @lang('It is deducted from your Deposit Wallet.')</p>
                                                          </div>
                                                      <div class="col-3">
                                                      <form method="post" action="{{route('user.acceleration.matrix.store', $data->id)}}">
                                                        @csrf
                                                        <!-- <meta name="csrf-token" content="{{ csrf_token() }}"> -->
                                                         <button type="submit" name="plan_id" value="{{$data->id}}" class="btn btn-primary bold uppercase"> @lang('Buy Now')</button>
                                                      </form>
                                                      </div>
                                                    </div>
                                            </div>
                                      @endforeach
                                    </div>
                                </div>
                            </div>
                </div>

@endsection


@push('style')

@endpush

              

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js">
  </script>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
 <script>
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();
    })
 </script>       

<style>
.pull-right{
    width:124px;
}
.floats{
    margin-top:-80px;
    position:absolute; 
}
.plan_active{
    color: #036;
    font-size::55px;
}
.mat1{
       padding:10px;
       margin-top:5px;
       border:1px solid #c9c9c9;
}


.separa{
    width:3px;
}
      .pie_matriz{
          margin-left:25px;
        margin-top:10px;

      }
      .body_matriz{
            margin-top:10px;

      }
      .bor-matriz{
          margin:0;
          padding: 10px;
          padding: 10 px;
          border:1px solid #f1f1f1;
      }
      
      .tama1{
        width: 100px;
            height: 100px;
      }
      .tama2{
            width: 80px;
            height: 80px;
     }
      .tama3{
        width: 70px;
            height: 70px;
    }

    .circulo2{
            font-weight:600;
            font-size:18px;
            -moz-border-radius: 50%;
            -webkit-border-radius: 50%;
            border-radius: 50%;
            background:#c9c9c9;
            margin-right:5px;      
            cursor:pointer;     
      }
     
     .circulo_pie{
        width: 25px;
        height: 25px;
        color:#fff;
        font-weight:600;
        font-size:14px;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        border:1px solid;
        border-radius: 50%;
        background: #036;
        cursor:pointer;
     }

     .circulo {
     width: 50px;
     height: 50px;
     color:#fff;
     font-weight:600;
     font-size:18px;
     -moz-border-radius: 50%;
     -webkit-border-radius: 50%;
     border-radius: 50%;
     border:1px solid;
     border-color:#036;
     background:#5798d1;
     cursor:pointer;
      }

      .circulo_activo {
     width: 50px;
     height: 50px;
     color:#fff;
     font-weight:600;
     font-size:18px;
     -moz-border-radius: 50%;
     -webkit-border-radius: 50%;
     border-radius: 50%;
     border:1px solid;
     border-color:#036;
     background:#;
     cursor:pointer;
      }

      .circulo_ina {
     width: 50px;
     height: 50px;
     color:#fff;
     font-weight:600;
     font-size:18px;
     -moz-border-radius: 50%;
     -webkit-border-radius: 50%;
     border-radius: 50%;
     border:1px solid;
     border-color:#036;
     background:#c9c9c9;
     
      }
      .circulo:hover, .circulo_pie:hover{
           border-color:#c9c9c9;
      }

      .zona_matriz{
          padding-top:10px;
          padding-bottom:10px;
      }
</style>





  