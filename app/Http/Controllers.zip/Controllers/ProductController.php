<?php

namespace App\Http\Controllers;

use App\CompenstionPlan;
use App\GeneralSetting;
use App\NetworkContract;
use App\Product;
use App\super_vip;
use App\Share;
use App\Trx;
use App\Deposit;
use App\auth;
use App\sorteo;
use App\Buy_ticket;
use App\GatewayCurrency;
use Carbon\Carbon;
use App\MatrixSubscriber;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $data['page_title'] = 'Products';
        $data['products'] = Product::where('status', 1)->get();
        return view(activeTemplate() . 'user.product', $data);
    }

    public function pay_trx(Request $request){
        session_start();
        $_SESSION['total_comprado'] = $request->shares;
        return;

       /*  
                $product = networkContract::where('moneda',2)->first();
                $data['page_title'] = 'Contracts TRX';
                $data['shares'] = Share::where('user_id', auth()->id())->where('moneda',2)->with('product')->latest()->paginate(config('constants.table.default'));
                $data['total_contra'] = Share::where('user_id', auth()->id())->where('type',1)->count();
                $data['pay_shares'] =  $total_price = round($product->price * $request->share, 8);
                $data['n_shares'] = $request->share;
            // return view(activeTemplate() . 'user.sharetrx', $data);
       */

    }

       // inicia aqui
    
    public function promocion($precio, $user){
         if($user->sen_cupon == 2)
         {
            $precio = $precio - ($precio * 5) / 100;
         }
         return $precio;
    }

    public function desact_promo($user){
        if($user->sen_cupon == 2)
        {
           $user->codigo_cupon = '';
           $user->sen_cupon = 3;
           $user->save();
        }
    }

    public function act_promocion(Request $request){
         
        $codigo = $request->codigo;
        $user = auth()->user();

        if($user->sen_cupon > 1)
        {    
            $notify[] = ['error', 'You do not have a coupon for this process'];
            return back()->withNotify($notify);
        }

        if($codigo == $user->codigo_cupon)
        {
            $user->sen_cupon = 2;
            $user->save();
            $notify[] = ['success', 'Your coupon has been activated'];
            return back()->withNotify($notify);
        }else{
            $notify[] = ['error', 'Invalid coupon code'];
            return back()->withNotify($notify);
        }
    
    }

    public function buy_trx(Request $request)
    {             
                    session_start();
                    $this->validate($request, [
                        'share' => 'required|integer|min:1',
                    ]);
                
                    $user = auth()->user();
                    $product = Product::where('moneda',2)->first();
                    
                    $precio_paq = $product->price;
                    
                    $total_price = number_format($precio_paq * $request->share, 8,'.','');
                    
                    $ab_share = $product->total_share - $product->total_sell;
                    
                    if($precio_paq > $user->balance_trx){
                        $notify[] = ['error', 'insufficient balance'];
                        return back()->withNotify($notify);
                    }
                    
                    if($total_price > $user->balance_trx){
                        $notify[] = ['error', 'insufficient balance'];
                        return back()->withNotify($notify);
                    }

                    if ($ab_share < $request->share) {
                        $notify[] = ['error', 'Available Contracts = ' . $ab_share];
                        return back()->withNotify($notify);
                    }

                    
                    $gnl = GeneralSetting::first();                
                    $max_earning = $total_price * $product->max_profit / 100;
                    $shar = new  Share();
                    $shar->user_id =  $user->id;
                    $shar->product_id = $product->id;
                    $shar->total_share = $request->share;
                    $shar->amount = $total_price;
                    $shar->max_earning = $max_earning;
                    $shar->status = 1;
                    $shar->start_date = Carbon::now()->addDays($product->pool_after);
                    $shar->moneda = $product->moneda;
                    $shar->act = 1;
                    $shar->save();

                    $share = $request->share;
                    $total_price = $total_price;
                    $user->balance_trx -= $total_price;
                    $user->shares_trx += $share;
                    $user->total_invest_trx += $total_price;     
                    $user->save();

                    $product->total_sell += $share;
                    $product->save();
            
            
                $user->transactions()->create([
                            'trx' => getTrx(),
                            'user_id' => $user->id,
                            'amount' => trontoether($total_price),
                            'main_amo' => trontoether($total_price),
                            'amount_con' => $total_price,
                            'main_amo_con' => $total_price,
                            'balance' => $user->balance_trx,
                            'title' => $share . ' Contract Purchase TRX',
                            'charge' => 0,
                            'moneda' => $product->moneda,
                            'type' => 'sharetrx_buy',
                        ]);  
                  
                    $current_rank = CompenstionPlan::where('min_share', '<=', $share)->where('max_share', '>=', $share)->first();
                    if ($current_rank == null) {
                        $current_rank = CompenstionPlan::where('max_share', '<=', $share)->orderBy('max_share', 'desc')->first();
                    }
                    $details = $user->username . ' Buy ' . $share . ' Contracts TRX.';
                  
                    if ($current_rank) {
            
                        $refer = User::find($user->ref_id);
            
                        if ($refer && $current_rank->ref_bonus > 0 && $refer->account_type == 1 && $user->generate_com == 1) {
                            $amount = ($total_price * $current_rank->ref_bonus) / 100;
                           referralComission_compensation($user->id, formatter_money($amount), $details,2);
                        }
                    }
                          
                    if ($user->generate_com == 1) {
                        $puntos = get_punto_trx($total_price);
                        updateBV($user->id, $puntos , $details);
                    }
            
                    $notify[] = ['success', 'You have purchase Contracts Successfully'];
                    return back()->withNotify($notify);
    }


    public function reparar(Request $request){
         
      $mi_co = 'TCiH3xu1kcUcT2ycc3JZF9SwmxqaPf9whh';
        $this->validate($request, [
            'hash' => 'required',
            'tipo' => 'required'
        ]);
       
        $hash = $request->hash;
        $shares = $request->share;
        $tipo = $request->tipo;
       
        // validamos que no este registrado en la base de datos
    
            $cant_d = Deposit::where('id_tx',$hash)->count();
            $cant_s = Share::where('id_tx',$hash)->count();
            $cant_t = buy_ticket::where('id_tx',$hash)->count();
            $cant = $cant_d + $cant_s+ $cant_t;

        if($cant>0) 
        { 
            $notify[] = ['error', 'Hash already registered'];  
            return back()->withNotify($notify); 
        }
                          $product = product::where('moneda',2)->first();
                          $vip     = networkcontract::where('moneda',2)->first();
                          $user    = User::where('id', auth()->id())->first();
                          $sorteo  = sorteo::where('status',0)->first();

                try{
                            $res =   file_get_contents("https://api.trongrid.io/v1/transactions/".$hash."/events");
                            $res =json_decode($res);
                            if(@$res->data[0])
                            {
                                 $total = $this->contar($res->data[0]);
                                        if($total == 9)
                                        {
                                            $data = $res->data[0];   
                                            $contracto = $data->contract_address;
                                            $contr_user = $data->result->user;
                                            $contr_status = $res->success;         
                                            $fecha = $data->block_timestamp / 1000;
                                            $fecha_pago = date('Y-m-d', $fecha);
                                            $fechaActual = Carbon::now();
                                            $diferencia = $fechaActual->diffInDays($fecha_pago);

                                        
                                            if($contracto  == $mi_co)
                                                        {
                                                               if(trim($contr_user) == trim($user->username)){
                                                                    $monto = $data->result->monto/1000000;
                                                                    if($diferencia < 11){
                                                                          
                                                                             switch($tipo){
                                                                                     case 1: 
                                                                                        $this->validate($request, [
                                                                                            'share' => 'required|integer|min:1'
                                                                                        ]);
                                                                                                 $cant_p = $monto /  $product->price; 
                                                                                                 if($cant_p == $shares){
                                                                                                        $this->act_buy($shares,$hash,$user->id); 
                                                                                                        $notify[] = ['success', 'You have purchase Contracts Successfully'];
                                                                                                        return back()->withNotify($notify); 
                                                                                                 }else{
                                                                                                    $notify[] = ['error', 'Contracts no Match es aqui!!'];  return back()->withNotify($notify);
                                                                                                }
                                                                                     break;

                                                                                     case 2:   
                                                                                                $this->validate($request, [
                                                                                                    'share' => 'required|integer|min:1'
                                                                                                ]);

                                                                                                $cant_p = $monto /  $vip->price;

                                                                                                if($cant_p == $shares){
                                                                                                       $this->act_vip($shares,$hash,$user->id); 
                                                                                                        $notify[] = ['success', 'You have purchase Contracts Successfully'];
                                                                                                        return back()->withNotify($notify);  
                                                                                                }else{
                                                                                                    $notify[] = ['error', 'Contracts no Match vip!!'];   return back()->withNotify($notify);    
                                                                                                }
                                                        
                                                                                    break;

                                                                                    case 3 :
                                                                                               $this->act_deposit($monto,$hash);

                                                                                               $notify[] = ['success', 'DEPOSIT SECCESS'];
                                                                                               back()->withNotify($notify);
                                                                                    break;

                                                                                    case 4 :
                                                                                        $cant_p = $monto /  $sorteo->price;
                                                                                        if($cant_p == $shares){
                                                                                             
                                                                                                 $this->act_lotto($shares,$hash,$user->id); 
                                                                                                 $notify[] = ['success', 'You have purchase Contracts Successfully'];
                                                                                                 return back()->withNotify($notify);  
                                                                                         }else{
                                                                                             $notify[] = ['error', 'Ticktes no Match!!'];   return back()->withNotify($notify);    
                                                                                         }
                                                                                    
                                                                                     
                                                                                    break;
                                                                            }
                                                                        
                                                                    }else{
                                                                        $notify[] = ['error', 'the date of This Hash if too old !!']; return back()->withNotify($notify); 
                                                                    }

                                                               }else{
                                                                $notify[] = ['error', 'Users no Match!!']; return back()->withNotify($notify); 
                                                               }
                                                        }else{
                                                            $notify[] = ['error', 'Contract Invalid'];   return back()->withNotify($notify); 
                                                        }

                                        }else{
                                          
                                           
                                        }
                            }else{
                                $notify[] = ['error', 'Hash Invalid'];   return back()->withNotify($notify); 
                            }
                    }
                    catch(Exception $e){
                        $notify[] = ['error', 'Hash Invalid'];   return back()->withNotify($notify); 
                    }
    }
    

    public function act_deposit($amount, $id_tx){
               
      
            $amount = trontoether($amount);

            $method_code = 506;
            $currency = 'TRX';
                $gate = GatewayCurrency::where('method_code', $method_code)->where('currency', $currency)->first();
                  
              

                $charge = formatter_money($gate->fixed_charge + ($amount * $gate->percent_charge / 100));
                $withCharge = $amount - $charge;
                $final_amo = formatter_money($withCharge * $gate->rate);
                

                    
                $trx_n= getTrx();
                $depo = new Deposit();
                $depo['user_id'] = auth()->id();
                $depo['method_code'] = $gate->method_code;
                $depo['method_currency'] = strtoupper($currency);
                $depo['amount'] = formatter_money($amount);
                $depo['charge'] = $charge;
                $depo['rate'] = $gate->rate;
                $depo['final_amo'] = $final_amo;
                $depo['btc_amo'] = 0;
                $depo['btc_wallet'] = "";
                $depo['trx'] = $trx_n;
                $depo['id_tx'] = $id_tx;
                $depo['try'] = 0;
                $depo['status'] = 0;
                $depo->save();
            

               // print_r(json_decode($depo));
        
    }

    public function act_vip($shares, $id_tx,$user){
                 
                $network_contract = NetworkContract::where('moneda',2)->first();
                $total_price = round($network_contract->price * $shares, 8);

                $ab_share = $network_contract->total_contract - $network_contract->total_sell;
                if ($ab_share < $shares) {
                    $notify[] = ['error', 'Available Network Contract = ' . $ab_share];
                    return back()->withNotify($notify);
                }
            
                $max_earning = $total_price * $network_contract->max_profit / 100;

                $share = new  Share();
                $share->user_id = $user;
                $share->product_id = 0;
                $share->total_share = $shares;
                $share->amount = $total_price;
                $share->max_earning = $max_earning;
                $share->moneda = $network_contract->moneda;
                $share->status = 0;
                $share->id_tx  = $id_tx;
                $share->act = 0;
                $share->type = 0;
                $share->save();
    }

    public function act_buy($shares, $id_tx,$user){
        $product = Product::where('moneda',2)->first();
        $total_price = round($product->price * $shares, 8);
        $ab_share = $product->total_share - $product->total_sell;

        if ($ab_share < $shares) {
            $notify[] = ['error', 'Available Contracts = ' . $ab_share];
            return back()->withNotify($notify);
        }
        $gnl = GeneralSetting::first();                
        $max_earning = $total_price * $product->max_profit / 100;
      
        $share = new  Share();
        $share->user_id = $user;
        $share->product_id = $product->id;
        $share->total_share = $shares;
        $share->amount = $total_price;
        $share->max_earning = $max_earning;
        $share->status = 0;
        $share->start_date = Carbon::now()->addDays($product->pool_after);
        $share->moneda = $product->moneda;
        $share->id_tx  = $id_tx;
        $share->act = 0; 
        $share->save();
    }

    public function act_lotto($cant,$hash,$user){

        $sorteo = sorteo::where('status', '0')->first();
        if($sorteo == null)
        {
            $notify[] = ['error', 'There are no draws'];
            return back()->withNotify($notify);
        }

        $cant = $cant;
        $total = $cant * $sorteo->price;
        
        $buy = new Buy_ticket();
        $buy->user_id  = $user;
        $buy->cantidad = $cant;
        $buy->amount   = $total;
        $buy->price    =  $sorteo->price;
        $buy->sorteo   = $sorteo->id;
        $buy->status   = 0;
        $buy->moneda   = 2;
        $buy->via      = 1;
        $buy->id_tx    = $hash;
        $buy->save();

    }
    
    // fin aqui
             
    function contar($obj){
        $i=0;
        foreach($obj as $value){
            $i++;
        }
        return $i;
    }

    public function buy(Request $request)
    {

        $this->validate($request, [
            'share' => 'required|integer|min:1',
        ]);

        $product = Product::first();
        
        $precio_paq = $product->price;

        $total_price = round($precio_paq * $request->share, 8);
        $ubal = round(auth()->user()->balance, 8);


        if ($total_price > $ubal) {
            $notify[] = ['error', 'Insufficient balance, Please deposit first'];
            return redirect()->route('user.wallets.index')->withNotify($notify);
        }

        $ab_share = $product->total_share - $product->total_sell;
        if ($ab_share < $request->share) {
            $notify[] = ['error', 'Available Contracts = ' . $ab_share];
            return back()->withNotify($notify);
        }

        $user = auth()->user();
        $user->balance -= $total_price;
        $user->shares += $request->share;
        $user->total_invest += $total_price;
        $user->save();

        $gnl = GeneralSetting::first();

        if (auth()->user()->account_type == 1) {
            $max_earning = $total_price * $gnl->max_profit / 100;
        } elseif (auth()->user()->account_type == 2) {
            $max_earning = $total_price * $gnl->investor_max_profit / 100;
        }

        $share = new  Share();
        $share->user_id = auth()->id();
        $share->product_id = $product->id;
        $share->total_share = $request->share;
        $share->amount = $total_price;
        $share->max_earning = $max_earning;
        $share->start_date = Carbon::now()->addDays($gnl->pool_start);
        $share->status = 1;
        $share->save();

        $product->total_sell += $request->share;
        $product->save();

        $user->transactions()->create([
            'trx' => getTrx(),
            'user_id' => $user->id,
            'amount' => $total_price,
            'main_amo' => $total_price,
            'balance' => $user->balance,
            'title' => $request->share . ' Contract  Purchase ETH',
            'charge' => 0,
            'type' => 'share_buy',
        ]);


        $current_rank = CompenstionPlan::where('min_share', '<=', $request->share)->where('max_share', '>=', $request->share)->first();

        if ($current_rank == null) {
            $current_rank = CompenstionPlan::where('max_share', '<=', $request->share)->orderBy('max_share', 'desc')->first();
        }

        $details = auth()->user()->username . ' Buy ' . $request->share . ' Contracts.';
        if ($current_rank) {
            $refer = User::find($user->ref_id);
//           account_type = 1, network account. only network account get  referral Commission;
            if ($refer && $current_rank->ref_bonus > 0 && $refer->account_type == 1 && $user->generate_com == 1) {
                $amount = ($total_price * $current_rank->ref_bonus) / 100;
                referralComission_compensation($user->id, formatter_money($amount), $details);
            }
        }
        
        if ($user->generate_com == 1) {
              $puntos = get_punto_eth($total_price);
            updateBV($user->id, $puntos, $details);
        }
        $notify[] = ['success', 'You have purchase Contracts Successfully'];
        return back()->withNotify($notify);
    }

    public function shares()
    {
        $data['page_title'] = 'Contracts ETH';
        $data['shares'] = Share::where('user_id', auth()->id())->where('moneda',1)->with('product')->latest()->paginate(config('constants.table.default'));
        $data['total_contra'] = Share::where('user_id', auth()->id())->where('type',1)->count();
        $data['total_matrix'] = MatrixSubscriber::where('user_id', auth()->user()->id)->where('created_at','>','2021-01-21')->count();
        return view(activeTemplate() . 'user.share', $data);
    }

    public function sharestrx()
    {
        $data['page_title'] = 'Contracts TRX';
        $data['shares'] = Share::where('user_id', auth()->id())->where('moneda',2)->where('status',"<>",5)->with('product')->latest()->paginate(config('constants.table.default'));
        $data['total_contra'] = Share::where('user_id', auth()->id())->where('type',1)->count();
        $data['pay_shares'] = 0;
        $data['total_matrix'] = MatrixSubscriber::where('user_id', auth()->user()->id)->count();
        return view(activeTemplate() . 'user.sharetrx', $data);
    }
    
    public function networkContractsBuy(Request $request)
    {

        $this->validate($request, [
            'network_contract' => 'required|integer|min:1',
        ]);
        $network_contract = NetworkContract::first();
        $precio_paq = $network_contract->price;
     
        $total_price = round($precio_paq * $request->network_contract, 8);
        $ubal = round(auth()->user()->balance, 8);
        

        if ($total_price > $ubal) {
            $notify[] = ['error', 'Insufficient balance, Please deposit first'];
            return redirect()->route('user.wallets')->withNotify($notify);
        }


        $ab_share = $network_contract->total_contract - $network_contract->total_sell;
        if ($ab_share < $request->network_contract) {
            $notify[] = ['error', 'Available Network Contract = ' . $ab_share];
            return back()->withNotify($notify);
        }
        $user = auth()->user();
        $user->balance -= $total_price;
        $user->network_contracts += $request->network_contract;
        $user->total_invest += $total_price;
        $user->save();

        $max_earning = $total_price * $network_contract->max_profit / 100;

        $share = new  Share();
        $share->user_id = auth()->id();
        $share->product_id = 0;
        $share->total_share = $request->network_contract;
        $share->amount = $total_price;
        $share->max_earning = $max_earning;
        $share->status = 3;
        $share->type = 0;
        $share->save();

        $network_contract->total_sell += $request->network_contract;
        $network_contract->save();

        $user->transactions()->create([
            'trx' => getTrx(),
            'user_id' => $user->id,
            'amount' => $total_price,
            'main_amo' => $total_price,
            'balance' => $user->balance,
            'title' => $request->network_contract . ' VIP Contracts Purchase ETH',
            'charge' => 0,
            'type' => 'share_buy'
        ]);

        $details = auth()->user()->username . ' Buy ' . $request->network_contract . ' VIP Contracts.';
        $refer = User::find($user->ref_id);
        //account_type = 1, network account. only network account get  referral Commission;

        if ($refer && $refer->account_type == 1 && $user->generate_com == 1) {
            $amount = ($total_price * $network_contract->ref_bonus) / 100;
            referralComission_compensation($user->id, $amount, $details);
        }

        if ($user->generate_com == 1) {
            $puntos = $puntos = get_punto_eth($total_price);
            updateBV($user->id, $puntos, $details);
        }
        // $notify[] = ['success', 'You have purchase Contracts Successfully'];
        $notify[] = ['success', 'You have purchase Contracts Successfully'];

        return back()->withNotify($notify);
    }
    

        // parta tron

    public function superbuy_trx(Request $request){

                        session_start();
                        $id_tx =  $request->id_transaction_sup; 
                   
                        if($_SESSION['total_comprado'] != $request->super)
                        {
                             $notify[] = ['error', 'Error Contracts'];
                             return back()->withNotify($notify);
                        }
                    
                        $this->validate($request, [
                                            'super' => 'required|integer|min:1',
                        ]);
                        
                        $network_contract = super_vip::where('moneda',2)->first();

                        $total_price = round($network_contract->price * $request->super, 8);
                        
                        $ab_share = $network_contract->total_contract - $network_contract->total_sell;
                        if ($ab_share < $request->super) {
                                                $notify[] = ['error', 'Available Network Contract = ' . $ab_share];
                                                return back()->withNotify($notify);
                        }

                        $max_earning = $total_price * $network_contract->max_profit / 100;
                        $share = new  Share();
                        $share->user_id     = auth()->id();
                        $share->product_id  = 0;
                        $share->total_share = $request->super;
                        $share->amount      = $total_price;
                        $share->max_earning = $max_earning;
                        $share->moneda      = $network_contract->moneda;
                        $share->status      = 0;
                        $share->id_tx       = $id_tx;
                        $share->finish      = Carbon::now()->addDays($network_contract->day_venci);
                        $share->act         = 0;
                        $share->type        = 2;
                        $share->save();

                        $notify[] = ['success', 'You have purchase Contracts VIP Successfully'];
                        return back()->withNotify($notify);


    }



    public function networkContractsBuy_trx(Request $request)
    {
                        
                            $this->validate($request, [
                                'network_contract' => 'required|integer|min:1',
                            ]);

                            $user = auth()->user();
                            
                            $network_contract = NetworkContract::where('moneda',2)->first();

                            $precio_paq = $network_contract->price;
                            $precio_org = $precio_paq;
                            $precio_paq = $this->promocion($precio_paq, $user, '');

                            $total_price = round($precio_paq * $request->network_contract, 8);
                            
                            $ab_share = $network_contract->total_contract - $network_contract->total_sell;
                            if ($ab_share < $request->network_contract) {
                                $notify[] = ['error', 'Available Network Contract = ' . $ab_share];
                                return back()->withNotify($notify);
                            }
                             
                            $total_price_org = round($precio_org * $request->network_contract, 8);

                            if($total_price > $user->balance_trx)
                            {
                               $notify[] = ['error', 'insufficient balance'];
                               return back()->withNotify($notify);
                            }
                            
                            $this->desact_promo($user);
                        
                            $max_earning = $total_price_org * $network_contract->max_profit / 100;

                            $shar = new  Share();
                            $shar->user_id = $user->id;
                            $shar->product_id = 0;
                            $shar->total_share = $request->network_contract;
                            $shar->amount = $total_price_org;
                            $shar->max_earning = $max_earning;
                            $shar->moneda = $network_contract->moneda;
                            $shar->status = 3;
                            $shar->id_tx  = 0;
                            $shar->act = 1;
                            $shar->type = 0;
                            $shar->save();

                            $share = $request->network_contract;
                            
                            $user->balance_trx -= $total_price;
                            $user->network_contracts_trx += $share;
                            $user->total_invest_trx += $total_price;     
                            $user->save();
                    
                            $network_contract->total_sell += $share;
                            $network_contract->save();
                    

                            $user->transactions()->create([
                                'trx' => getTrx(),
                                'user_id' => $user->id,
                                'amount' => trontoether($total_price),
                                'main_amo' => trontoether($total_price),
                                'amount_con' => $total_price,
                                'main_amo_con' => $total_price,
                                'balance' => $user->balance_trx,
                                'title' => $share . ' VIP Contracts Purchase TRX',
                                'charge' => 0,
                                'moneda' => $network_contract->moneda,
                                'type' => 'sharetrx_buy',
                            ]); 
                           
                          
                            $refer = User::find($user->ref_id);
                            $details = $user->username . ' Buy ' . $share . ' VIP Contracts TRX.';
                             
                            if ($refer && $refer->account_type == 1 && $user->generate_com == 1) {
                                $amount = ($total_price * $network_contract->ref_bonus) / 100;
                                referralComission_compensation($user->id, $amount, $details,2);
                            }
                    
                            if ($user->generate_com == 1) {
                                $puntos = get_punto_trx($total_price);
                                updateBV($user->id, $puntos, $details);
                            }

                            $notify[] = ['success', 'You have purchase Contracts VIP Successfully'];
                            return back()->withNotify($notify);
                
     

    }


}
