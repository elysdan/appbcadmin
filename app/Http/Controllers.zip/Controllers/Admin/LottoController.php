<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Ticket;
use App\sorteo;
use App\User;
use App\Share;
use App\resul_loto;
use App\Buy_ticket;

class LottoController extends Controller
{
    public function Index()
    { 
        $page_title = 'Lotto - Sorteos';
        $empty_message = 'No Sorteos.';
        $usuario = "";
        $sorteos = sorteo::orderBy('id', 'DESC')->latest()->paginate(15);
        return view('admin.lotto.index', compact('page_title', 'empty_message', 'sorteos'));
    }
   

    public function create(request $request)
    { 
        $precio = $request->price;
        $fecha  = $request->fecha; 
        if($precio == ""  || $fecha == "")
        {
            $notify[] = ['error', 'Please complete the form.'];
            return back()->withNotify($notify);
        }

        $sorti = sorteo::where('status', 0)->first();

        if($sorti->secuencia > 5)
        {
            $sorti->status = 1;
            $sorti->save();
        }
       

        $valor = sorteo::where('status',0)->count();

        if($valor)
        { 
            $notify[] = ['error', 'There is already an active draw.'];
            return back()->withNotify($notify);
        }

        $sorte = new sorteo();
        $sorte->price = $precio;
        $sorte->date = $fecha;
        $sorte->participantes = 0;
        $sorte->status = 0;
        $sorte->moneda = 2;
        $sorte->save();
        
        $notify[] = ['success', 'The Sorteo has been created'];
        return back()->withNotify($notify);
        
    }
    
    public function update(request $request){
      
         $request->id_sorteo;
         $request->fecha;
         if($request->fecha == "")
        {
            $notify[] = ['error', 'Please insert to date.'];
            return back()->withNotify($notify);
        }
        
        $sort = sorteo::where('id', $request->id_sorteo)->first();

        if($sort->status == 1){
            $notify[] = ['error', 'Sorteo is closed.'];
            return back()->withNotify($notify);
        }
      
        $sort->date =  $request->fecha;
        $sort->save();

        $notify[] = ['success', 'The Sorteo has been Updated'];
        return back()->withNotify($notify);
    }

    public function Detalle($id){
        echo $id;
    }

    public function sitio($premio = ''){
        $sorteo = sorteo::where('status',0)->first();   
        $data['page_title'] = 'Winner Lotto';
        $data['sorteo'] = $sorteo;
        $total = ticket::where('sorteo',$sorteo->id)->sum('price');
        $parti = ticket::where('sorteo',$sorteo->id)->count();
        $repa = $this->resultados($total, $parti);
        $data['participantes']   = $parti;
        $data['total']           = $repa['total'];
        $data['fundacion']       = $repa['fundacion'];
        if($premio == '')
              $data['ganadores']       = resul_loto::where('sorteo',$sorteo->id)->paginate(33);
        elseif($premio == 1)
               $data['ganadores']       = resul_loto::where('sorteo',$sorteo->id)->where('premio','<=',3)->paginate(15);
            else
              $data['ganadores']       = resul_loto::where('sorteo',$sorteo->id)->where('premio',$premio)->paginate(33);
        return view('admin.lotto.loteria', $data);
    }

    public function oficial(){
        $sorteo = sorteo::where('status',0)->first();    
        $total = ticket::where('sorteo',$sorteo->id)->sum('price');
        $parti = ticket::where('sorteo',$sorteo->id)->count();
        $repa = $this->resultados($total, $parti);
        $data['page_title']      = 'Preview lotto';
        $data['sorteo']          = $sorteo;
        $data['participantes']   = ticket::where('sorteo',$sorteo->id)->count();
        $data['total']           = $repa['total'];
        $data['primer']          = $repa['primero'];
        $data['segundo']         = $repa['segundo'];
        $data['tercero']         = $repa['tercero'];
        $data['total_2x']        = $repa['total_2x'];
        $data['corto']           = $repa['corto'];
        $data['solidario']       = $repa['solidario'];
        $data['procash']         = $repa['procash'];
        $data['fundacion']       = $repa['fundacion'];
        $data['bono']            = $repa['bono'];
        return view('admin.lotto.genera', $data);
    }

    public function G_sorteo(){
        $sorteo = sorteo::where('status',0)->first();
        switch($sorteo->secuencia){
              case 1: $this->primer_premio(); break;
              case 2: $this->segundo_premio(); break;
              case 3: $this->tercer_premio(); break;
              case 4: $this->premio_2x(); break;
              case 5: $this->premio_solidario(); break;
              default:   $notify[] = ['error', 'Ya se lanzo la loteria'];
                         return back()->withNotify($notify);
        }
        $notify[] = ['success', 'Winner lotto bonus success'];
        return back()->withNotify($notify);
     
    }

    public function primer_premio(){
        $sorteo = sorteo::where('status',0)->first();    
        $total = ticket::where('sorteo',$sorteo->id)->sum('price');
        $parti = ticket::where('sorteo',$sorteo->id)->count();
        $repa = $this->resultados($total,$parti);
        $user = $this->girar_esfera($sorteo);
        $premio = $repa['primero'];
        $titulo = 'Win 1st Prize Lotto Bonus '.$premio;
        $this->insert_win($user,$sorteo, 1, $premio);
        $this->pagar_premio($user,$sorteo,$premio,$titulo);
        $sorteo->secuencia += 1;
        $sorteo->save();
    }

    public function segundo_premio(){
        $sorteo = sorteo::where('status',0)->first();    
        $total = ticket::where('sorteo',$sorteo->id)->sum('price');
        $parti = ticket::where('sorteo',$sorteo->id)->count();
        $repa = $this->resultados($total,$parti);
        $user = $this->girar_esfera($sorteo);
        $premio = $repa['segundo'];
        $this->insert_win($user,$sorteo, 2, $premio);
        $titulo = 'Win 2nd Prize Lotto Bonus '.$premio;
        $this->pagar_premio($user,$sorteo,$premio,$titulo);
        $sorteo->secuencia += 1;
        $sorteo->save();
    }

    public function tercer_premio(){
        $sorteo = sorteo::where('status',0)->first();    
        $total = ticket::where('sorteo',$sorteo->id)->sum('price');
        $parti = ticket::where('sorteo',$sorteo->id)->count();
        $repa = $this->resultados($total,$parti);
        $user = $this->girar_esfera($sorteo);
        $premio = $repa['tercero'];
        $this->insert_win($user,$sorteo, 3, $premio);
        $titulo = 'Win 3rd Prize Lotto Bonus '.$premio;
        $this->pagar_premio($user,$sorteo,$premio,$titulo);
        $sorteo->secuencia += 1;
        $sorteo->save();
    }


    public function premio_2x(){

        $sorteo = sorteo::where('status',0)->first();    
        $total = ticket::where('sorteo',$sorteo->id)->sum('price');
        $parti = ticket::where('sorteo',$sorteo->id)->count();
        $repa = $this->resultados($total,$parti);

        $tot_pay = round( ($parti * 15) / 100);
        for($i=0; $i<$tot_pay;$i++)
        {
                $user = $this->girar_esfera($sorteo);
                $premio = $repa['corto'];
                $this->insert_win($user,$sorteo, 4, $premio);
                $titulo = 'Win Double Lotto Bonus '.$premio;
                $this->pagar_premio($user,$sorteo,$premio,$titulo);
        }
       $sorteo->secuencia += 1;
         $sorteo->save();
    }

    public function premio_solidario(){

        $sorteo = sorteo::where('status',0)->first();    
        $total = ticket::where('sorteo',$sorteo->id)->sum('price');
        $parti = ticket::where('sorteo',$sorteo->id)->count();
        $repa = $this->resultados($total,$parti);
        $total_ticket = ticket::where('sorteo',$sorteo->id)->where('status',0)->count();
        $monto = round($repa['solidario'] / $total_ticket,2);
        $solis = ticket::where('sorteo',$sorteo->id)->where('status',0)->get();
        foreach($solis as $gana)
        {
                $premio = $monto;
                $gana->status = 1;
                $gana->save();
                $this->insert_win($gana->user_id,$sorteo, 5, $premio);
                $titulo = 'Solidary Lotto Bonus '.$premio;
                $this->pagar_premio($gana->user_id,$sorteo,$premio,$titulo); 
        }
        $sorteo->secuencia += 1;
        $sorteo->save();
    }
    

    public function insert_win($user,$sorteo, $poci, $premio){
       
        $user = User::where('id',$user)->first();
        $resu =  new resul_loto();
        $resu->user_id = $user->id;
        $resu->sorteo  = $sorteo->id;
        $resu->premio  = $poci;
        $resu->monto   = $premio;
        $resu->save();
    }

    public function pagar_premio($user, $sorteo, $premio, $titulo){
        $user = User::where('id',$user)->first();
        $user->interest_wallet_trx += $premio;
        $user->save();
        $user->transactions()->create([
            'trx' => getTrx(),
            'user_id' => $user->id,
            'amount_con' => $premio,
            'main_amo_con' => $premio,
            'balance' => $user->interest_wallet_trx,
            'title' =>  $titulo.' TRX',
            'charge' => 0,
            'moneda' => $sorteo->moneda,
            'type' => 'Bonus_loto'
        ]); 

        send_email($user, 'WIN_LOTTO', [
            'amount' => formatter_money($premio)
        ]); 
    }

    public function girar_esfera($sorteo){
        $tickets = ticket::where('sorteo',$sorteo->id)->where('status',0)->get();
         $i = 0;
        foreach($tickets as $valor){
            $i++;
            $suerte[$i] =  $valor->id;
        }
        $resultado = rand(1,$i);
        $gan = $suerte[$resultado];   
        $tic = ticket::where('id',$gan)->first();
        $tic->status = 1;
        $tic->save();
        return $tic->user_id;
    }

    public function resultados($total,$participante){
            
        if($participante == 0){
             $gana = 0;
        }else{
            $parti_2 = round(($participante * 15) / 100);   
            $parte                 = ($total * 30) / 100; 
            $gana                  = round($parte/$parti_2,2);
        }

            $primero               = ($total * 15) / 100;
            $segundo               = ($total * 10) / 100;
            $tercero               = ($total * 5) / 100;
            $parte                 = ($total * 30) / 100;      
            $solidario             = ($total * 15) / 100;
            $procash               = ($total * 10) / 100;
            $fundacion             = ($total * 5) / 100;
            $bono                  = ($total * 10) / 100;

            $data['total']         = $total;
            $data['primero']       = $primero;
            $data['segundo']       = $segundo;
            $data['tercero']       = $tercero;
            $data['total_2x']      = $parte;
            $data['corto']         = $gana;
            $data['solidario']     = $solidario;
            $data['procash']       = $procash;
            $data['fundacion']     = $fundacion;
            $data['bono']          = $bono;

            return $data;
    }

    public function transaction($user = ''){
         
        if($user == '')
            $data['ticket']  = Buy_ticket::latest()->paginate(15);
        else
          $data['ticket']  = Buy_ticket::where('user_id',$user)->latest()->paginate(15);

        $data['page_title'] = 'Sales - Tickets';
        $data['empty_message'] = 'No Sales.';

        return view('admin.reports.ticket', $data);


    }

    public function transaction_sorteo($sorteo){

        $data['ticket']  = Buy_ticket::where('sorteo',$sorteo)->latest()->paginate(15);

        $data['page_title'] = 'Tickets Sorteo No. '.$sorteo;
        $data['empty_message'] = 'No Sales.';
        return view('admin.reports.ticket', $data);
    }


}

?>   