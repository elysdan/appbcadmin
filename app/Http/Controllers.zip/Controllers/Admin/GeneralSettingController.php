<?php

namespace App\Http\Controllers\Admin;

use App\Frontend;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\GeneralSetting;
use App\PoolInterest; 
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Image;



class GeneralSettingController extends Controller
{
    public function index()
    {
        $general_setting = GeneralSetting::first();
        $page_title = 'General Settings';
        
        $f_ini           = Carbon::now()->format('Y-m')."-01";
        $f_fin           = Carbon::now()->format('Y-m')."-30";
        $dias            = Carbon::now()->format('d');

        $tab_trx =  PoolInterest::where('created_at', '>=',  $f_ini)->where('moneda','2')->sum('porcentaje') + $general_setting->pool_interest_trx;
        $tab_eth =  PoolInterest::where('created_at', '>=',  $f_ini)->where('moneda','1')->sum('porcentaje') + $general_setting->pool_interest;
         
        $total_trx = number_format((($tab_trx / ($dias + 1)) * 30),2,'.','');
        $total_eth = number_format((($tab_eth / ($dias + 1)) * 30),2,'.','');

        return view('admin.setting.general_setting', compact('page_title', 'general_setting','total_trx','total_eth'));
    }

    public function update(Request $request)
    {
        $validation_rule = [
            'bclr' => ['nullable', 'regex:/^[a-f0-9]{6}$/i'],
            'sclr' => ['nullable', 'regex:/^[a-f0-9]{6}$/i'],
        ];

        $custom_attribute = [
            'bclr' => 'Base color',
            'sclr' => 'Secondary Color',
        ];

        $request->validate([
            'bal_trans_fixed_charge' => 'required|numeric|min:0',
            'bal_trans_per_charge' => 'required|numeric|min:0',
        ]);

        $validator = Validator::make($request->all(), $validation_rule, [], $custom_attribute);
        $validator->validate();

        $general_setting = GeneralSetting::first();
        $request->merge(['ev' => isset($request->ev) ? 1 : 0]);
        $request->merge(['en' => isset($request->en) ? 1 : 0]);
        $request->merge(['sv' => isset($request->sv) ? 1 : 0]);
        $request->merge(['sn' => isset($request->sn) ? 1 : 0]);
        $request->merge(['reg' => isset($request->reg) ? 1 : 0]);


        $general_setting->update($request->only(['sitename', 'cur_text', 'bal_trans_fixed_charge', 'bal_trans_per_charge',
            'cur_sym', 'ev', 'en', 'sv', 'sn', 'reg', 'alert', 'bclr', 'sclr','pool_interest','pool_interest_trx','gas_user','maximo_fee',
        ]));

        $notify[] = ['success', 'General Setting has been updated.'];
        return back()->withNotify($notify);
    }

    public function popup()
    {
        $page_title = 'pop ups';
        return view('admin.popup', compact('page_title'));
    }
    
    public function smart()
    {
        $page_title = 'Smart Contract';
        $wallet     = '0xbAa37930a2B24bc17F92f26c86D8A514539A7a44';
        $asigna     = '0xCcE433BAdB23B695Cae3013ea459C1fE407C133a';
        $resp   =  $this->send_smart('/eth/balance', array('dire'=>$asigna));
        $monto_asigna    =  @$resp->result;
        $resp   =  $this->send_smart('/eth/balance', array('dire'=>$wallet));
        $monto_wallet    =  @$resp->result;
        $tipo_co = 1;
        return view('admin.smart', compact('page_title', 'wallet','asigna','monto_asigna', 'monto_wallet','tipo_co'));
    }


    public function smart_deposito()
    {
        $page_title = 'Smart Contract Deposit';
        $wallet     = 'TCiH3xu1kcUcT2ycc3JZF9SwmxqaPf9whh';
        $asigna     = 'TXnpEHYnAfvSuCznquQy4s8pcg9PtWNfJE';
        $resp   =  $this->send_smart('/tron/balance', array('dire'=>$asigna));
        $monto_asigna    =  @$resp->result;
        $resp   =  $this->send_smart('/tron/balance', array('dire'=>$wallet));
        $monto_wallet    =  @$resp->result;
        $tipo_co = 2;
        return view('admin.smart_deposito', compact('page_title', 'wallet','asigna','monto_asigna', 'monto_wallet', 'tipo_co'));
    }

    public function update_deposito(){
        set_time_limit(0);
        $resp   =  $this->send_smart('/tron/retirar', array('dire'=>'0xxooooo'));
        $notify[] = ['success', 'Wallet Recharged!!.'];
        return back()->withNotify($notify);
    }


    public function smart_tron()
    {
        $page_title = 'Smart Contract';
        $wallet     = 'TKSSoisLQk9Lt2wxtGvSv2ZhreRAJcqStx';
        $asigna     = 'TXnpEHYnAfvSuCznquQy4s8pcg9PtWNfJE';
        $resp   =  $this->send_smart('/tron/balance', array('dire'=>$asigna));
        $monto_asigna    =  @$resp->result;
        $resp   =  $this->send_smart('/tron/balance', array('dire'=>$wallet));
        $monto_wallet    =  @$resp->result;
        $tipo_co = 2;
        return view('admin.smart', compact('page_title', 'wallet','asigna','monto_asigna', 'monto_wallet', 'tipo_co'));
    }
    
    public function recargasmart_tron(Request $request){
        $request->validate([
            'recarga' => '',
        ]);
        $recarga = $request->recarga;
         try{
        $data = array ('monto' => $recarga);
        $resp = $this->send_smart('/tron/saldo',$data);
          $notify[] = ['success', 'Smart contract Recargado.'];
         }catch(Exception $err){
                 $notify[] = ['error', 'Ocurrio un error durante la ejecución del smart contract']; 
         }
        return redirect()->route('admin.setting.smart_tron')->withNotify($notify);
    }

    public function recargasmart(Request $request){
        $request->validate([
            'recarga' => '',
        ]);
        $recarga = $request->recarga;
         try{
        $data = array ('monto' => $recarga);
        $resp = $this->send_smart('/eth/saldo',$data);
          $notify[] = ['success', 'Smart contract Recargado.'];
         }catch(Exception $err){
                 $notify[] = ['error', 'Ocurrio un error durante la ejecución del smart contract']; 
         }
        return redirect()->route('admin.setting.smart')->withNotify($notify);
    }

    public function popupUpdate(Request $request)
    {
        $request->validate([
            'image' => 'image|mimes:jpg,jpeg,png|max:2024',
        ]);



        if ($request->hasFile('image')) {
            try {
                $path = config('constants.popup.path');
                if (!file_exists($path)) {
                    mkdir($path, 0755, true);
                }
                Image::make($request->image)->save($path . '/popup.png');
            } catch (\Exception $exp) {
                $notify[] = ['error', 'image could not be uploaded.'];
                return back()->withNotify($notify);
            }
        }

         $general_setting = GeneralSetting::first();
         $general_setting->popup = $request->popup ? 1 : 0;
         $general_setting->save();

        $notify[] = ['success', 'image has been updated.'];
        return back()->withNotify($notify);
    }


    public function logoIcon()
    {
        $page_title = 'Logo & Icon';
        return view('admin.setting.logo_icon', compact('page_title'));
    }

    public function logoIconUpdate(Request $request)
    {
        $request->validate([
            'logo' => 'image|mimes:jpg,jpeg,png',
            'favicon' => 'image|mimes:png',
        ]);

        if ($request->hasFile('logo')) {
            try {
                $path = config('constants.logoIcon.path');
                if (!file_exists($path)) {
                    mkdir($path, 0755, true);
                }
                Image::make($request->logo)->save($path . '/logo.png');
            } catch (\Exception $exp) {
                $notify[] = ['error', 'Logo could not be uploaded.'];
                return back()->withNotify($notify);
            }
        }

        if ($request->hasFile('favicon')) {
            try {
                $path = config('constants.logoIcon.path');
                if (!file_exists($path)) {
                    mkdir($path, 0755, true);
                }
                $size = explode('x', config('constants.favicon.size'));
                Image::make($request->favicon)->resize($size[0], $size[1])->save($path . '/favicon.png');
            } catch (\Exception $exp) {
                $notify[] = ['error', 'Favicon could not be uploaded.'];
                return back()->withNotify($notify);
            }
        }

        $notify[] = ['success', 'Logo Icons has been updated.'];
        return back()->withNotify($notify);
    }

    public function socialLogin()
    {
        $page_title = 'Social Login Setting';
        $general_setting = GeneralSetting::first(['social_login']);
        $social_login = Frontend::where('key', 'gauth')->orWhere('key', 'fauth')->get();
        return view('admin.setting.social_login_setting', compact('page_title', 'general_setting', 'social_login'));
    }

    public function socialLoginUpdate(Request $request)
    {
        $validation_rule = [
            'gid' => 'required_with:social_login',
            'gsecret' => 'required_with:social_login',
            'fid' => 'required_with:social_login',
            'fsecret' => 'required_with:social_login',
        ];

        $custom_attribute = [
            'gid' => 'Google client id',
            'gsecret' => 'Google client secret',
            'fid' => 'Facebook client id',
            'fsecret' => 'Facebook client secret',
        ];

        $custom_message = ['*.required_with' => ':attribute is required for social login'];

        $validator = Validator::make($request->all(), $validation_rule, $custom_message, $custom_attribute);
        $validator->validate();

        $gid = '';
        $gsecret = '';
        $fid = '';
        $fsecret = '';
        if ($request->social_login) {
            $gid = $request->gid;
            $gsecret = $request->gsecret;
            $fid = $request->fid;
            $fsecret = $request->fsecret;
        }

        Frontend::updateOrCreate(

            ['key' => 'gauth'],
            ['value' => [
                'id' => $gid,
                'secret' => $gsecret,
            ]]

        );
        Frontend::updateOrCreate(

            ['key' => 'fauth'],
            ['value' => [
                'id' => $fid,
                'secret' => $fsecret,
            ]]

        );

        $general_setting = GeneralSetting::first();
        $request->merge(['social_login' => isset($request->social_login) ? 1 : 0]);
        $general_setting->update($request->only(['social_login']));

        $notify[] = ['success', 'Social Login Setting has been updated.'];
        return back()->withNotify($notify);
    }


    public function contact()
    {
        $page_title = 'Contact Settings';
        $data = GeneralSetting::first();

        return view('admin.setting.contact', compact('page_title', 'data'));

    }

    public function contactUpdate(Request $request)
    {

        $request->validate([
            'phone' => 'required',
            'email' => 'required',
            'address' => 'required',
        ]);
        $general_setting = GeneralSetting::first();
        $general_setting->contact_email = $request->email;
        $general_setting->contact_phone = $request->phone;
        $general_setting->contact_address = $request->address;
        $general_setting->save();

        $notify[] = ['success', 'Contact Setting has been updated.'];
        return back()->withNotify($notify);
    }

    public function noticeIndex()
    {

        $page_title = 'Contact Settings';

        return view('admin.notice', compact('page_title'));

    }

    public function noticeUpdate(Request $request)
    {

        $general_setting = GeneralSetting::first();
        $general_setting->notice = $request->notice;
        $general_setting->network_account_notice = $request->network_account_notice;
        $general_setting->investor_account_notice = $request->investor_account_notice;
        $general_setting->save();

        $notify[] = ['success', 'Notice has been updated.'];
        return back()->withNotify($notify);

    }

    function send_smart($sesion, $data){

        $arra = "";
         foreach ($data as $key => $value) {
             if($arra != "") $arra .= "&";
             $arra .= $key."=".$value;
         }

         $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL,"http://labts.procashdream.com/smart".$sesion);
          curl_setopt($ch, CURLOPT_POST, TRUE);
         curl_setopt($ch, CURLOPT_POSTFIELDS,$arra);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          $resul = curl_exec ($ch);
          curl_close ($ch);
          $resu = json_decode($resul);
          return $resu;
      }


}
