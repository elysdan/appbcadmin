<?php

namespace App\Http\Controllers\Admin;

use App\CompenstionPlan;
use App\GeneralSetting;
use App\NetworkContract;
use App\PoolInterest;
use App\Product;
use App\Rank;
use App\Share;
use App\User;
use App\send_tele;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use Intervention\Image\Facades\Image;

class ProductController extends Controller
{
    public function index_trx()
    {
        $data['page_title'] = 'Contract TRX Settings';
        $data['nt_contract'] = networkContract::where('moneda',2)->first();
        return view('admin.product_trx', $data);
    }
    public function update_trx(Request $request)
    {
        $request->validate([
            'price' => 'required|numeric|min:0',
            'max_profit' => 'required|numeric|min:0',
            'sponsorship_bonus' => 'required|numeric|min:0',
            'binary_bonus' => 'required|numeric|min:0',
            'total_contract' => 'required|integer|min:0',
        ]);

        $data = NetworkContract::where('moneda',2)->first();
        $data->max_profit = $request->max_profit;
        $data->price = $request->price;
        $data->total_contract = $request->total_contract;
        $data->ref_bonus = $request->sponsorship_bonus;
        $data->binary_bonus = $request->binary_bonus;
        $data->pool_after   = $request->pool_after;
        $data->save();

        $notify[] = ['success', 'Updated Successfully'];
        return back()->withNotify($notify);
    }
    public function index()
    {
        $data['page_title'] = 'Contract Settings';
        $data['product'] = Product::where('moneda',1)->first();
        return view('admin.product', $data);
    }

    public function update(Request $request)
    {


        $this->validate($request, [
            'price' => 'required|min:0',
            'total_share' => 'required|min:1|integer',
            'active_charge' => 'required|numeric|min:0',
            'investor_active_charge' => 'required|numeric|min:0',
            'pool_start' => 'required|integer|min:1',
            'max_profit' => 'required|numeric|min:0',
            'investor_max_profit' => 'required|numeric|min:0',
        ]);


        $data = Product::where('moneda',1)->first();
        $data->name = $request->name;
        $data->price = $request->price;
        $data->total_share = $request->total_share;
        $data->save();

        $gnl = GeneralSetting::first();
        $gnl->active_charge = $request->active_charge;
        $gnl->investor_active_charge = $request->investor_active_charge;
        $gnl->pool_start = $request->pool_start;
        $gnl->max_profit = $request->max_profit;
        $gnl->investor_max_profit = $request->investor_max_profit;
        $gnl->save();

        $notify[] = ['success', 'Updated successfully'];
        return back()->withNotify($notify);

    }

    public function compensation()
    {

        $data['page_title'] = 'Compensation Plans';
        $data['plans'] = CompenstionPlan::latest()->paginate(config('constants.table.default'));
        return view('admin.compensation_plan', $data);

    }

    public function compensationCreate(Request $request)
    {
        $this->validate($request, [
            'min_share' => 'required|integer|min:1',
            'max_share' => 'required|integer|min:1',
            'ref_bonus' => 'required|numeric|min:0',
            'binary_bonus' => 'required|min:1|numeric',
            'status' => 'required|min:0|integer',
        ]);

        $data = new CompenstionPlan();
        $data->min_share = $request->min_share;
        $data->max_share = $request->max_share;
        $data->ref_bonus = $request->ref_bonus;
        $data->binary_bonus = $request->binary_bonus;
        $data->status = $request->status;
        $data->save();
        $notify[] = ['success', 'plan created successfully'];
        return back()->withNotify($notify);

    }

    public function compensationUpdate(Request $request)
    {

        $this->validate($request, [
            'id' => 'required|integer|min:1',
            'min_share' => 'required|integer|min:1',
            'max_share' => 'required|integer|min:1',
            'ref_bonus' => 'required|numeric|min:0',
            'binary_bonus' => 'required|min:1|numeric',
            'status' => 'required|min:0|integer',
        ]);

        $data = CompenstionPlan::findorFail($request->id);
        $data->min_share = $request->min_share;
        $data->max_share = $request->max_share;
        $data->ref_bonus = $request->ref_bonus;
        $data->binary_bonus = $request->binary_bonus;
        $data->status = $request->status;
        $data->save();

        $notify[] = ['success', 'plan Updated successfully'];
        return back()->withNotify($notify);

    }


    public function ranks()
    {
        $data['page_title'] = 'Manage Ranks';
        $data['ranks'] = Rank::paginate(config('constants.table.default'));

        return view('admin.rank', $data);
    }


    public function rankCreate(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:60',
            'binary_earning' => 'required|numeric|min:0',
            'avatar' => 'required|image|mimes:jpg,jpeg,png',
        ]);


        $path = config('constants.rank.path');
        $size = config('constants.rank.size');

        $filename = '';
        if ($request->hasFile('avatar')) {
            try {
                $filename = upload_image($request->avatar, $path, $size, $filename);
            } catch (\Exception $exp) {
                $notify[] = ['errors', 'Image could not be uploaded.'];
                return back()->withNotify($notify);
            }
        }

        $rank = new Rank();
        $rank->name = $request->name;
        $rank->binary_earning = $request->binary_earning;
        $rank->avatar = $filename;
        $rank->save();


        $notify[] = ['success', 'Rank Created successfully'];
        return back()->withNotify($notify);
    }


    public function rankUpdate(Request $request)
    {
        $this->validate($request, [
            'id' => 'required|integer',
            'name' => 'required|max:60',
            'binary_earning' => 'required|numeric|min:0',
            'avatar' => 'image|mimes:jpg,jpeg,png',
        ]);

        $rank = Rank::findOrFail($request->id);
        $filename = $rank->avatar;
        if ($request->hasFile('avatar')) {
            try {

                $path = config('constants.rank.path');
                $size = config('constants.rank.size');

                $filename = upload_image($request->avatar, $path, $size, $filename);
            } catch (\Exception $exp) {
                $notify[] = ['errors', 'Image could not be uploaded.'];
                return back()->withNotify($notify);
            }
        }

        $rank->name = $request->name;
        $rank->binary_earning = $request->binary_earning;
        $rank->avatar = $filename;
        $rank->save();

        $notify[] = ['success', 'Rank updated successfully'];
        return back()->withNotify($notify);
    }

    public function rankDelete(Request $request)
    {
        $this->validate($request, [
            'id' => 'required|integer',
        ]);
        $rank = Rank::findOrFail($request->id);
        @unlink('assets/images/rank/' . $rank->avatar);
        $rank->delete();
        $notify[] = ['success', 'Rank deleted successfully'];
        return back()->withNotify($notify);
    }

    public function poolIndex()
    {
       $data['page_title']               =   'Pool Interest ETH';
       $data['product']                  =   Product::where('moneda',1)->first();
       $data['eligible_share']           =   Share::where('moneda',1)->where('start_date', '<=', Carbon::now()->toDateString())->where('status', 1)->sum('total_share');
       $data['expired_share']            =   Share::where('moneda',1)->where('status', 2)->where('type', 1)->sum('total_share');

       $data['network_Contract']         =   NetworkContract::where('moneda',1)->first();
       $data['active_network_Contract']  =   Share::where('moneda',1)->where('status', 3)->where('type', 0)->sum('total_share');
       $data['network_Contract_expired'] =   Share::where('moneda',1)->where('status', 2)->where('type', 0)->sum('total_share');
       return view('admin.pool_interest', $data);
    }

    public function pooltrxIndex()
    {
        error_reporting(E_ALL);
       $data['page_title']               =   'Pool Interest TRX';
       $data['product']                  =   product::where('moneda',2)->first();
       $data['eligible_share']           =   Share::where('moneda',2)->where('status', 1)->where('type', 1)->sum('total_share');
       $data['expired_share']            =   Share::where('moneda',2)->where('status', 2)->where('type', 1)->sum('total_share');

       $data['network_Contract']         =   NetworkContract::where('moneda',2)->first();
       $data['active_network_Contract']  =   Share::where('moneda',2)->where('status', 3)->where('type', 0)->sum('total_share');
       $data['network_Contract_expired'] =   Share::where('moneda',2)->where('status', 2)->where('type', 0)->sum('total_share');
       return view('admin.pooltrx_interest', $data);
    }

    public function poolUpdateCheck(Request $request)
    {
        $this->validate($request, [
            'profit' => 'required|numeric|min:0',
        ]);

        $total_share_eligible = eligible_share_sell();

        if ($total_share_eligible == 0) {
            $notify[] = ['error', 'No Eligible Share found yet'];
            return back()->withNotify($notify);
        }

        $date = Carbon::now()->toDateString();
        $shares = Share::where('start_date', '<=', $date)->where('status', 1)->get();

        if ($shares == null) {
            $notify[] = ['error', 'No Eligible Share found yet'];
            return back()->withNotify($notify);
        }

        $code = verification_code(6);
        $sig = hash_hmac('sha256', $code, auth()->guard('admin')->user()->email);
        $data['hash'] = $sig;

        send_tele(auth()->guard('admin')->user(), 'pool_interest_2fa', [
            'code' => $code,
        ]);

        Session::put('profit', $request->profit);

        $data['profit'] = $request->profit;
        $data['page_title'] = 'Pool Interest 2Fa Check';
        $data['product'] = Product::first();
        $data['eligible_share'] = Share::where('start_date', '<=', Carbon::now()->toDateString())->where('status', 1)->sum('total_share');
        $data['expired_share'] = Share::where('status', 2)->sum('total_share');
        return view('admin.pool_interest_2fa', $data);

    }


    public function poolUpdate(Request $request)
    {

      

        $this->validate($request, ['code' => 'required|max:191',]);

        $check_profit = Session::get('profit');
        if ($check_profit == null)
        {
            $notify[] = ['error', 'Invalid request'];
            redirect()->route('admin.pooltrx.interest')->withNotify($notify);;
        }

        $sig = hash_hmac('sha256', $request->code, auth()->guard('admin')->user()->email);
        if($request->hash != $sig) {
            $notify[] = ['error', 'OTP NOT MATCHED!!!'];
            return redirect()->route('admin.pooltrx.interest')->withNotify($notify);
        }
              
        $total_share_eligible = eligible_share_sell();

        if ($total_share_eligible == 0) {
            $notify[] = ['error', 'No Eligible Share found yet'];
            return back()->withNotify($notify);
        }

        $per_share_profit = $request->profit / $total_share_eligible;

        $date = Carbon::now()->toDateString();
        $shares = Share::where('moneda',2)->where('start_date', '<=', $date)->where('status', 1)->get();

        if ($shares == null) {
            $notify[] = ['error', 'No Eligible Share found yet'];
            return back()->withNotify($notify);
        }

        foreach ($shares as $share) {
            $profit = $share->total_share * round($per_share_profit, 8);
            $user = User::find($share->user_id);
            $max_return_profit = formatter_money($share->return_profit + $profit);
            $max_earning = formatter_money($share->max_earning);
            if ($max_earning < $max_return_profit) {
                $amount = $share->max_earning - $share->return_profit;
                $share->status = 2;
            } elseif ($max_earning >= $max_return_profit) {
                $amount = $profit;
            }
            $share->return_profit += $amount;
            $share->save();
            $user->interest_wallet += $amount;
            $user->total_return += $amount;
            $user->save();

            $trx = $user->transactions()->create([
                'trx' => getTrx(),
                'user_id' => $user->id,
                'amount' => formatter_money($amount),
                'main_amo' => formatter_money($amount),
                'balance' => $user->interest_wallet,
                'title' => 'Interest for ' . $share->total_share . ' shares',
                'charge' => 0,
                'type' => 'pool_interest',
            ]);

            send_tele($user, 'POOL_INTEREST', [
                'trx' => $trx->trx,
                'amount' => formatter_money($amount),
                'balance' => formatter_money($user->interest_wallet),
                'share' => $share->total_share,
            ]);

            send_sms($user, 'POOL_INTEREST', [
                'trx' => $trx->trx,
                'amount' => formatter_money($amount),
                'balance' => formatter_money($user->interest_wallet),
                'share' => $share->total_share,
            ]);

        }

        $pool = new PoolInterest();
        $pool->amount = $request->profit;
        $pool->moneda = 1;
        $pool->total_distribution_share = $total_share_eligible;
        $pool->per_share_profit = round($per_share_profit, 8);
        $pool->save();

        $notify[] = ['success', 'Pool Interest given successfully'];
        return redirect()->route('admin.pool.interest')->withNotify($notify);
    }


     public function poll_auto()
    {
        set_time_limit(0);
         $date = Carbon::now()->toDateString();
         $valida = PoolInterest::where('moneda',1)->where('created_at', '>=', $date)->first();

         if($valida != null)
         {
            return "Pool pagado con exito!!";
         }

        $gnl = GeneralSetting::first();
        $porcentaje = $gnl->pool_interest;

        $total_share_eligible = eligible_share_sell();
        $total_pagar = (($total_share_eligible * 0.07) * $porcentaje)/100;
        $per_share_profit = $total_pagar / $total_share_eligible;

        $pool = new PoolInterest();
        $pool->amount = $total_pagar;
        $pool->moneda = 1;
        $pool->total_distribution_share = $total_share_eligible;
        $pool->per_share_profit = round($per_share_profit, 8);
        $pool->porcentaje = $porcentaje;
        $pool->save();

        $date = Carbon::now()->toDateString();
        $shares = Share::where('start_date', '<=', $date)->where('moneda',1)->where('type',1)->where('status', 1)->get();
        if ($shares == null) {
            $notify[] = ['error', 'No Eligible Share found yet'];
            return back()->withNotify($notify);
        }

        foreach ($shares as $share) {
            
            if($share->id < 3367)
            { 
              $profit = $share->total_share * round($per_share_profit, 8);
            }else{
                $per_5 = round($per_share_profit/2, 8);
                $profit = $share->total_share * $per_5;
            }

            $user = User::find($share->user_id);
            $max_return_profit = formatter_money($share->return_profit + $profit);
            $max_earning = formatter_money($share->max_earning);

            if ($max_earning < $max_return_profit) {
                $amount = $share->max_earning - $share->return_profit;
                $share->status = 2;
            } elseif ($max_earning >= $max_return_profit) {
                $amount = $profit;
            }
            $share->return_profit += $amount;
            $share->save();
            $user->interest_wallet += $amount;
            $user->total_return += $amount;
            $user->save();
            cierra_paquete($share->id);

            if( $share->return_profit == $max_earning)
            {
                $share->status = 2;
                $share->save();
            }

         
            $trx = $user->transactions()->create([
                'trx' => getTrx(),
                'user_id' => $user->id,
                'amount' => formatter_money($amount),
                'main_amo' => formatter_money($amount),
                'balance' => $user->interest_wallet,
                'title' => 'Interest for ' . $share->total_share . ' shares',
                'charge' => 0,
                'type' => 'pool_interest',
            ]);

           send_tele($user, 'POOL_INTEREST', [
                'trx' => $trx->trx,
                'amount' => formatter_money($amount),
                'balance' => formatter_money($user->interest_wallet),
                'share' => $share->total_share,
            ]);
            send_sms($user, 'POOL_INTEREST', [
                'trx' => $trx->trx,
                'amount' => formatter_money($amount),
                'balance' => formatter_money($user->interest_wallet),
                'share' => $share->total_share,
            ]);

        }

      

        $notify[] = ['success', 'Pool Interest given successfully'];
        return redirect()->route('admin.pool.interest')->withNotify($notify);
    }


    public function networkContract()
    {
        $data['page_title'] = "Network Contract";
        $data['nt_contract'] = NetworkContract::first();
        return view('admin.networkContract', $data);
    }


    public function networkContractUpdate(Request $request)
    {

        $request->validate([
            'price' => 'required|numeric|min:0',
            'max_profit' => 'required|numeric|min:0',
            'sponsorship_bonus' => 'required|numeric|min:0',
            'binary_bonus' => 'required|numeric|min:0',
            'total_contract' => 'required|integer|min:0',
        ]);

        $data = NetworkContract::first();
        $data->max_profit = $request->max_profit;
        $data->price = $request->price;
        $data->total_contract = $request->total_contract;
        $data->ref_bonus = $request->sponsorship_bonus;
        $data->binary_bonus = $request->binary_bonus;
        $data->save();

        $notify[] = ['success', 'Updated Successfully'];
        return back()->withNotify($notify);

    }


    // pool trx 
   
    public function pooltrxUpdateCheck(Request $request)
    {

        $this->validate($request, [
            'profit' => 'required|numeric|min:0',
        ]);

        $total_share_eligible = eligible_share_sell();

        if ($total_share_eligible == 0) {
            $notify[] = ['error', 'No Eligible Share found yet'];
            return back()->withNotify($notify);
        }

        $date = Carbon::now()->toDateString();
        $shares = Share::where('start_date', '<=', $date)->where('status', 1)->get();

        if ($shares == null) {
            $notify[] = ['error', 'No Eligible Share found yet'];
            return back()->withNotify($notify);
        }

        $code = verification_code(6);
        $sig = hash_hmac('sha256', $code, auth()->guard('admin')->user()->email);
        $data['hash'] = $sig;

        send_email(auth()->guard('admin')->user(), 'pool_interest_2fa', [
            'code' => $code,
        ]);

        Session::put('profit', $request->profit);

        $data['profit'] = $request->profit;
        $data['page_title'] = 'Pool Interest 2Fa Check';
        $data['product'] = networkContract::where('moneda',2)->first();
        $data['eligible_share'] = Share::where('moneda',2)->where('start_date', '<=', Carbon::now()->toDateString())->where('status', 1)->sum('total_share');
        $data['expired_share'] = Share::where('moneda',2)->where('status', 2)->sum('total_share');
        return view('admin.pool_interest_2fa_trx', $data);

    }





   function pooltrxupdate(Request $request){  

    $this->validate($request, ['code' => 'required|max:191',]);

    $check_profit = Session::get('profit');
    if ($check_profit == null)
    {
        $notify[] = ['error', 'Invalid request'];
        redirect()->route('admin.pooltrx.interest')->withNotify($notify);;
    }

    $sig = hash_hmac('sha256', $request->code, auth()->guard('admin')->user()->email);
    if($request->hash != $sig) {
        $notify[] = ['error', 'OTP NOT MATCHED!!!'];
        return redirect()->route('admin.pooltrx.interest')->withNotify($notify);
    }
          // crear
    $total_share_eligible = eligible_sharetrx_sell();

    if ($total_share_eligible == 0) {
        $notify[] = ['error', 'No Eligible Share found yet'];
        return redirect()->route('admin.pooltrx.interest')->withNotify($notify);;
    }

    $per_share_profit = $request->profit / $total_share_eligible;

    $date = Carbon::now()->toDateString();
    $shares = Share::where('moneda',2)->where('start_date', '<=', $date)->where('status', 1)->get();

    if ($shares == null) {
        $notify[] = ['error', 'No Eligible Share found yet'];
        return back()->withNotify($notify);
    }

     foreach ($shares as $share) {
        $profit = $share->total_share * round($per_share_profit, 6);
       //$retener = round($profit * 0.1,6);
        //$profit = $profit- $retener;
        $user = User::find($share->user_id);

        $max_return_profit = formatter_money($share->return_profit + $profit);
        $max_earning = formatter_money($share->max_earning);
        if ($max_earning <= $max_return_profit) {
            $amount = $share->max_earning - $share->return_profit;
            $share->status = 2;
        } elseif ($max_earning >= $max_return_profit) {
            $amount = $profit;
        }
  
        $share->return_profit += $amount;
        $share->save();
        $user->interest_wallet_trx += $amount;
        $user->total_return_trx += $amount;
        $user->save();


        $trx = $user->transactions()->create([
            'trx' => getTrx(),
            'user_id' => $user->id,
            'amount_con' => formatter_money($amount),
            'main_amo_con' => formatter_money($amount),
            'balance' => $user->interest_wallet_trx,
            'title' => 'Interest for ' . $share->total_share . ' shares',
            'charge' => 0,
            'moneda' => 2,
            'type' => 'pool_interest',
        ]);

        send_email($user, 'POOL_INTEREST_TRX', [
            'trx' => $trx->trx,
            'amount' => formatter_money($amount),
            'balance' => formatter_money($user->interest_wallet),
            'share' => $share->total_share,
        ]);

        send_sms($user, 'POOL_INTEREST_TRX', [
            'trx' => $trx->trx,
            'amount' => formatter_money($amount),
            'balance' => formatter_money($user->interest_wallet),
            'share' => $share->total_share,
        ]);
       // reparte_interes($user->ref_id,$retener);
    }
    

    $pool = new PoolInterest();
    $pool->moneda = 2;
    $pool->amount = $request->profit;
    $pool->total_distribution_share = $total_share_eligible;
    $pool->per_share_profit = round($per_share_profit, 8);

    $notify[] = ['success', 'Pool Interest given successfully'];
    return redirect()->route('admin.pooltrx.interest')->withNotify($notify);
    }
     
     
    public function polltrx_auto()
    {
        set_time_limit(0);
       $date = Carbon::now()->toDateString();
        $valida = PoolInterest::where('moneda',2)->where('created_at', '>=', $date)->first();
        if($valida != null)
        {
            return "Pool pagado con exito!!";
        }
        
       $gnl = GeneralSetting::first();
       $porcentaje = $gnl->pool_interest_trx;
       $total_share_eligible = eligible_sharetrx_sell();
       $total_pagar = ((($total_share_eligible * 100)  * 0.7) * $porcentaje)/100;
        
       if($total_pagar <= 0)
       {
          $notify[] = ['error', 'No configuro el porcentaje'];
          return  "configurar porcemtaje a pagar";
       }

       if ($total_share_eligible == 0) {
            $notify[] = ['error', 'No Eligible Share found yet'];
            return redirect()->route('admin.pooltrx.interest')->withNotify($notify);;
        }

       $per_share_profit = $total_pagar / $total_share_eligible;

      
       $pool = new PoolInterest();
       $pool->amount = $total_pagar;
       $pool->moneda = 2;
       $pool->total_distribution_share = $total_share_eligible;
       $pool->per_share_profit = round($per_share_profit, 8);
       $pool->porcentaje = $porcentaje;
       $pool->save(); 
       

       $shares = Share::where('moneda',2)->where('start_date', '<=', $date)->where('type',1)->where('created_at','<>',$date)->where('status', 1)->get();

       if ($shares == null) {
           $notify[] = ['error', 'No Eligible Share found yet'];
           return 'No hay contractos';
       }
       
       foreach ($shares as $share) {
           
            $profit = $share->total_share * round($per_share_profit, 8);
            $user = User::find($share->user_id);
            $max_return_profit = formatter_money($share->return_profit + $profit);
            $max_earning = formatter_money($share->max_earning);

            if ($max_earning < $max_return_profit) {
                $amount = $share->max_earning - $share->return_profit;
                $share->status = 2;
            } elseif ($max_earning >= $max_return_profit) {
                $amount = $profit;
            }
          
            $share->return_profit += $amount;
            $share->save();
            
            cierra_paquete($share->id);

            print_r(json_decode($share));
           echo '<hr>';
            $user->interest_wallet_trx += $amount;
            $user->total_return_trx += $amount;
            $user->save();
        
            $trx = $user->transactions()->create([
                'trx' => getTrx(),
                'user_id' => $user->id,
                'amount_con' => formatter_money($amount),
                'main_amo_con' => formatter_money($amount),
                'balance' => $user->interest_wallet_trx,
                'title' => 'Interest for ' . $share->total_share . ' shares',
                'charge' => 0,
                'moneda' => 2,
                'type' => 'pool_interest',
            ]);
            
            
               $teleg = new send_tele();
                $teleg->user_id =   $user->id;
                $teleg->amount  =   $amount;
                $teleg->trx     =   $trx->trx;
                $teleg->pool    =   $pool->id;
                $teleg->balance =   $user->interest_wallet_trx;
                $teleg->share   =   $share->total_share;
                $teleg->save();

            
            
            
            /*

         /*  send_tele($user, 'POOL_INTEREST_TRX', [
                'trx' => $trx->trx,
                'amount' => formatter_money($amount),
                'balance' => formatter_money($user->interest_wallet),
                'share' => $share->total_share,
            ]);*/

        
                
                 
         } 
       
        return "Pagado";
    }
     

   

    public function buy_trx(Request $request)
    {   

                    $this->validate($request, [
                        'share' => 'required|integer|min:1',
                        'user' => 'required|integer'
                    ]);

                    $user  = User::where("id",$request->user)->first();
                    $product = product::where('moneda',2)->first();
                    $total_price = round($product->price * $request->share, 8);
                    $ab_share = $product->total_contract - $product->total_sell;
                    if ($ab_share < $request->share) {
                        $notify[] = ['error', 'Available Contracts = ' . $ab_share];
                        return back()->withNotify($notify);
                    }
                    
                    $user->shares_trx += $request->share;
                    $user->total_invest_trx += $total_price;
                    $user->save();
                    
                    $gnl = GeneralSetting::first();                
                    $max_earning = $total_price * $product->max_profit / 100;
                    $share = new  Share();
                    $share->user_id = $user->id;
                    $share->product_id = $product->id;
                    $share->total_share = $request->share;
                    $share->amount = $total_price;
                    $share->max_earning = $max_earning;
                    $share->type = 1;
                    $share->status = 1;
                    $share->start_date = Carbon::now()->addDays($product->pool_after);
                    $share->moneda = $product->moneda;
                    $share->save();

                    $product->total_sell += $request->share;
                    $product->save();
                    
             
                    $user->transactions()->create([
                        'trx' => getTrx(),
                        'user_id' => $user->id,
                        'amount' => trontoether($total_price),
                        'main_amo' => trontoether($total_price),
                        'amount_con' => $total_price,
                        'main_amo_con' => $total_price,
                        'balance' => 0,
                        'title' => $request->share . ' Contract Purchase TRX',
                        'charge' => 0,
                        'moneda' => $product->moneda,
                        'type' => 'sharetrx_buy',
                    ]);
                    
                     
                    $current_rank = CompenstionPlan::where('min_share', '<=', $request->share)->where('max_share', '>=', $request->share)->first();
                    if ($current_rank == null) {
                        $current_rank = CompenstionPlan::where('max_share', '<=', $request->share)->orderBy('max_share', 'desc')->first();
                    }
                    $details = $user->username . ' Buy ' . $request->share . ' Contracts TRX.';

                    if ($current_rank) {
                        $refer = User::find($user->ref_id);

                        // account_type = 1, network account. only net;work account get  referral Commission;

                        if ($refer && $current_rank->ref_bonus > 0 && $refer->account_type == 1 && $user->generate_com == 1) {
                            $amount = ($total_price * $current_rank->ref_bonus) / 100;
                            $amount = $amount;
                            referralComission_compensation($user->id, formatter_money($amount), $details,2);
                        }
                    }
                    if ($user->generate_com == 1) {
                      
                       $puntos = get_punto_trx($total_price);
                       updateBV($user->id, $puntos , $details); 
                    }
                    $notify[] = ['success', 'You have purchase Contracts TRX Successfully'];
                    return back()->withNotify($notify);
    }
    

    public function buyvip_trx(Request $request)
    {   
            
                    $this->validate($request, [
                        'share' => 'required|integer|min:1',
                        'user' => 'required|integer'
                    ]);

                    $user  = User::where("id",$request->user)->first();
                    $product = networkContract::where('moneda',2)->first();
                    $total_price = round($product->price * $request->share, 8);
                    $ab_share = $product->total_contract - $product->total_sell;
                    if ($ab_share < $request->share) {
                        $notify[] = ['error', 'Available Contracts = ' . $ab_share];
                        return back()->withNotify($notify);
                    }
                    
                   // $user = auth()->user();
                    $user->network_contracts_trx += $request->share;
                    $user->total_invest_trx += $total_price;
                    $user->save();
                    
                    $gnl = GeneralSetting::first();                
                    $max_earning = $total_price * $product->max_profit / 100;
                    $share = new  Share();
                    $share->user_id = $user->id;
                    $share->product_id = $product->id;
                    $share->total_share = $request->share;
                    $share->amount = $total_price;
                    $share->max_earning = $max_earning;
                    $share->type = 0;
                    $share->status = 3;
                    $share->start_date = Carbon::now()->addDays($product->pool_after);
                    $share->moneda = $product->moneda;
                    $share->save();

                    $product->total_sell += $request->share;
                    $product->save();
                    
             
                    $user->transactions()->create([
                        'trx' => getTrx(),
                        'user_id' => $user->id,
                        'amount' => trontoether($total_price),
                        'main_amo' => trontoether($total_price),
                        'amount_con' => $total_price,
                        'main_amo_con' => $total_price,
                        'balance' => 0,
                        'title' => $request->share . ' Contract Purchase TRX',
                        'charge' => 0,
                        'moneda' => $product->moneda,
                        'type' => 'sharetrx_buy',
                    ]);
                    
                     
                    $current_rank = CompenstionPlan::where('min_share', '<=', $request->share)->where('max_share', '>=', $request->share)->first();
                    if ($current_rank == null) {
                        $current_rank = CompenstionPlan::where('max_share', '<=', $request->share)->orderBy('max_share', 'desc')->first();
                    }
                    $details = $user->username . ' Buy ' . $request->share . ' Contracts TRX.';

                    if ($current_rank) {
                        $refer = User::find($user->ref_id);

                        // account_type = 1, network account. only network account get  referral Commission;

                        if ($refer &&  $refer->account_type == 1 && $user->generate_com == 1) {
                            $amount = ($total_price * $product->ref_bonus) / 100;
                            $amount = $amount;
                            referralComission_compensation($user->id, formatter_money($amount), $details,2);
                        }
                    }
                    if ($user->generate_com == 1) {
                        $puntos = get_punto_trx($total_price);
                       updateBV($user->id, $puntos , $details);
                    }
                    $notify[] = ['success', 'You have purchase Contracts TRX Successfully'];
                    return back()->withNotify($notify);
    }
    
    
    
    public function usdt_auto()
    {
                    set_time_limit(0);
                $date = Carbon::now()->toDateString();
                $valida = PoolInterest::where('moneda',3)->where('created_at', '>=', $date)->first();
                
                if($valida != null)
                {
                        return "Pool pagado con exito!!";
                }
                    
                $gnl = GeneralSetting::first();
                $porcentaje = $gnl->pool_interest_usdt;
                $total_share_eligible = eligible_usdt_sell();
                
                echo $total_share_eligible." <br>";
                
        
                $total_pagar = ((($total_share_eligible * 10)  * 0.7) * $porcentaje)/100;
                    
                if($total_pagar <= 0)
                {
                    $notify[] = ['error', 'No configuro el porcentaje'];
                    return  "configurar porcentaje a pagar";
                }

                if ($total_share_eligible == 0) {
                        $notify[] = ['error', 'No Eligible Share found yet'];
                        return redirect()->route('admin.pooltrx.interest')->withNotify($notify);;
                    }

                $per_share_profit = $total_pagar / $total_share_eligible;
                $pool = new PoolInterest();
                $pool->amount = $total_pagar;
                $pool->moneda = 3;
                $pool->total_distribution_share = $total_share_eligible;
                $pool->per_share_profit = round($per_share_profit, 4);
                $pool->porcentaje = $porcentaje;
                $pool->save(); 
                

                $shares = Share::where('moneda',3)->where('start_date', '<=', $date)->where('status', 1)->where('type',1)->get();

                if ($shares == null) {
                    $notify[] = ['error', 'No Eligible Share found yet'];
                    return 'No hay contractos';
                }
                
                    foreach ($shares as $share) {
                            
                        
                            $profit = $share->total_share * round($per_share_profit, 4);
                            $user = User::find($share->user_id);
                            $max_return_profit = formatter_money($share->return_profit + $profit);
                            $max_earning = formatter_money($share->max_earning);

                            if ($max_earning < $max_return_profit) {
                                $amount = $share->max_earning - $share->return_profit;
                                $share->status = 2;
                            } elseif ($max_earning >= $max_return_profit) {
                                $amount = $profit;
                            }
                        
                            $share->return_profit += $amount;
                            $share->save();
                            
                            cierra_paquete($share->id);

                        

                            $user->interest_wallet_usdt += ($amount);
                            $user->total_return_usdt += $amount;
                            $user->save();
                        
                            $trx = $user->transactions()->create([
                                'trx' => getTrx(),
                                'user_id' => $user->id,
                                'amount_con' => formatter_money($amount),
                                'main_amo_con' => formatter_money($amount),
                                'balance' => $user->interest_wallet_usdt,
                                'title' => 'Interest for ' . $share->total_share . ' shares',
                                'charge' => 0,
                                'moneda' => 3,
                                'type' => 'pool_interest',
                            ]);

                            

                                $teleg = new send_tele();
                                $teleg->user_id =   $user->id;
                                $teleg->amount  =   $amount;
                                $teleg->trx     =   $trx->trx;
                                $teleg->pool    =   $pool->id;
                                $teleg->balance =   $user->interest_wallet_usdt;
                                $teleg->share   =   $share->total_share;
                                $teleg->save();


                                    /*  
                                            send_tele($user, 'POOL_INTEREST_USDT', [
                                                'trx' => $trx->trx,
                                                'amount' => formatter_money($amount),
                                                'balance' => formatter_money($user->interest_wallet),
                                                'share' => $share->total_share,
                                            ]);

                                            send_sms($user, 'POOL_INTEREST_USDT', [
                                                'trx' => $trx->trx,
                                                'amount' => formatter_money($amount),
                                                'balance' => formatter_money($user->interest_wallet),
                                                'share' => $share->total_share,
                                            ]);

                                    */
                                
                                
                        }


        return "Pagado";

    }
    
    
            public function buy_usdt(Request $request)
            {
                $this->validate($request, [
                    'share' => 'required|integer|min:1',
                ]);
                
              //  Array ( [_token] => Hx8uynPutuHudHeC4xUWgJ17rQelq1FTF3tm6zdP [user] => 125177 [share] => 10 )
            
                $user =  User::where('id', $request->user)->first();
             
                $data_con                = $this->data_cont(1);
                $cantidad                = $request->share;
                $price                   = $data_con->price;
                $total_price             = $cantidad * $price;
                    
        
              /*  if($user->balance_usdt < $total_price)
                { 
                    $notify[] = ['error', 'Insufficient balance, Please deposit first'];
                    return redirect()->route('user.wallets.index')->withNotify($notify);
                } */


                $data['cant']           =   $cantidad;
                $data['price']          =   $price;
                $data['total_price']    =   $total_price;
                $data['producto']       =   $data_con;
                $data['moneda']         =   3;  
                $data['user']           =   $user;              
                $resu = (object)$data; 

                $this->contrato(1,$resu);
                 
                $notify[] = ['success', 'You have purchase Contracts Successfully'];
                return back()->withNotify($notify);       
            }


                    private function  contrato ($tipo, $request){
                        $gnl = GeneralSetting::first();
                        $user = $request->user;

                     //   $user->balance_usdt            -= $request->total_price;
                        if($tipo == 0)
                        $user->network_contracts_usdt   += $request->cant;
                        else
                        $user->shares_usdt             += $request->cant;
                        $user->total_invest_usdt       += $request->total_price;
                        $user->save();

                        
                        if($tipo == 1)
                            $max_earning = $request->total_price * $gnl->max_profit / 100;
                        else
                            $max_earning = $request->total_price * $request->producto->max_profit / 100;

                        $share = new  Share();
                        $share->user_id         = $user->id;
                        $share->product_id      = $request->producto->id;
                        $share->type            = $tipo;
                        $share->total_share     = $request->cant;
                        $share->price_share     = $request->price;
                        $share->price_dolar     = 1;
                        $share->moneda          = $request->moneda;
                        $share->amount          = $request->total_price;
                        $share->max_earning     = $max_earning;
                        $share->status          = 3;
                    
                        if($tipo == 1){
                            $share->status         = 1;
                            $share->start_date = Carbon::now()->addDays(5);
                        }
                    
                        $share->save();

                        if($tipo == 0) {
                                $title = "Buy ".$request->cant." USDT contract";
                                $details = $user->username . ' Buy ' . $request->cant . ' USDT Contracts.';
                        }

                        elseif($tipo==1){
                                $title = "Buy ".$request->cant." USDT contract";
                                $details = $user->username . ' Buy ' . $request->cant . ' USDT Contracts.';
                        }

                        trx_compra($user, $request->total_price, $title, $request->moneda);

                        $refer = User::find($user->ref_id);
                        
                        // valida que no se esta pagando el mismo binario
                      
                        $puede = $this->validar_patrocinador($user);


                        $inversion = Share::where('user_id', $user->id)->where('type',1)->count();
                        echo $puede."<br>";
                        if ($refer && $refer->account_type == 1 && $user->generate_com == 1 &&  $puede == 0) {
                            $amount = ($request->total_price * $request->producto->ref_bonus) / 100;
                                
                            echo "<br>".$amount;
                            referralComission_compensation($user->id, $amount, $details,3);
                        }

                        if ($user->generate_com == 1 &&  $puede == 0 ) {
                                $puntos = $request->total_price;
                                updateBV($user->id, $puntos, $details, $inversion);
                        }

                }

                    private function validar_patrocinador($user){

                    
                        $ref = User::where('id', $user->ref_id)->first();
                        
                        // validamos primero l a misma wallet

                        if($ref->wallet_tron  <> 41 or $user->wallet_tron <> 41){
                                    if($ref->wallet_tron == $user->wallet_tron){
                                        return 1;
                                    }
                        }

                        if($ref->chat_id  <> 0 or $user->chat_id <> 0){
                                    if($ref->chat_id == $user->chat_id){
                                        return 1;
                                    }
                        }

                        if($ref->identity  <> 0 or $user->identity <> 0){
                                    if($ref->identity == $user->identity){
                                        return 1;
                                    }
                        }

                        return 0;
                    }


                private function create_contrato($user, $data  ){
                            $share = new  Share();
                            $share->user_id         = $user->id;
                            $share->product_id      = $product->id;
                            $share->total_share     = $request->share;
                            $share->price_share     = $price;
                            $share->price_dolar     = 1;
                            $share->amount          = $total_price;
                            $share->max_earning     = $max_earning;
                                if($data ['tipo'] == 1){
                                    $share->start_date = Carbon::now()->addDays($gnl->pool_start);
                                }
                            $share->status = 1;
                            $share->save();

                            $product->total_sell += $request->share;
                            $product->save();
                    
                            $user->transactions()->create([
                                'trx' => getTrx(),
                                'user_id' => $user->id,
                                'amount_con' => $total_price,
                                'main_amo_con' => $total_price,
                                'balance_con' => $user->balance,
                                'price_dolar' => 1,
                                'moneda' => 3,
                                'title' => $request->share . ' Contract MN  Purchase USDT',
                                'charge' => 0,
                                'type' => 'share_buy_ustd',
                            ]);
                }

            private function update_contrato($tipo, $data, $cantidad){
                
            }

            

            private function data_cont($tipo){
                switch($tipo){
                    case 0:
                        return  NetworkContract::where('moneda',3)->first();         
                    break;
                    case 1:
                        return  Product::where('moneda',3)->first(); 
                    break;
                    default: return false;
                }
            }







}
