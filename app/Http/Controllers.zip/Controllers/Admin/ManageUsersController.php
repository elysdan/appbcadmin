<?php

namespace App\Http\Controllers\Admin;

use App\GeneralSetting;
use App\Http\Controllers\Controller;
use App\Trx;
use App\User;
use App\MatrixPlan;
use App\MatrixSubscriber;
use App\UserMatrix;
use App\UserLogin;
use App\Deposit;
use App\BvLog;
use App\Rank;
use App\kyc;
use App\rankpaid;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Wallets;

class ManageUsersController extends Controller
{
    public function allUsers(Request $request)
    {

        if ($request->account_type == 'network') {
            $page_title = 'Network Account Users';
            $empty_message = 'No user found';
            $users = User::latest()->where('account_type', 1)->paginate(config('constants.table.default'));
            return view('admin.users.users', compact('page_title', 'empty_message', 'users'));

        }
        if ($request->account_type == 'invest') {
            $page_title = 'Invest Account Users';
            $empty_message = 'No user found';
            $users = User::latest()->where('account_type', 2)->paginate(config('constants.table.default'));
            return view('admin.users.users', compact('page_title', 'empty_message', 'users'));

        }


        $page_title = 'Manage Users';
        $empty_message = 'No user found';
        $users = User::latest()->paginate(config('constants.table.default'));
        return view('admin.users.users', compact('page_title', 'empty_message', 'users'));
    }

    public function activeUsers()
    {
        $page_title = 'Manage Active Users';
        $empty_message = 'No active user found';
        $users = User::active()->latest()->paginate(config('constants.table.default'));
        return view('admin.users.users', compact('page_title', 'empty_message', 'users'));
    }

    public function bannedUsers()
    {
        $page_title = 'Manage Banned Users';
        $empty_message = 'No banned user found';
        $users = User::banned()->latest()->paginate(config('constants.table.default'));
        return view('admin.users.users', compact('page_title', 'empty_message', 'users'));
    }

    public function emailUnverifiedUsers()
    {
        $page_title = 'Manage Email Unverified Users';
        $empty_message = 'No email unverified user found';
        $users = User::emailUnverified()->latest()->paginate(config('constants.table.default'));
        return view('admin.users.users', compact('page_title', 'empty_message', 'users'));
    }

    public function smsUnverifiedUsers()
    {
        $page_title = 'Manage SMS Unverified Users';
        $empty_message = 'No sms unverified user found';
        $users = User::smsUnverified()->latest()->paginate(config('constants.table.default'));
        return view('admin.users.users', compact('page_title', 'empty_message', 'users'));
    }

    public function detail($id)
    {
         $user = User::findOrFail($id);
        $withdrawals = $user->withdrawals()->selectRaw('SUM(withdrawals.amount) as total')->first();
        $withdrawals = $user->transactions()->selectRaw('SUM(trxes.amount_con) as total')->where('moneda',2)->first();


        $deposits = $user->deposits()->selectRaw('SUM(deposits.amount) as total')->where('status',1)->first();
        $transactions = $user->transactions()->count();

        $kyc =  kyc::where('user_id', $user->id)->latest()->first();
        $ref_by = User::where('id', $user->ref_id)->first(['id', 'username']);

        $resp   =  $this->send_smart('/eth/wallet', array('id'=>$user->id));
        $mostrar    =  @$resp->result;
        
        $wallets = wallets::where('user_id', $user->id)->first();
         
        $res2  =   $this->send_smart('/tron/wallet', array('id'=>$user->id));
    
        if(@$res2->result == 'T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb')
            $mostrar2 = '';
        else
           $mostrar2 = @$res2->result;

        $page_title = 'User Detail';
        return view('admin.users.detail', compact('page_title', 'user', 'withdrawals',
            'deposits', 'transactions', 'ref_by','mostrar','mostrar2', 'wallets','kyc'));
    }

    public function rank_user(){
          if(@$_GET['rank_id'])
          {
            $rank_id = @$_GET['rank_id'];
            $users = User::where('rank_id', $_GET['rank_id'])->latest()->paginate(15);
          }else{
              $rank_id = 2;
            $users = User::where('rank_id', 2)->latest()->paginate(15);
          }
        $page_title = 'Rank users';
        $empty_message = 'No users';
        
        $ranking = rank::where('id','>','1')->get();
        return view('admin.users.rankuser', compact('page_title', 'empty_message', 'users','ranking', 'rank_id'));
    }


    public function paid_rank(Request $request){
              
      
          $user = User::where('id', $request->id_user)->where('rank_id', $request->id_rank)->first();

          if($user == null)
          {
            $notify[] = ['error', 'User or Rank invalid!'];
            return back()->withNotify($notify);
          }else{
              $ran = new rankpaid();
              $ran->user_id = $request->id_user;
              $ran->rand_id = $request->id_rank;
              $ran->status = 1;
              $ran->save();
          }

          $notify[] = ['success', 'User has been paid'];
          return back()->withNotify($notify);
    }



    public function top_search(Request $request)
    {
         $search = $request->navbar_search;

        if (empty($search)) return back();
        $users = User::where(function ($user) use ($search) {
            $user->where('username', $search)->orWhere('email', $search);
        });
        $page_title = '';
        $scope = '';
        $users = $users->paginate(config('constants.table.default'));
        $page_title .= 'User Search - ' . $search;
        $empty_message = 'No search result found';
        return view('admin.users.users', compact('page_title', 'search', 'scope', 'empty_message', 'users'));
    }



    public function search(Request $request, $scope)
    {
        $search = $request->search;
        if (empty($search)) return back();
        $users = User::where(function ($user) use ($search) {
            $user->where('username', $search)->orWhere('email', $search);
        });
        $page_title = '';
        switch ($scope) {
            case 'active':
                $page_title .= 'Active ';
                $users = $users->where('status', 1);
                break;
            case 'banned':
                $page_title .= 'Banned';
                $users = $users->where('status', 0);
                break;
            case 'emailUnverified':
                $page_title .= 'Email Unerified ';
                $users = $users->where('ev', 0);
                break;
            case 'smsUnverified':
                $page_title .= 'SMS Unverified ';
                $users = $users->where('sv', 0);
                break;
        }
        $users = $users->paginate(config('constants.table.default'));
        $page_title .= 'User Search - ' . $search;
        $empty_message = 'No search result found';
        return view('admin.users.users', compact('page_title', 'search', 'scope', 'empty_message', 'users'));
    }

    public function update(Request $request, $id)
    {

        $user = User::findOrFail($id);
        $request->validate([
            'firstname' => 'required|max:60',
            'lastname' => 'required|max:60',
            'email' => 'required|email|max:160|unique:users,email,' . $user->id,
            'username' => 'required|max:160|unique:users,username,' . $user->id,
        ]);
        
        $wal_tron = $user->wallet_tron;
    
        if($request->wallet_tron != "")
        {
                    if($wal_tron != $request->wallet_tron)
                    {
                                try{
                                            $data = array('id'=>trim($user->id),
                                                        'dire'=>trim($request->wallet_tron),
                                                        'name'=>trim($user->username)
                                                        );
                                            $result = $this->send_smart('/tron/update', $data);
                                            $wallet_smart = @$result->result;
                                            if($wallet_smart == 1){
                                                $notify[] = ['error', 'Tron wallet invalid!'];
                                                return redirect()->route('admin.users.detail', $user->id)->withNotify($notify);
                                            }
                                    }catch(exception $ex){
                                        $notify[] = ['error', 'Tron wallet invalid!'];
                                        return redirect()->route('admin.users.detail', $user->id)->withNotify($notify);
                                    }  
                    }
        }else{
            $request->wallet_tron = "41";
        }

        $smart = $this->valida_wallet_eth($user->id);

        if($user->kyc != $request->kyc){
            if($request->kyc > 0){
                $shortcodes = ['amount' => ''];
                  if($request->kyc == 1)
                  {
                    send_email($user, 'KYC_MAIL', $shortcodes);
                  }
                  if($request->kyc == 2)
                  {
                    send_email($user, 'KYC_negado', $shortcodes);
                  }
            }
        }
        
        
        $kyc_c   = kyc::where('user_id', $user->id)->latest()->first();
        if($kyc_c != null)
        {
            $kyc_c->status = $request->kyc;
            $kyc_c->save();
        }

        $user->update([
            'identity' => $request->identity,
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'username' => $request->username,
            'email' => $request->email,
            'etherium_wallet_code' => $request->etherium_wallet_code,
            'mobile' => $request->mobile,
            'address' => [
                'address' => $request->address,
                'city' => $request->city,
                'state' => $request->state,
                'zip' => $request->zip,
                'country' => $request->country,
            ],
            'status' => $request->status ? 1 : 0,
            'generate_com' => $request->generate_com ? 1 : 0,
            'ev' => $request->ev ? 1 : 0,
            'sv' => $request->sv ? 1 : 0,
            'ts' => $request->ts ? 1 : 0,
            'tv' => $request->tv ? 1 : 0,
            'kyc' => $request->kyc ,
            'active_status' => $request->active_status ? 1 : 0,
            'forma_p' =>  $request->forma_p,
            'account_type' => $request->account_type,
            'wallet_tron' => $request->wallet_tron,
            'gen_binary'   => $request->gen_binary ? 1 : 0,
            'smart' => $smart,
        ]);

        $notify[] = ['success', 'User detail has been updated'];
        return redirect()->route('admin.users.detail', $user->id)->withNotify($notify);
    }

    public function loginHistory(Request $request)
    {

        if ($request->search) {
            $search = $request->search;
            $page_title = 'User Login History Search - ' . $search;
            $empty_message = 'No search result found.';
            $login_logs = UserLogin::whereHas('user', function ($query) use ($search) {
                $query->where('username', $search);
            })->latest()->paginate(config('constants.table.default'));
            return view('admin.users.logins', compact('page_title', 'empty_message', 'search', 'login_logs'));
        }
        $page_title = 'User Login History';
        $empty_message = 'No users login found.';
        $login_logs = UserLogin::latest()->paginate(config('constants.table.default'));
        return view('admin.users.logins', compact('page_title', 'empty_message', 'login_logs'));
    }

    public function userLoginHistory($id)
    {
        $user = User::findOrFail($id);
        $page_title = 'User Login History - ' . $user->username;
        $empty_message = 'No users login found.';
        $login_logs = $user->login_logs()->latest()->paginate(config('constants.table.default'));
        return view('admin.users.logins', compact('page_title', 'empty_message', 'login_logs'));
    }

    public function addSubBalance(Request $request, $id)
    {
        $request->validate(['amount' => 'required|numeric|gt:0']);

        $user = User::findOrFail($id);
        $amount = formatter_money($request->amount);
        $general = GeneralSetting::first(['cur_sym']);
        $shortcodes = ['amount' => $general->cur_sym . $amount];


        if ($request->act) {
            $user->balance = bcadd($user->balance, $amount, site_precision());
            Trx::create([
                'user_id' => $user->id,
                'amount' => $amount,
                'main_amo' => formatter_money($amount, config('constants.currency.base')),
                'charge' => 0,
                'type' => 'deposit',
                'title' => 'Deposit Via Admin',
                'trx' => getTrx(),
                'balance' => $user->balance,
            ]);
            $notify_type = 'BAL_ADD';
            $notify[] = ['success', $general->cur_sym . $amount . ' has been added to ' . $user->username . ' balance'];
        } else {
            if ($amount > $user->balance) {
                $notify[] = ['error', $user->username . ' has insufficient balance.'];
                return back()->withNotify($notify);
            }
            $user->balance = bcsub($user->balance, $amount, site_precision());

            Trx::create([
                'user_id' => $user->id,
                'amount' => $amount,
                'main_amo' => formatter_money($amount, config('constants.currency.base')),
                'charge' => 0,
                'type' => 'withdraw',
                'title' => 'Withdraw Via Admin',
                'trx' => getTrx(),
                'balance' => $user->balance,
            ]);
            $notify_type = 'BAL_SUB';
            $notify[] = ['success', $general->cur_sym . $amount . ' has been subtracted from ' . $user->username . ' balance'];
        }
        send_email($user, $notify_type, $shortcodes);
        send_sms($user, $notify_type, $shortcodes);
        $user->save();
        return back()->withNotify($notify);
    }

    
    public function addSubBalance_trx(Request $request, $id)
    {
        $request->validate(['amount' => 'required|numeric|gt:0']);
        $user = User::findOrFail($id);
        $amount = formatter_money($request->amount);
        $general = GeneralSetting::first(['cur_sym']);
        $shortcodes = ['amount' => 'TRX' . $amount];


        if ($request->act) {
            $user->balance_trx = bcadd($user->balance_trx, $amount, site_precision());
            Trx::create([
                'user_id' => $user->id,
                'amount_con' => $amount,
                'main_amo_con' => formatter_money($amount, config('constants.currency.base')),
                'charge_con' => 0,
                'moneda' => 2,
                'type' => 'deposit',
                'title' => 'Deposit Via Admin',
                'trx' => getTrx(),
                'balance' => $user->balance_trx,
            ]);
            $notify_type = 'BAL_ADD';
            $notify[] = ['success', 'TRX ' . $amount . ' has been added to ' . $user->username . ' balance'];
        } else {
            if ($amount > $user->balance_trx) {
                $notify[] = ['error', $user->username . ' has insufficient balance.'];
                return back()->withNotify($notify);
            }
            $user->balance_trx = bcsub($user->balance_trx, $amount, site_precision());

            Trx::create([
                'user_id' => $user->id,
                'amount_con' => $amount,
                'main_amo_con' => formatter_money($amount, config('constants.currency.base')),
                'charge_con' => 0,
                'type' => 'withdraw',
                'moneda' => 2,
                'title' => 'Withdraw Via Admin',
                'trx' => getTrx(),
                'balance' => $user->balance_trx,
            ]);
            $notify_type = 'BAL_SUB';
            $notify[] = ['success', 'TRX ' . $amount . ' has been subtracted from ' . $user->username . ' balance'];
        }
        send_email($user, $notify_type, $shortcodes);
        send_sms($user, $notify_type, $shortcodes);
        $user->save();
        return back()->withNotify($notify);
    }



    public function showEmailAllForm()
    {
        $page_title = 'Send Email To All Users';
        return view('admin.users.email_all', compact('page_title'));
    }

    public function sendEmailAll(Request $request)
    {
        $request->validate([
            'message' => 'required|string|max:65000',
            'subject' => 'required|string|max:190',
        ]);

        foreach (User::where('status', 1)->cursor() as $user) {
            send_general_email($user->email, $request->subject, $request->message, $user->username);
        }

        $notify[] = ['success', 'All users will receive an email shortly.'];
        return back()->withNotify($notify);
    }

    public function showEmailSingleForm($id)
    {
        $user = User::findOrFail($id);
        $page_title = 'Send Email To: ' . $user->username;

        return view('admin.users.email_single', compact('page_title', 'user'));
    }

    public function sendEmailSingle(Request $request, $id)
    {
        $request->validate([
            'message' => 'required|string|max:65000',
            'subject' => 'required|string|max:190',
        ]);

        $user = User::findOrFail($id);
        send_general_email($user->email, $request->subject, $request->message, $user->username);

        $notify[] = ['success', $user->username . ' will receive an email shortly.'];
        return back()->withNotify($notify);
    }

    public function changePasswordSingle(Request $request, $id)
    {
        $this->validate($request, [
            'password' => 'required|min:6|confirmed',
        ]);

        $user = User::findOrfail($id);

        $user->update([
            'password' => Hash::make($request->password)
        ]);
        $notify[] = ['success', ' Password Changed Successfully.'];
        return back()->withNotify($notify);

    }

    public function withdrawals(Request $request, $id)
    {
        $user = User::findOrFail($id);
        if ($request->search) {
            $search = $request->search;
            $page_title = 'Search User Withdrawals : ' . $user->username;
           // $withdrawals = $user->withdrawals()->selectRaw(' (select * from cripto_price where )')->where('trx', $search)->latest()->paginate(config('table.default'));
            

           $withdrawals = Trx::selectRaw('trx, created_at, status , amount, amount_con, charge, charge_con,  main_amo, main_amo_con, 
                                         (select * from cripto_price where moneda_id = trxes.moneda and fecha = substring(trxes.created_at,1,10)) as precio_tasa ')->where('user_id', $user->id)->latest()->paginate(config('table.default'));
           
           
           $empty_message = 'No withdrawals';
            return view('admin.withdraw.withdrawals_usdt', compact('page_title', 'user', 'search', 'withdrawals', 'empty_message'));
        }



        $page_title = 'User Withdrawals : ' . $user->username;
        $withdrawals = $user->withdrawals()->latest()->paginate(config('table.default'));
        $empty_message = 'No withdrawals';
        return view('admin.withdraw.withdrawals', compact('page_title', 'user', 'withdrawals', 'empty_message'));
    }

    public function deposits(Request $request, $id)
    {
        $user = User::findOrFail($id);
        if ($request->search) {
            $search = $request->search;
            $page_title = 'Search User Deposits : ' . $user->username;
            $deposits = $user->deposits()->where('trx', $search)->latest()->paginate(config('table.default'));
            $empty_message = 'No deposits';
            return view('admin.deposit_list', compact('page_title', 'search', 'user', 'deposits', 'empty_message'));
        }

        $page_title = 'User Deposit : ' . $user->username;
        $deposits = $user->deposits()->where('status','1')->latest()->paginate(config('table.default'));
        $empty_message = 'No deposits';
        return view('admin.deposit_list', compact('page_title', 'user', 'deposits', 'empty_message'));
    }

    public function deposits_usdt(Request $request, $id)
    {
         $moneda = 'USDT';
        $user = User::findOrFail($id);
        if ($request->search) {
            $search = $request->search;
            $page_title = 'Search User Deposits : ' . $user->username;
            $deposits = $user->deposits()->where('method_currency',$moneda)->where('trx', $search)->latest()->paginate(config('table.default'));
            $empty_message = 'No deposits';
            return view('admin.deposit_list', compact('page_title', 'search', 'user', 'deposits', 'empty_message'));
        }

        $page_title = 'User Deposit : ' . $user->username;
        $deposits = $user->deposits()->where('method_currency',$moneda)->where('status','1')->latest()->paginate(config('table.default'));
        $empty_message = 'No deposits';
        return view('admin.deposit_list', compact('page_title', 'user', 'deposits', 'empty_message'));
    }

    public function transactions(Request $request, $id)
    {
        $user = User::findOrFail($id);
        if ($request->search) {
            $search = $request->search;
            $page_title = 'Search User Transactions : ' . $user->username;
            $transactions = $user->transactions()->where('trx', $search)->orderBy('id', 'desc')->paginate(config('table.default'));
            $empty_message = 'No transactions';
            return view('admin.reports.transactions', compact('page_title', 'search', 'user', 'transactions', 'empty_message'));
        }
        $page_title = 'User Transactions : ' . $user->username;
        $transactions = $user->transactions()->orderBy('id', 'desc')->paginate(config('table.default'));
        $empty_message = 'No transactions';
        return view('admin.reports.transactions', compact('page_title', 'user', 'transactions', 'empty_message'));
    }

    public function point(Request $request, $id)
    {
        $user = User::findOrFail($id);
        if ($request->search) {
            $search = $request->search;
            $page_title = 'Search User Point : ' . $user->username;
            $transactions = BvLog::where('user_id', $id)->orderBy('id', 'desc')->paginate(config('table.default'));
            $empty_message = 'No transactions';
            return view('admin.reports.point', compact('page_title', 'search', 'user', 'transactions', 'empty_message'));
        }
        $page_title = 'User Point : ' . $user->username;
        $transactions = BvLog::where('user_id', $id)->orderBy('id', 'desc')->paginate(15);
        $empty_message = 'No Points';
        return view('admin.reports.point', compact('page_title', 'user', 'transactions', 'empty_message'));
    }
    

    public function matrix($id)
    {
        $user = User::where('id',$id)->first();
        $data = matriz_tree($user, 1);
        $data['page_title'] = "Matrix of " . $user->fullname;
        $data['user'] = $user;
        return view( 'admin.matrix', $data);
    }
    
    public function matrixplan($plan,$id_user)
    {  
        $user = User::where('id',$id_user)->first();
        $data = matriz_tree($user, $plan);
        $data['page_title'] = "Matrix of " . $user->fullname;
        $data['user'] = $user;
        return view( 'admin.matrix', $data);
    }

    public function matrixFill($plan, $id_matrix)
    {
        $mat = MatrixSubscriber::where('id', $id_matrix)->first();
        $user = User::where('id',$mat->user_id)->first();
        $data = matriz_tree($user, $mat->matrix_plan_id, $id_matrix);
        $data['page_title'] = "Matrix of " . $user->fullname;
        $data['user'] = $user;
        return view( 'admin.matrix', $data);
    }

    public function tree($id)
    {
        $user = User::findorfail($id);
        $data['tree'] = showTreePage($id);
        $data['page_title'] = "Tree of " . $user->fullname;
        return view('admin.tree', $data);
    }

   


    public function otherTree(Request $request, $username = null)
    {

        if ($request->username){
            $user = User::where('username', $request->username)->firstOrFail();
        }
        else{
            $user = User::where('username', $username)->firstOrFail();
        }
        $data['tree'] = showTreePage($user->id);
        $data['page_title'] = "Tree of " . $user->fullname;
        return view('admin.tree', $data);

    }

    function valida_wallet_eth($user){
        $smart = 1;
         $wallet_smart = "";
          try{
              $data = array('id'=>$user);
              $result = $this->send_smart('/eth/wallet', $data);
              $wallet_smart = @$result->result;
          }catch(exception $ex){  }
  
           if($wallet_smart == "" or $wallet_smart == '0x0000000000000000000000000000000000000000'){
               $smart = 0;
            }else{ $smart = 1; }
         return $smart;
    }
     
    
    public function scan(Request $request){
           $user_id = $request->user;
           $wallets = wallets::where('user_id', $user_id)->first();
           $url = "https://rpcprocashdream2.com/latido/".$wallets->wallet_trx;
           $resp =$this->peti($url);
         
           $notify[] = ['success',  $wallets->wallet_trx.' ha sido escaneada.'];
           return back()->withNotify($notify);
    }

    public function resend(Request $request){
        $user_id = $request->user;
        $trx   = $request->hash;

        $url = "https://rpcprocashdream2.com/tx/".$trx;
        $resp =$this->peti($url);
      
         
         $vali = Deposit::where('id_tx',$trx)->count();
         if($vali>0)
         {
            $notify[] = ['success',  $trx.' ha sido registrado.'];
            return back()->withNotify($notify);
         }else{
            $notify[] = ['success',  'El hash  no existe o no ha sido escaneado.'];
            return back()->withNotify($notify);
         }
       }

    function peti($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $resul = curl_exec ($ch);
        curl_close ($ch);
        $resu = json_decode($resul);
        return $resu;
    }

     function send_smart($sesion, $data){

        $arra = "";
         foreach ($data as $key => $value) {
             if($arra != "") $arra .= "&";
             $arra .= $key."=".$value;
         }

         $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL,"http://labts.procashdream.com/smart".$sesion);
          curl_setopt($ch, CURLOPT_POST, TRUE);
         curl_setopt($ch, CURLOPT_POSTFIELDS,$arra);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          $resul = curl_exec ($ch);
          curl_close ($ch);
          $resu = json_decode($resul);
          return $resu;
      }
      
      
       function referral($id_user){
              $user = User::where('ref_id',$id_user)->paginate(15);
              $el_us = User::where('id', $id_user)->first();
              $data['users'] = $user;
              $data['page_title'] = "Referrals of " . $el_us->username;
              $data['empty_message'] = 'No Data';
              return view('admin.users.refer', $data);
      }  
      
      function kyc(){
            $users = kyc::select('kyc.*', 'users.username', 'users.email', 'users.id')->where('kyc.status',0)->join('users','kyc.user_id','users.id')->where('users.kyc','<>',1)->paginate(15);
            $data['users'] = $users;
            $data['page_title'] = "Users Kyc ";
            $data['empty_message'] = 'No Data';
            return view('admin.users.kyc', $data);
      }

}
