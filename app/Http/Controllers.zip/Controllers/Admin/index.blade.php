@extends('admin.layouts.app')

@section('panel')
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script>
	res = "false"
	 $(document).ready(function(){

		    $('#data_sele_pri').change(function() {
                res = $(this).prop("checked");
                res =  res.toString();
                if(res == 'false')
                   $(".data_sele").bootstrapToggle('off')
                else
                   $(".data_sele").bootstrapToggle('on')

                   total_retiro();
		    })




	 });

     function total_retiro(){
            alert("hice click");
        $("#tab_w tbody tr").each(function(index, fila) {

            obj = $(this);
            $(obj + " div")
           // alert(fila.children[0].innerHTML);

           valor = $(obj + " div").html();
           alert(valor);
                 return;
        });

        return total;
     }

</script>
<div class="row">

	<div class="col-lg-12">

    <button class="boton" onclick="total_retiro()">Ok</button>

    <div class="row">
                         <!--   <div class="col-4">
                            <span>Saldo Wallet</span>
                            <br>
                            çç
                           {{@saldo_wallet}}
                            </div>-->
                            <div class="col-4 text-left bold " style="color:#fff; font-weight:bold">
                            <h5>Saldo Contracto
                             ETH  {{$saldo_contracto}}
                             </h5>
                            </div>
                            <div class="col-4"></div>
                            <div class="col-4 text-right bold" style="color:#fff; font-weight:bold">
                            <h6>Monto retirar
                            <input type="text" class="form-control" style="border:1px solid #c9c9c9" value="0">
                            </h6>
                            </div>
                    </div>
		<div class="card">
                <div class="container">

                 </div>

			<form action="{{route('admin.withdraw.request.store')}}" method="post">
				@csrf

				<div class="table-responsive table-responsive-xl">
					<table id="tab_w" class="table align-items-center table-light tab_w">
						<thead>
							<tr>
								<th scope="col"> <input type="checkbox" id='data_sele_pri' data-toggle="toggle" data-on="SEND" data-off="NO" data-onstyle="success" data-offstyle="danger" > </th>
								<th scope="col">User</th>
								<th scope="col">Balance</th>
								<th scope="col">Withdrawable</th>
								<th scope="col">Charge</th>
								<th scope="col">User will get</th>
								<th scope="col">After Balance</th>
							</tr>
						</thead>
						<tbody class="list">
							@foreach($withdraws as $wd)
							<tr>
								<td scope="col">
									<input type="checkbox" class='data_sele' data-width="100" data-onstyle="success" data-offstyle="danger"
									data-toggle="toggle" data-on="SEND" data-off="NO" name="user[{{$wd->id}}]" >
								</td>
								<td scope="col">
									<a href="{{ route('admin.users.detail', $wd->id) }}" class="avatar avatar-sm rounded-circle mr-3">{{ $wd->username }}</a>

								</td>
								<td scope="col" class="lead font-weight-bold">{{@$wd->interest_wallet +0 }} {{@$general->cur_text}}</td>


								@php
								if ($method->max_limit < $wd->interest_wallet){
	    							$wdamo = $method->max_limit;
								}else{
    								$wdamo = $wd->interest_wallet;
								}
								$charge = formatter_money($method->fixed_charge + ($wdamo * $method->percent_charge / 100));
								@endphp


								<td scope="col">{{$wdamo +0 }} {{$general->cur_text}}</td>
								<td scope="col">{{$charge +0 }} {{$general->cur_text}}</td>
								<td scope="col" class="lead font-weight-bold text-danger">{{$wdamo - $charge}} {{$general->cur_text}}</td>
								<td scope="col" class="lead font-weight-bold text-success">{{$wd->interest_wallet - $wdamo}} {{$general->cur_text}}</td>
                            </tr>
							@endforeach


						</tbody>
					</table>
				</div>
 <div class="card-footer py-4">
                    <nav aria-label="...">
                        {{ $withdraws->links() }}
                    </nav>
                </div>


				<div class="m-5">
					<button type="submit" class="btn btn-success btn-block btn-lg"> CREATE WITHDRAWAL</button>
				</div>

			</form>

		</div>

	</div>
</div>

@endsection
