<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\Deposit;
use App\GeneralSetting;
use App\MatrixPlan;
use App\Plan;
use App\PoolInterest;
use App\Share;
use App\Trx;
use Carbon\Carbon;
use Carbon\CarbonTimeZone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use App\User;
use App\pop;
use App\Ticket;
use App\UserLogin;
use App\Withdrawal;

class AdminController extends Controller
{

    public function dashboard(Request $request)
    {
            
         
   
        $page_title = 'Dashboard';
            $fecha = \Carbon\Carbon::now()->subYear();
             

    /* $user_login_data = UserLogin::whereYear('created_at', '>=', $fecha )->get(['browser', 'os', 'country']);
   
            
        $chart['user_browser_counter'] = $user_login_data->groupBy('browser')->map(function ($item, $key) {
            return collect($item)->count();
        });
        
          

        $chart['user_os_counter'] = $user_login_data->groupBy('os')->map(function ($item, $key) {
            return collect($item)->count();
        });
        
       

        $chart['user_country_counter'] = $user_login_data->groupBy('country')->map(function ($item, $key) {
            return collect($item)->count();
        })->sort()->reverse()->take(5);
       */
       
       $user_login_data = UserLogin::whereYear('created_at', '>=', $fecha );
            
        $chart['user_browser_counter'] = $user_login_data->SelectRaw('count(browser), browser')->groupBy('browser')->get();
     //   
         $chart['user_os_counter'] = $user_login_data->SelectRaw('count(os), os')->groupBy('os')->get();
        
         $chart['user_country_counter'] = $user_login_data->SelectRaw('count(country), country')->groupBy('country')->get();
          
        $widget['total_users'] = User::all('sv', 'ev', 'status', 'balance');
        
        
                 
        
        
        
        $widget['withdrawals'] = Withdrawal::where('status', 1)->where('currency','ETH')->selectRaw('COUNT(*) as total, SUM(charge) as total_charge')->selectRaw('SUM(amount) as total_amount')->first();
        $widget['withdrawals_trx'] = Trx::where('moneda','2')->where('type','withdraw')->selectRaw('COUNT(*) as total, SUM(charge_con) as total_charge')->selectRaw('SUM(amount_con) as total_amount')->first();

        $widget['ref_com'] = Trx::where('type', 'referral_commision')->sum('amount');
        $widget['binary_com'] = Trx::where('type', 'binary_comission')->sum('amount');
        $widget['residual_bonus'] = Trx::where('type', 'residual_bonus')->sum('amount');
        $widget['residual_bonus'] = Trx::where('type', 'residual_bonus')->sum('amount');
        $widget['deposito_rs'] = Trx::where('type', 'deposit_rs')->sum('amount');

        $widget['matrix_bonus'] = Trx::where('type', 'matrix_commission')->where('moneda',1)->sum('amount');
        $widget['matrix_bonus_trx'] = Trx::where('type', 'matrix_commission')->where('moneda',2)->sum('amount_con');

        $widget['interest'] = PoolInterest::where('moneda',1)->sum('amount');
        $widget['interest_trx'] = PoolInterest::where('moneda',2)->sum('amount');

        $widget['tickets'] = Ticket::selectRaw('COUNT(*) as total, sum(price) as amount')->first();
        $widget['depo_eth'] = Deposit::where('status', 1)->where('created_at','>', '2020-12-22')->where('method_currency', 'ETH')->sum('amount');
        $widget['depo_btc'] = Deposit::where('status', 1)->where('created_at','>', '2020-12-22')->where('method_currency', 'BTC')->sum('amount');
        $widget['depo_trx'] = Deposit::where('status', 1)->where('created_at','>', '2020-12-22')->where('method_currency', 'TRX')->sum('amount');

        $widget['depo_count'] = Deposit::where('status', 1)->count();
       
        return view('admin.dashboard', compact('page_title', 'chart', 'widget'));
    }

    public function pop_index(){
        $page_title = 'Popup';
        $admin      = Auth::guard('admin')->user();
        $pop   =  pop::first();
        return view('admin.pop', compact('page_title', 'admin', 'pop'));
    }

    public function pop_save(Request $request){
           $pop = pop::first();

           $pop->status = $request->status;
           $pop->titulo  = $request->titulo_noticia;
           $pop->mensaje = $request->notice;
           $pop->save();
           $notify[] = ['success', 'Pop has been update'];
           return back()->withNotify($notify);
    }

    public function profile()
    {
        $page_title = 'Profile';
        $admin = Auth::guard('admin')->user();
        return view('admin.profile', compact('page_title', 'admin'));
    }

    public function profileUpdate(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email',
            'image' => 'nullable|image|mimes:jpg,jpeg,png'
        ]);

        $user = Auth::guard('admin')->user();

        if ($request->hasFile('image')) {
            try {
                $old = $user->image ?: null;
                $user->image = upload_image($request->image, config('constants.admin.profile.path'), config('contants.admin.profile.size'), $old);
            } catch (\Exception $exp) {
                $notify[] = ['error', 'Image could not be uploaded.'];
                return back()->withNotify($notify);
            }
        }

        $user->name = $request->name;
        $user->email = $request->email;
        $user->save();
        $notify[] = ['success', 'Your profile has been updated.'];
        return redirect()->route('admin.profile')->withNotify($notify);
    }

    public function passwordUpdate(Request $request)
    {
        $this->validate($request, [
            'old_password' => 'required',
            'password' => 'required|min:6|confirmed',
        ]);

        $user = Auth::guard('admin')->user();
        if (!Hash::check($request->old_password, $user->password)) {
            $notify[] = ['error', 'Password Do not match !!'];
            return back()->withErrors(['Invalid old password.']);
        }
        $user->update([
            'password' => bcrypt($request->password)
        ]);
        return redirect()->route('admin.profile')->withSuccess('Password Changed Successfully');
    }


    public function plan()
    {
        $page_title = 'MLM Plans';
        $empty_message = 'No Plan found';
        $plans = Plan::paginate(config('constants.table.default'));
        return view('admin.mlm_plan', compact('page_title', 'plans', 'empty_message'));
    }

    public function planCreate(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'amount' => 'required|min:0',
            'bv' => 'required|min:0|integer',
            'ref_com' => 'required|min:0',
            'com_to_tree' => 'required|min:0',
        ]);


        $plan = new Plan();
        $plan->name = $request->name;
        $plan->amount = $request->amount;
        $plan->bv = $request->bv;
        $plan->ref_com = $request->ref_com;
        $plan->com_to_tree = $request->com_to_tree;
        $plan->status = $request->status;
        $plan->save();

        $notify[] = ['success', 'New MLM Plan create successfully'];
        return back()->withNotify($notify);
    }


    public function planUpdate(Request $request)
    {
        $this->validate($request, [
            'id' => 'required',
            'name' => 'required',
            'amount' => 'required|min:0',
            'bv' => 'required|min:0|integer',
            'ref_com' => 'required|min:0',
            'com_to_tree' => 'required|min:0',
        ]);


        $plan = Plan::find($request->id);
        $plan->name = $request->name;
        $plan->amount = $request->amount;
        $plan->bv = $request->bv;
        $plan->ref_com = $request->ref_com;
        $plan->com_to_tree = $request->com_to_tree;
        $plan->status = $request->status;
        $plan->save();

        $notify[] = ['success', 'MLM Plan has been updated.'];
        return back()->withNotify($notify);
    }


    public function matchingIndex()
    {
        $page_title = 'Cron Job';

        return view('admin.matching_bonus', compact('page_title'));
    }

    public function matchingUpdate(Request $request)
    {
        $this->validate($request, [
            'bv_price' => 'required|min:0',
            'total_bv' => 'required|min:0|integer',
            'max_bv' => 'required|min:0|integer',


        ]);




        $setting = GeneralSetting::first();

        if ($request->matching_bonus_time == 'daily') {
          $when = $request->daily_time;
        } elseif ($request->matching_bonus_time == 'weekly') {
            $when = $request->weekly_time;
        } elseif ($request->matching_bonus_time == 'monthly') {
            $when = $request->monthly_time;
        }


        $setting->bv_price = $request->bv_price;
        $setting->total_bv = $request->total_bv;
        $setting->max_bv = $request->max_bv;
        $setting->cary_flash = $request->cary_flash;
        $setting->matching_bonus_time = $request->matching_bonus_time;

        $setting->matching_when = $when;
        $setting->save();

        $notify[] = ['success', 'Matching bonus has been updated.'];
        return back()->withNotify($notify);

    }


    public function staffIndex()
    {
        $page_title = "Manage Staff";
        $staffs = Admin::where('role', 1)->orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        return view('admin.staff.all_staff', compact('page_title', 'staffs'));
    }



    public function storeStaff(Request $request)
    {
        $this->validate($request,[
            'name' => 'required',
            'username' => 'required|alpha_dash|unique:admins,username',
            'email' => 'required|email|max:191|unique:admins,email',
            'password' => 'nullable|min:5',
            'status' => 'required'
        ]);


        $item = new Admin();
        $item->name = $request->name;
        $item->username = $request->username;
        $item->email = $request->email;
        $item->mobile = $request->mobile;
        if(isset($request->password)){
            $item->password = Hash::make($request->password);
        }
        $item->role = 1;
        $item->status = $request->status;
        $item->save();

        $notify[] = ['success', 'Added Successfully.'];
        return back()->withNotify($notify);
    }


    public function updateStaff(Request $request, $id)
    {
        $this->validate($request,[
            'name' => 'required',
            'username' => 'required|alpha_dash|unique:admins,username,'.$id,
            'email' => 'required|email|max:191|unique:admins,email,'.$id,
            'password' => 'nullable|min:5',
            'status' => 'required'
        ]);

        $item = Admin::findOrFail($id);
        $item->name = $request->name;
        $item->username = $request->username;
        $item->email = $request->email;
        $item->mobile = $request->mobile;
        $item->role = 1;
        if(isset($request->password)){
            $item->password = Hash::make($request->password);
        }
        $item->status = $request->status;
        $item->save();
        $notify[] = ['success', 'Updated Successfully.'];
        return back()->withNotify($notify);
    }


    public function matrixPlan()
    {
        $page_title = 'Matrix Plans';
        $empty_message = 'No Plan found';
        $plans = MatrixPlan::paginate(config('constants.table.default'));
        return view('admin.matrixPlan.index', compact('page_title', 'plans', 'empty_message'));
    }

     public function matrixPlanCreate()
    {
        $page_title = 'Matrix Plan Create';
        return view('admin.matrixPlan.create', compact('page_title' ));
    }

  public function matrixPlanEdit($id)
    {
        $page_title = 'Matrix Plan Edit';
        $plan = MatrixPlan::findOrfail($id);
        return view('admin.matrixPlan.edit', compact('page_title', 'plan' ));
    }



    public function matrixPlanPost(Request $request)
    {


        $this->validate($request, [
            'name' => 'required|string',
            'description' => 'string',
        ]);

        $plan = new MatrixPlan();
        $plan->name = $request->name;
        $plan->description = $request->description;
        $plan->save();

        $notify[] = ['success', 'New matrix Plan created successfully'];
        return back()->withNotify($notify);
    }

    public function matrixPlanUpdate(Request $request)
    {

        $this->validate($request, [
            'name' => 'required|string',
            'price' => 'required|numeric|min:0',
            'description' => 'string',
        ]);

        $plan = MatrixPlan::findOrfail($request->id);
        $plan->name = $request->name;
        $plan->price = $request->price;
        $plan->description = $request->description;
        $plan->save();

        $notify[] = ['success', 'New matrix Plan updated successfully'];
        return back()->withNotify($notify);

    }
    
 



}
