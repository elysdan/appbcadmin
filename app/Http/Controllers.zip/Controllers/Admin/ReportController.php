<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\PoolInterest;
use App\Share;
use App\NetworkContract;
use App\Trx;
use App\Product;
use App\BvLog;
use App\User;
use App\DB;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function transaction()
    {
        $page_title = 'Transaction Logs';
        $transactions = Trx::with('user')->orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        $empty_message = 'No transactions.';
        return view('admin.reports.transactions', compact('page_title', 'transactions', 'empty_message'));
    }

    public function point()
    {
        $page_title = 'Point Logs';
        $transactions = BvLog::with('user')->latest()->paginate(15);
        $empty_message = 'No Point.';
        return view('admin.reports.point', compact('page_title', 'transactions', 'empty_message'));
    }

    public function interest( Request $request)
    {

        if ($request->user_id)
        {
            $user = User::findorfail($request->user_id);
            if ($user)
            {
                $page_title = 'Binary Commission Logs | ' .$user->username;
                $transactions = Trx::where('user_id', $user->id)->where('type', 'pool_interest')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
            }
        }else{
            $page_title = 'Interest Logs';
            $transactions = Trx::where('type', 'pool_interest')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
        }


        $empty_message = 'No transactions.';
        return view('admin.reports.transactions', compact('page_title', 'transactions', 'empty_message'));
    }

    public function interest_trx( Request $request)
    {

        if ($request->user_id)
        {
            $user = User::findorfail($request->user_id);
            if ($user)
            {
                $page_title = 'Binary Commission Logs | ' .$user->username;
                $transactions = Trx::where('user_id', $user->id)->where('moneda',2)->where('type', 'pool_interest')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
            }
        }else{
            $page_title = 'Interest Logs';
            $transactions = Trx::where('moneda',2)->where('type', 'pool_interest')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
        }


        $empty_message = 'No transactions.';
        return view('admin.reports.transactions', compact('page_title', 'transactions', 'empty_message'));
    }

     


    public function ref_com( Request $request)
    {

        if ($request->user_id)
        {
            $user = User::findorfail($request->user_id);
            if ($user)
            {
                $page_title = 'Referral Commission Logs | ' .$user->username;
                $transactions = Trx::where('user_id', $user->id)->where('type', 'referral_commision')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
            }
        }else{
            $page_title = 'Referral Commission Logs';
            $transactions = Trx::where('type', 'referral_commision')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
        }

        $empty_message = 'No transactions.';
        return view('admin.reports.transactions', compact('page_title', 'transactions', 'empty_message'));
    }

        public function binary_com( Request $request)
    {

        if ($request->user_id)
        {
            $user = User::findorfail($request->user_id);
            if ($user)
            {
                $page_title = 'Binary Commission Logs | ' .$user->username;
                $transactions = Trx::where('user_id', $user->id)->where('type', 'binary_comission')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
            }
        }else{
            $page_title = 'Binary Commission Logs';
            $transactions = Trx::where('type', 'binary_comission')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
        }

        $empty_message = 'No transactions.';
        return view('admin.reports.transactions', compact('page_title', 'transactions', 'empty_message'));
    }
    
    public function deposit_rs_com(Request $request)
    {
        if ($request->user_id)
        {
            $user = User::findorfail($request->user_id);
            if ($user)
            {
                $page_title = 'Matrix Commission Logs | ' .$user->username;
                $transactions = Trx::where('user_id', $user->id)->where('type', 'matrix_commission')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
            }
        }else{
            $page_title = 'Matrix Commission Logs';
            $transactions = Trx::where('type', 'matrix_commission')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
        }

        $empty_message = 'No transactions.';
        return view('admin.reports.transactions', compact('page_title', 'transactions', 'empty_message'));
    }



        public function residual_com( Request $request)
    {

        if ($request->user_id)
        {
            $user = User::findorfail($request->user_id);
            if ($user)
            {
                $page_title = 'Residual Commission Logs | ' .$user->username;
                $transactions = Trx::where('user_id', $user->id)->where('type', 'residual_bonus')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
            }
        }else{
            $page_title = 'Residual Commission Logs';
            $transactions = Trx::where('type', 'residual_bonus')->orderBy('id', 'DESC')->with('user')->paginate(config('constants.table.default'));
        }

        $empty_message = 'No transactions.';
        return view('admin.reports.transactions', compact('page_title', 'transactions', 'empty_message'));
    }
     
 

    public function transactionSearch(Request $request)
    {
        $search = $request->search;
        $page_title = 'Transactions Search - ' . $search;
        $empty_message = 'No transactions.';
        $transactions = Trx::with('user')->whereHas('user', function ($user) use ($search) {
            $user->where('username', $search);
        })->orWhere('trx', $search)->orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        return view('admin.reports.transactions', compact('page_title', 'transactions', 'empty_message'));
    }

    public function shares()
    {
        $user = User::findorfail(1);
        $page_title = 'Shares Sell Logs';
        $product = NetworkContract::where("moneda",1)->first();
        $shares = Share::with(['product', 'user'])->orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        $moneda = 1;
        return view('admin.reports.share', compact('page_title', 'shares','user','moneda','product'));
    }

    public function sharesDateUpdate(Request $request)
    {
        $this->validate($request, [
            'id' => 'required|integer',
            'date' => 'required',
        ]);

        $data = Share::find($request->id);
        $data->start_date = $request->date;
        $data->save();

        $notify[] = ['success', 'updated Successfully.'];
        return back()->withNotify($notify);
    }

     public function singleShares($id)
    {
        $user = User::findorfail($id);
        $page_title = $user->username . ' Shares Logs';
        $shares = Share::where('user_id', $id)->where('moneda',1)->with(['product', 'user'])->orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        $product = NetworkContract::where("moneda",2)->first();
        $moneda = 1;
        return view('admin.reports.share', compact('page_title', 'shares','product','user', 'moneda'));
    }

    public function singleShares_trx($id)
    {
        $user = User::findorfail($id);
        $page_title = $user->username . ' Shares TRX Logs';
        $shares = Share::where('user_id', $id)->where('moneda',2)->with(['NetworkContract', 'user'])->orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        $total_vip  = Share::where('user_id', $id)->where('type',0)->where('moneda',2)->count();
        $total_mn  = Share::where('user_id', $id)->where('type',1)->where('moneda',2)->count();
        $product = Product::where("moneda",2)->first();
        $network_contract = NetworkContract::where("moneda",2)->first();
        $moneda = 2;
        return view('admin.reports.share', compact('page_title', 'shares', 'product','network_contract','user','moneda','total_vip','total_mn'));
    }

    public function singleShares_usdt($id)
    {
        $user = User::findorfail($id);
        $page_title = $user->username . ' Shares USDT Logs';
        $shares = Share::where('user_id', $id)->where('moneda',3)->with(['NetworkContract', 'user'])->orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        $total_vip  = Share::where('user_id', $id)->where('type',0)->where('moneda',3)->count();
        $total_mn  = Share::where('user_id', $id)->where('type',1)->where('moneda',3)->count();
        $product = Product::where("moneda",3)->first();
        $network_contract = NetworkContract::where("moneda",3)->first();
        $moneda = 3;
        return view('admin.reports.share', compact('page_title', 'shares', 'product','network_contract','user','moneda','total_vip','total_mn'));
    }

    public function singleShares_trx_auditor(){
        $user = User::findorfail(2);
        $page_title = ' Shares TRX Logs';
        $shares = Share::where('id_tx', '0')->where('moneda',2)->orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        $total_vip  = Share::where('id_tx', 0)->where('type',0)->where('moneda',2)->count();
        $total_mn  = Share::where('id_tx', 0)->where('type',1)->where('moneda',2)->count();
        $product = Product::where("moneda",2)->first();
        $network_contract = NetworkContract::where("moneda",2)->first();
        $moneda = 1;
        return view('admin.reports.share', compact('page_title', 'shares', 'product','network_contract','user','moneda','total_vip','total_mn'));
    }

    public function pool_interest()
    {
        $page_title = 'Pool Interest Logs';
        $pools = PoolInterest::orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        return view('admin.reports.pool_interest', compact('page_title', 'pools'));
    }

    public function consolidado($date = ""){
         
        if(@$_GET['fecha'] && @$_GET['fecha_fin'])
        {
            $date = @$_GET['fecha'];
            $filter = "created_at between '".$_GET['fecha']."' and '".$_GET['fecha_fin']."'";
        }else
          {
              $filter = "substring(created_at,1,10) = '".$date."'";
          }

          $date = date("Y-m-d", strtotime($date));


         if(!$this->isDate($date))
         {
              $date = date('Y-m-d');
         }

         $sql_depo = "select sum(amount) as total, count(*) as cantidad, method_currency  from deposits  where status = 1 and  ".$filter."    group by method_currency";
         $depositos = \DB::select($sql_depo);

         $sql_depo = "select sum(amount) as total, sum(total_share) as cantidad, moneda, type from shares   where status = 1 and ".$filter."    group by type, moneda";
         $shares = \DB::select($sql_depo);

         $sql_bonos = "select sum(amount_con) as total, count(*) as cantidad , type  from trxes where moneda = 2 and ".$filter." group by type";
         $trxes_trx = \DB::select($sql_bonos);
    
         $sql_bonos = "select sum(amount) as total, count(*) as cantidad , type  from trxes where moneda = 1 and ".$filter." group by type";
         $trxes_eth = \DB::select($sql_bonos);

         $sql_pagos = "select sum(solicitud_trx) as total_retiro, sum(enviado_trx) as total_enviado,  count(*) as cantidad   from prew_withdraws where ".$filter."";
         $pagos_trx = \DB::select($sql_pagos);
        
         $sql_pagos = "select sum(amount) as total_retiro, sum(final_amo) as total_enviado,  count(*) as cantidad   from withdrawals where currency = 'ETH' and ".$filter."";
         $pagos_eth = \DB::select($sql_pagos);

         $sql_pagos = "select sum(monto) as total, count(*) as cantidad  from resul_lotos where ".$filter."";
         $lotto_trx = \DB::select($sql_pagos);
         
         $data['page_title'] = "Consolidado";
         $data['fecha']     = $date;
         $data['shares']      = $shares;
         $data['depositos'] = $depositos;
         $data['bono_trx']  = @$trxes_trx;
         $data['bono_eth']  = @$trxes_eth;
         $data['pagos_trx'] = $pagos_trx;
         $data['pagos_eth'] = $pagos_eth;
         $data['lotto']     = $lotto_trx;  
        
         return view('admin.reports.consolidado',$data);


  }

        function isDate($value) 
        {
            if (!$value) {
                return false;
            }

            try {
                new \DateTime($value);
                return true;
            } catch (\Exception $e) {
                return false;
            }
        }


}

