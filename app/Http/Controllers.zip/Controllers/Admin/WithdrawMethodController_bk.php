<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Rules\FileTypeValidate;
use App\WithdrawMethod;
use Illuminate\Support\Facades\Validator;
use App\User;
use App\GeneralSetting;
use App\Withdrawal;
use App\Trx;
use App\Lib\CoinPaymentHosted;

class WithdrawMethodController extends Controller
{
    public function WithdrawRequestCreate()
    {
        $page_title = 'Create Withdrawal Etehreum';
        $method = WithdrawMethod::where('id',1)->first();
        $withdraws = User::where('interest_wallet','>=', $method->min_limit)->where('forma_p',1)->where('smart',1)->where('id','<>',2)->where('status','1')->orderBy('interest_wallet')->paginate(200,['id','username','interest_wallet','interest_wallet_trx','etherium_wallet_code','forma_p']);
        $resp   =  $this->send_smart('/eth/balance', array('dire'=>'0xbAa37930a2B24bc17F92f26c86D8A514539A7a44'));
        $saldo_contracto    =  @$resp->result;
        $forma_pago = 1;
        return view('admin.withdraw.index', compact('page_title','withdraws', 'method','saldo_contracto', 'forma_pago'));
    }

    public function WithdrawRequestCreate_tron()
    {
        $page_title = 'Create Withdrawal Tron(TRX)';
        $method = WithdrawMethod::where('id',1)->first();
        $method2 = WithdrawMethod::where('id',2)->first();

        $withdraws = User::whereRaw(
                          "
                          (interest_wallet >= $method2->min_limit and
                          forma_p = 2 and status = 1 and wallet_tron <> '41')
                          or
                          (interest_wallet_trx >= 10 and
                          forma_p = 2 and status = 1 and wallet_tron <> '41')
                          "
                       )->orderBy('interest_wallet')->paginate(50,['id','username','interest_wallet','interest_wallet_trx','etherium_wallet_code','forma_p']);
        $resp   =  $this->send_smart('/tron/balance', array('dire'=>'TKSSoisLQk9Lt2wxtGvSv2ZhreRAJcqStx'));
        $saldo_contracto    =  @$resp->result;
        $forma_pago = 2;
        $precio_eth  = price_ether_btc();
        $precio_tron = price_tron_btc();
        $i = 0;
     
        return view('admin.withdraw.index', compact('page_title','withdraws', 'method','saldo_contracto','forma_pago'));
    }
    
    public function WithdrawRequestStore_tron(Request $request)
    {

           $method = WithdrawMethod::where('id',2)->first();
           $cps = new CoinPaymentHosted();
           $cps->Setup($method->val2, $method->val1);
           $result = $cps->GetRates();
         
           $btceth = $result['result']['ETH']['rate_btc'];
           $btctrx = $result['result']['TRX']['rate_btc'];
            set_time_limit(0);
            $request->validate([
                'user' => 'required',
            ]);
          
            foreach($request->user as $user_id => $a){
                                $user = User::findOrFail($user_id);

                                $total_interest =  tron_pay($user->interest_wallet,$btceth,$btctrx) + $user->interest_wallet_trx;
                                $interest_trx   =  $user->interest_wallet_trx;
                                $interest_eth   =  $user->interest_wallet + $this->calcula_ether($user->interest_wallet_trx,$btceth, $btctrx); 

                                if($method->max_limit < $total_interest){
                                    $wdamo_et = $user->interest_wallet;
                                    $wdamo = $method->max_limit;
                                    $wdamo_tx = 0;
                            	}else{
                                    $wdamo_et = $user->interest_wallet;
                                    $wdamo    = $total_interest;
                                    $wdamo_tx = $interest_trx;
                                }

                                $charge = formatter_money($method->fixed_charge + ($wdamo * $method->percent_charge / 100));
                                $charge_eth = $this->calcula_ether($charge,$btceth, $btctrx);
                                $amountSend_eth =  $interest_eth - $charge_eth;
                            	$amountSend = $wdamo - $charge;
                                $tnxnum = getTrx();
                                  
                        ////////////////////////AUTOMATED
                                if ($method->status) {
                                 /*   $cps = new CoinPaymentHosted();
                                    $cps->Setup($method->val2, $method->val1);
                                    $result = $cps->CreateWithdrawal($amountSend, 'ETH', $user->etherium_wallet_code, '1');
                                    */
                                }
                    // crear strutura
                        try{
                                    $data = array('id'=>$user->id);
                                    $result = $this->send_smart('/tron/wallet', $data);
                                     
                                     
                                     if(@$result->result != "T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb")
                                      {
                                            if(@$result->result != "") {
                                            $pagos_inline[] = array(
                                                                'id_user'=>$user->id,
                                                                'interest_wallet'=> $user->interest_wallet,
                                                                'wdamo'=> $interest_eth,
                                                                'charge'=> $charge_eth,
                                                                'wdamo_trx'=>round($interest_trx,6),
                                                                'wdamo_eth'=>$wdamo_et,
                                                                'wdamo_con'=> $wdamo,
                                                                'charge_con'=> round($charge,6),
                                                                'amountSend_con'=>round($amountSend,6),
                                                                'tnx_num'=>$tnxnum,
                                                                'amountSend'=>$amountSend_eth,
                                                                'moneda'=>2
                                                                );
                                            }
                                      }
                        }catch(Exception $err){
                                  $notify[] = ['error', 'Servidor smart Contract Apagado!'];
                                  return back()->withNotify($notify);
                        }
                    // fin
////////////////////////AUTOMATED
        }
             
            
             $result =  $this->send_pay_tron(@$pagos_inline);
             
             // @$result->res = "ok";
             
             if (@$result->res == 'ok') {
                            $hash = (string)$result->result;
                            foreach(@$pagos_inline as $valor){
                                         $wdamo      = $valor['wdamo'];
                                         $charge     = $valor['charge'];
                                         $amountSend = $valor['amountSend'];
                                         $wdamo_con      = $valor['wdamo_con'];
                                         $charge_con     = $valor['charge_con'];
                                         $amountSend_con = $valor['amountSend_con'];
                                         $interes_wallet   =  $valor['interest_wallet'];
                                         $wdamo_trx      = $valor['wdamo_trx'];
                                         $wdamo_eth      = $valor['wdamo_eth'];
                                         $tnxnum     = $valor['tnx_num'];
                                        // echo $wdamo." - ".$charge." - ".$amountSend;
                                         $user = User::findOrFail($valor['id_user']);

                                        $withdraw = new Withdrawal();
                                        $withdraw->method_id = $method->id;
                                        $withdraw->user_id = $user->id;
                                        $withdraw->amount = formatter_money($wdamo);
                                        $withdraw->charge = formatter_money($charge);
                                        $withdraw->rate = 1;
                                        $withdraw->currency = 'TRX';
                                        $withdraw->delay = 0;
                                        $withdraw->final_amo = $amountSend;
                                        $withdraw->status = 2;
                                        $withdraw->email_code = verification_code(6);
                                        $withdraw->trx = $tnxnum;
                                        $withdraw->save();

                                        $user->interest_wallet -= $wdamo_eth;
                                        $user->interest_wallet_trx -= $wdamo_trx;
                                        $user->save();

                                        $trx = new Trx();
                                        $trx->user_id = $user->id;
                                        $trx->amount = $wdamo;
                                        $trx->charge = formatter_money($charge);
                                        $trx->main_amo = formatter_money($amountSend);
                                        $trx->balance = formatter_money($user->interest_wallet);
                                        $trx->charge_con = formatter_money($charge_con);
                                        $trx->main_amo_con = formatter_money($amountSend_con);
                                        $trx->amount_con = $wdamo_con;
                                        $trx->type = 'withdraw';
                                        $trx->trx = $tnxnum;
                                        $trx->hash =  $hash;
                                        $trx->moneda = 2;
                                        $trx->title = 'withdraw Via Smart Contract TRX';
                                        $trx->save();

                                        $withdraw->status = 1;
                                        $withdraw->save();
                                
                                        $general = GeneralSetting::first();
                                        send_email($user, 'WITHDRAW_TRON_APPROVE', [
                                            'trx' => $tnxnum,
                                            'amount' =>  formatter_money($trx->amount_con)."  ".$withdraw->currency." (".formatter_money($withdraw->amount)."  ETH)",
                                            'receive_amount' =>  formatter_money($withdraw->amount_con - $withdraw->charge_con)."  ".$withdraw->currency." (".formatter_money($withdraw->amount_con - $withdraw->charge_con)." ETH)",
                                            'charge' =>  formatter_money($withdraw->charge_con)." ".$withdraw->currency." (".formatter_money($withdraw->charge). " ETH)",
                                            'method' => $withdraw->method->name,
                                        ]);

                                        send_sms($user, 'WITHDRAW_TRON_APPROVE', [
                                            'trx' => $tnxnum,
                                            'amount' => $general->cur_sym . formatter_money($withdraw->amount),
                                            'receive_amount' => $general->cur_sym . formatter_money($withdraw->amount - $withdraw->charge),
                                            'charge' => $general->cur_sym . formatter_money($withdraw->charge),
                                            'method' => $withdraw->method->name,
                                        ]);
                                      
                             }
                                $notify[] = ['success', 'Withdraw Completed Successfully!'];
                                return back()->withNotify($notify);
                         }
                         else{
                            foreach($pagos_inline as $value){
                                echo "<br>(".$value['amountSend_con']." ".$value['id_user'].")";
                            }
                              echo "<hr>";
                                print_r($result);
                                return "no registro  pago ";
                                $notify[] = ['error', 'Withdraw no pudo ser completado!'];
                                return back()->withNotify($notify);
                         }
            

    }


    public function WithdrawRequestStore(Request $request)
    {
         
            set_time_limit(0);
            $request->validate([
                'user' => 'required',
            ]);

            $precio_eth  = price_ether_btc();
            $precio_tron = price_tron_btc();

            $method = WithdrawMethod::where('id',1)->first();
            foreach($request->user as $user_id => $a){
    
                                $user = User::findOrFail($user_id);
                                $interest_trx   = $user->interest_wallet_trx;
                                $total_interest =  $user->interest_wallet + ether_pay($user->interest_wallet_trx,$precio_eth,$precio_tron);

                                if($method->max_limit < $total_interest){
                                    $wdamo_et = $user->interest_wallet;
                                    $wdamo = $method->max_limit;
                                    $wdamo_tx = 0;
                            	}else{
                                    $wdamo_et = $user->interest_wallet;
                                    $wdamo = $total_interest;
                                    $wdamo_tx = $user->interest_wallet_trx;
                                }

                            	$charge = formatter_money($method->fixed_charge + ($wdamo * $method->percent_charge / 100));
                            	$amountSend = $wdamo - $charge;
                                $tnxnum = getTrx();
                                
                        ////////////////////////AUTOMATED
                                if ($method->status) {
                                    /*
                                         $cps    = new CoinPaymentHosted();
                                         $cps->Setup($method->val2, $method->val1);
                                         $result = $cps->CreateWithdrawal($amountSend, 'ETH', $user->etherium_wallet_code, '1');
                                    */
                                }
                    // crear strutura
                        try{
                          $data = array('id'=>$user->id);
                          $result = $this->send_smart('/eth/wallet', $data);
                           if(@$result->result != "0x0000000000000000000000000000000000000000")
                          {
                             if(@$result->result != "") {
                              $pagos_inline[] = array(
                                                 'id_user'=>$user->id,
                                                 'interes_wallet'=> $user->interest_wallet,
                                                 'wdamo'=>$wdamo,
                                                 'wdamo_eth'=>$wdamo_et,
                                                 'wdamo_trx'=>$wdamo_tx,
                                                 'charge'=> $charge,
                                                 'tnx_num'=>$tnxnum,
                                                 'amountSend'=>$amountSend
                                                );
                             }
                          }

                        }catch(Exception $err){
                                  $notify[] = ['error', 'Servidor smart Contract Apagado!'];
                                  return back()->withNotify($notify);
                        }


                    // fin

////////////////////////AUTOMATED
        }
          
                     $result =  $this->send_pay(@$pagos_inline);  
                  
                       if (@$result->res == 'ok') {

                             $hash = (string)$result->result;
                       

                            foreach(@$pagos_inline as $valor){

                                         $wdamo      = $valor['wdamo'];
                                         $wdamo_eth  = $valor['wdamo_eth'];
                                         $wdamo_trx  = $valor['wdamo_trx'];
                                         $charge     = $valor['charge'];
                                         $amountSend = $valor['amountSend'];
                                         $tnxnum     = $valor['tnx_num'];
                                        // echo $wdamo." - ".$charge." - ".$amountSend;

                                         $user = User::findOrFail($valor['id_user']);

                                        $withdraw = new Withdrawal();
                                        $withdraw->method_id   = $method->id;
                                        $withdraw->user_id     = $user->id;
                                        $withdraw->amount      = formatter_money($wdamo);
                                        $withdraw->charge      = formatter_money($charge);
                                        $withdraw->rate        = 1;
                                        $withdraw->currency    =  'ETH';
                                        $withdraw->delay       = 0;
                                        $withdraw->final_amo   = $amountSend;
                                        $withdraw->status      = 2;
                                        $withdraw->email_code  = verification_code(6);
                                        $withdraw->trx = $tnxnum;
                                        $withdraw->save();

                                        $user->interest_wallet     -= $wdamo_eth;
                                        $user->interest_wallet_trx -= $wdamo_trx;
                                        $user->save();

                                        $trx = new Trx();
                                        $trx->user_id = $user->id;
                                        $trx->amount = formatter_money($wdamo);
                                        $trx->charge = formatter_money($charge);
                                        $trx->main_amo = formatter_money($amountSend);
                                        $trx->balance = formatter_money($user->interest_wallet);
                                        $trx->type = 'withdraw';
                                        $trx->trx = $tnxnum;
                                        $trx->hash =  $hash;
                                        $trx->title = 'withdraw Via Smart Contract';
                                        $trx->save();

                                        $withdraw->status = 1;
                                        $withdraw->save();

                                  
                                        $general = GeneralSetting::first();
                                        send_email($user, 'WITHDRAW_APPROVE', [
                                            'trx' => $hash,
                                            'amount' => $general->cur_sym . formatter_money($withdraw->amount)." ( ".$withdraw->currency.") ",
                                            'receive_amount' => $general->cur_sym . formatter_money($withdraw->amount - $withdraw->charge)." ( ".$withdraw->currency.") ",
                                            'charge' => $general->cur_sym . formatter_money($withdraw->charge)." ( ".$withdraw->currency.") ",
                                            'method' => $withdraw->method->name,
                                        ]);

                                        send_sms($user, 'WITHDRAW_APPROVE', [
                                            'trx' => $hash,
                                            'amount' => $general->cur_sym . formatter_money($withdraw->amount),
                                            'receive_amount' => $general->cur_sym . formatter_money($withdraw->amount - $withdraw->charge),
                                            'charge' => $general->cur_sym . formatter_money($withdraw->charge),
                                            'method' => $withdraw->method->name,
                                        ]);
                                
                             }
                         
                                $notify[] = ['success', 'Withdraw Completed Successfully!'];
                                return back()->withNotify($notify);
                         }
                         else{

                               $notify[] = ['error', 'Withdraw no pudo ser completado!'];
                                return back()->withNotify($notify);
                         }
    }

    public function methods()
    {
        $page_title = 'Withdraw Methods';
        $empty_message = 'Withdraw Methods not found.';
        $methods = WithdrawMethod::orderByDesc('status')->orderBy('id')->paginate(config('constants.table.default'));
        return view('admin.withdraw.methods', compact('page_title', 'empty_message', 'methods'));
    }

    public function create()
    {
        $page_title = 'New Withdraw Method';
        return view('admin.withdraw.create', compact('page_title', 'saldo_contracto'));
    }

    public function store(Request $request)
    {
        $validation_rule = [
            'name' => 'required|max: 60',
            'image' => 'required|image',
            'image' => [new FileTypeValidate(['jpeg', 'jpg', 'png'])],
            'rate' => 'required|gt:0',
            'delay' => 'required',
            'currency' => 'required',
            'min_limit' => 'required|gt:0',
            'max_limit' => 'required|gte:0',
            'fixed_charge' => 'required|gte:0',
            'percent_charge' => 'required|between:0,100',
            'instruction' => 'required|max:64000',

            'ud.*' => 'required',
        ];
        $request->validate($validation_rule, [], ['ud.*' => 'All user data']);

        $filename = '';
        if ($request->hasFile('image')) {
            try {
                $filename = upload_image($request->image, config('constants.withdraw.method.path'), config('constants.withdraw.method.size'));
            } catch (\Exception $exp) {
                $notify[] = ['error', 'Image could not be uploaded.'];
                return back()->withNotify($notify);
            }
        }

        $method = WithdrawMethod::create([
            'name' => $request->name,
            'image' => $filename,
            'rate' => $request->rate,
            'delay' => $request->delay,
            'min_limit' => $request->min_limit,
            'max_limit' => $request->max_limit,
            'fixed_charge' => $request->fixed_charge,
            'percent_charge' => $request->percent_charge,
            'currency' => $request->currency,
            'description' => $request->instruction,
            'user_data' => $request->ud ?: [],
        ]);

        $notify[] = ['success', $method->name . ' has been added.'];
        return redirect()->route('admin.withdraw.method.methods')->withNotify($notify);
    }

    public function edit($id)
    {
        $page_title = 'Update Withdraw Method';
        $method = WithdrawMethod::findOrFail($id);
        return view('admin.withdraw.edit', compact('page_title', 'method'));
    }


    public function update(Request $request, $id)
    {
        $validation_rule = [
            'name' => 'required|max: 60',
            'image' => 'nullable|image',
            'image' => [new FileTypeValidate(['jpeg', 'jpg', 'png'])],
            'min_limit' => 'required|gt:0',
            'max_limit' => 'required|gte:0',
            'fixed_charge' => 'required|gte:0',
            'percent_charge' => 'required|between:0,100',
        ];
        $request->validate($validation_rule, [], ['ud.*' => 'All user data']);

        $method = WithdrawMethod::findOrFail($id);
        $filename = $method->image;
        if ($request->hasFile('image')) {
            try {
                $filename = upload_image($request->image, config('constants.withdraw.method.path'), config('constants.withdraw.method.size'), $method->image);
            } catch (\Exception $exp) {
                $notify[] = ['error', 'Image could not be uploaded.'];
                return back()->withNotify($notify);
            }
        }

        $method->update([
            'name' => $request->name,
            'image' => $filename,
            'min_limit' => $request->min_limit,
            'max_limit' => $request->max_limit,
            'fixed_charge' => $request->fixed_charge,
            'percent_charge' => $request->percent_charge,
            'val1' => $request->val1,
            'val2' => $request->val2,
        ]);

        $notify[] = ['success', $method->name . ' has been updated.'];
        return back()->withNotify($notify);
    }

    public function activate(Request $request)
    {
        $request->validate(['id' => 'required|integer']);
        $method = WithdrawMethod::findOrFail($request->id);
        $method->update(['status' => 1]);
        $notify[] = ['success', $method->name . ' has been activated.'];
        return redirect()->route('admin.withdraw.method.methods')->withNotify($notify);
    }

    public function deactivate(Request $request)
    {
        $request->validate(['id' => 'required|integer']);
        $method = WithdrawMethod::findOrFail($request->id);
        $method->update(['status' => 0]);
        $notify[] = ['success', $method->name . ' has been deactivated.'];
        return redirect()->route('admin.withdraw.method.methods')->withNotify($notify);
    }

    function send_pay($valores){
              $usuarios = "";
              $montos = "";
              $i=1;
             foreach($valores as $valor)
             {
                  if($usuarios!=""){ $usuarios .= ",";  $montos   .= ","; }

                $usuarios .= $valor['id_user'];
                $montos   .= $valor['amountSend'];
                //$montos    .= "0.00002";
                $i++;
             }
         if($usuarios == "")
              {
                   return array('res'=>'1', 'result'=>'nothing');
                }
                 
           $data = array('dire'=>$usuarios,  'monto'=> $montos );
           $result = $this->send_smart('/eth/pagar', $data);
           return $result;
    }
    
    function calcula_tron($ether, $btceth, $btctrx) {
        $btc_ether = $ether * $btceth;
        $tron = $btc_ether / $btctrx;
        return round($tron,6);
    }

    function calcula_ether($tron, $btceth, $btctrx) {
        $eth_tron =  $btctrx / $btceth;
        $ether =  $eth_tron * $tron;
        return round($ether,8);
    }

    function send_pay_tron($valores){
        $usuarios = "";
        $montos = "";
        $i=1;
       foreach($valores as $valor)
       {
            if($usuarios!=""){ $usuarios .= ",";  $montos   .= ","; }
            $usuarios .= $valor['id_user'];
            $montos   .= $valor['amountSend_con'];
          //$montos    .= "0.00002";
          $i++;
       }
   if($usuarios == "")
          {
             return array('res'=>'1', 'result'=>'nothing');
          }
        
     $data = array('dire'=>$usuarios,  'monto'=> $montos );
     $result = $this->send_smart('/tron/pagar', $data);
     return $result;
}


function send_smart($sesion, $data){

        $arra = "";
         foreach ($data as $key => $value) {
             if($arra != "") $arra .= "&";
             $arra .= $key."=".$value;
         }

         $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL,"http://labts.procashdream.com/smart".$sesion);
          curl_setopt($ch, CURLOPT_POST, TRUE);
         curl_setopt($ch, CURLOPT_POSTFIELDS,$arra);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          $resul = curl_exec ($ch);
          curl_close ($ch);
          $resu = json_decode($resul);
          return $resu;
      }

    

}
