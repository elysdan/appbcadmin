<?php

namespace App\Http\Controllers;

use App\CompenstionPlan;
use App\GeneralSetting;
use App\NetworkContract;
use App\Product;
use App\super_vip;
use App\Share;
use App\Trx;
use App\Deposit;
use App\auth;
use App\sorteo;
use App\Buy_ticket;
use App\GatewayCurrency;
use Carbon\Carbon;
use App\MatrixSubscriber;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;

class usdtController extends Controller
{
     public function  index(){
        $data['page_title'] = 'Contracts USDT';
        $data['shares'] = Share::where('user_id', auth()->id())->where('moneda',3)->with('product')->latest()->paginate(config('constants.table.default'));
        $data['total_contra'] = Share::where('user_id', auth()->id())->where('type',1)->count();
        return view(activeTemplate() . 'user.shareusdt', $data);
     } 

     public function buy_MN(Request $request)
     {
            $this->validate($request, [
                'share' => 'required|integer|min:1',
            ]);
    
            $data_con                = $this->data_cont(1);
            $cantidad                = $request->share;
            $price                   = $data_con->price;
            $total_price             = $cantidad * $price;
                
            if(auth()->user()->balance_usdt < $total_price)
            { 
                $notify[] = ['error', 'Insufficient balance, Please deposit first'];
                return redirect()->route('user.wallets.index')->withNotify($notify);
            }
    
            $data['cant']           =   $cantidad;
            $data['price']          =   $price;
            $data['total_price']    =   $total_price;
            $data['producto']       =   $data_con;
            $data['moneda']         =   3;                
            $resu = (object)$data; 
            $this->contrato(1,$resu);
            
            return;
            $notify[] = ['success', 'You have purchase Contracts Successfully'];
            return back()->withNotify($notify);
     }

     public function buy_VIP(Request $request ){
            $this->validate($request, ['network_contract' => 'required|integer|min:1']);
            $data_con                = $this->data_cont(0);
            $cantidad                = $request->network_contract;
            $price                   = $data_con->price;
            $total_price             = $cantidad * $price;
            if(auth()->user()->balance_usdt < $total_price)
            { 
                $notify[] = ['error', 'Insufficient balance, Please deposit first'];
                return redirect()->route('user.wallets.index')->withNotify($notify);
            }
            $data['cant']           =   $cantidad;
            $data['price']          =   $price;
            $data['total_price']    =   $total_price;
            $data['producto']       =   $data_con;
            $data['moneda']         =   3;
            $resu = (object)$data;                
            $this->contrato(0,$resu);
            $notify[] = ['success', 'You have purchase Contracts Successfully'];
            return back()->withNotify($notify);
     }


     private function  contrato ($tipo, $request){
            $gnl = GeneralSetting::first();
            $user = auth()->user();

            $user->balance_usdt            -= $request->total_price;
            if($tipo == 0)
            $user->network_contracts_usdt   += $request->cant;
            else
            $user->shares_usdt             += $request->cant;
            $user->total_invest_usdt       += $request->total_price;
            $user->save();

            
            if($tipo == 1)
                $max_earning = $request->total_price * $gnl->max_profit / 100;
            else
                $max_earning = $request->total_price * $request->producto->max_profit / 100;

            $share = new  Share();
            $share->user_id         = $user->id;
            $share->product_id      = $request->producto->id;
            $share->type            = $tipo;
            $share->total_share     = $request->cant;
            $share->price_share     = $request->price;
            $share->price_dolar     = 1;
            $share->moneda          = $request->moneda;
            $share->amount          = $request->total_price;
            $share->max_earning     = $max_earning;
            $share->status          = 3;
        
            if($tipo == 1){
                $share->status         = 1;
                $share->start_date = Carbon::now()->addDays(5);
            }
        
            $share->save();

            if($tipo == 0) {
                    $title = "Buy ".$request->cant." USDT contract";
                    $details = $user->username . ' Buy ' . $request->cant . ' USDT Contracts.';
            }
            elseif($tipo==1){
                    $title = "Buy ".$request->cant." USDT contract";
                    $details = $user->username . ' Buy ' . $request->cant . ' USDT Contracts.';
                }
           
             trx_compra($user, $request->total_price, $title, $request->moneda);
           
         
            $refer = User::find($user->ref_id);
              
         

            // valida que no se esta pagando el mismo binario
            $puede = $this->validar_patrocinador($user);

            $inversion = Share::where('user_id', $user->id)->where('type',1)->count();
             echo $puede."<br>";
            if ($refer && $refer->account_type == 1 && $user->generate_com == 1 &&  $puede == 0) {
                
                   
                   echo  "entro por aqui ".$refer;
                
                  $amount = ($request->total_price * $request->producto->ref_bonus) / 100;
                 referralComission_compensation($user->id, $amount, $details,3);
            }
             
             
             // si queremos frenar las reeninversiones
            if ($user->generate_com == 1 &&  $puede == 0 ) {
                       $puntos = $request->total_price;
                       updateBV($user->id, $puntos, $details, 1);
            }

     }

     private function validar_patrocinador($user){
      
        $ref = User::where('ref_id', $user->id)->first();
      

        // validamos primero l a misma wallet
        
        if($ref->wallet_tron  <> 41 or $user->wallet_tron <> 41){
                    if($ref->wallet_tron == $user->wallet_tron){
                        return 1;
                    }
        }

        if($ref->chat_id  <> 0 or $user->chat_id <> 0){
                    if($ref->chat_id == $user->chat_id){
                        return 1;
                    }
        }

        if($ref->identity  <> 0 or $user->identity <> 0){
                    if($ref->identity == $user->identity){
                        return 1;
                    }
        }

        return 0;
     }


     private function create_contrato($user, $data  ){
                $share = new  Share();
                $share->user_id         = $user->id;
                $share->product_id      = $product->id;
                $share->total_share     = $request->share;
                $share->price_share     = $price;
                $share->price_dolar     = 1;
                $share->amount          = $total_price;
                $share->max_earning     = $max_earning;
                    if($data ['tipo'] == 1){
                        $share->start_date = Carbon::now()->addDays($gnl->pool_start);
                    }
                $share->status = 1;
                $share->save();

                $product->total_sell += $request->share;
                $product->save();
        
                $user->transactions()->create([
                    'trx' => getTrx(),
                    'user_id' => $user->id,
                    'amount_con' => $total_price,
                    'main_amo_con' => $total_price,
                    'balance_con' => $user->balance,
                    'price_dolar' => 1,
                    'moneda' => 3,
                    'title' => $request->share . ' Contract MN  Purchase USDT',
                    'charge' => 0,
                    'type' => 'share_buy_ustd',
                ]);
     }

     private function update_contrato($tipo, $data, $cantidad){
          
     }

     

     private function data_cont($tipo){
        switch($tipo){
            case 0:
                   return  NetworkContract::where('moneda',3)->first();         
            break;
            case 1:
                   return  Product::where('moneda',3)->first(); 
            break;
            default: return false;
        }
     }





}