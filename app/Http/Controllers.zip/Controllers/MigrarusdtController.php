<?php

namespace App\Http\Controllers;

use App\CompenstionPlan;
use App\GeneralSetting;
use App\NetworkContract;
use App\Product;
use App\super_vip;
use App\Share;
use App\Trx;
use App\Deposit;
use App\auth;
use App\sorteo;
use App\Buy_ticket;
use App\User;
use App\GatewayCurrency;
use Carbon\Carbon;
use App\Matrix1x3;
use App\Cripto_price;
use App\User3x1;
use App\Prod_mat;
use App\MatrixSubscriber;
//use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;



class migrarusdtController extends Controller
{

    public function lista_contracto(){

        $data['page_title'] = 'Products';

        $data['products'] = \DB::select('select user_id, username, shares.created_at, shares.status, start_date, total_share,
                                        (amount/total_share) as precio, amount, return_profit, 0
                                         max_earning, moneda, shares.type, 
                                        (select price from cripto_price where fecha = substring(shares.created_at,1,10) and moneda_id = shares.moneda limit 1) as precio_dolar 
                                         from shares join users on shares.useR_id = users.id');
                                         
            return view(activeTemplate() . 'user.contratos_antes', $data);
    }
        
        public function todos_users(){
              
             set_time_limit(0);
             $sqlk = 'select * FROM(SELECT user_id, sum(total_share) as total FROM `shares` WHERE migrado = 0 and moneda <> 3 and migrado = 0 group by user_id desc) as a  where a.total = 1';
            $all_user = \DB::select($sqlk);

            $fecha = '2021-03-01';

            echo $fecha;
            $i = 1;
          foreach($all_user as $data){
                   
                $user_id = $data->user_id;
                $tasa = 0;
                $fecha = '2021-03-01';
                echo "iniciamos con las ganancias <br>";
                $ganancia  = $this->migrar_ganancias($user_id);

                echo "<br>Luego aplicamos los contratos de masternodo<br>";
                $pendiente = $this->contratos_trx_mn($fecha, $user_id, 2, $tasa, $ganancia);

                echo "<br>Luego aplicamos los contratos VIP</br>";
                $this->contratos_trx_vip($fecha, $user_id, 2, $tasa, $pendiente);
                
                $i++;
           } 

        }

        public function prueba_fuego($user_id){
                        $tasa = 0;
                        $fecha = '2021-03-01';
                   
                        echo "iniciamos con las ganancias <br>";
                        $ganancia  = $this->migrar_ganancias($user_id);

                        echo "<br>Luego aplicamos los contratos de masternodo<br>";
                        $pendiente = $this->contratos_trx_mn($fecha, $user_id, 2, $tasa, $ganancia);

                        echo "<br>Luego aplicamos los contratos VIP</br>";
                        $this->contratos_trx_vip($fecha, $user_id, 2, $tasa, $pendiente);


        }

    
     
        public function migrar_ganancias($user_id, $moneda = 0){
                           
                    $total_usdt = 0;
                    $balance = 0;
                    $pool = trx::where('type', 'pool_interest')->where('user_id', $user_id)->get();
                    
                    foreach($pool as $data){
                            if($data->moneda == 1)  $monto_c = $data->amount;
                            else            $monto_c = $data->amount_con;
                            $fecha = substr($data->created_at, 0,10);
                            $cal = Cripto_price::where('fecha', $fecha)->where('moneda_id',$data->moneda)->first();
                            $tasa_dia = @$cal->price;
                            $precio_usdt = $monto_c * $tasa_dia;
                            $total_usdt += $precio_usdt;
                    }
                    $pool = "";

                    $matrix   =  trx::where('type', 'matrix_commission')->where('user_id', $user_id)->get();
                    
                    foreach($matrix as $data){
                                if($data->moneda == 1)  $monto_c = $data->amount;
                                else            $monto_c = $data->amount_con;
                                $fecha = substr($data->created_at, 0,10);
                                $cal = Cripto_price::where('fecha', $fecha)->where('moneda_id',$data->moneda)->first();
                                $tasa_dia = @$cal->price;
                                $precio_usdt = $monto_c * $tasa_dia;
                                $total_usdt += $precio_usdt;
                    }
                    $matrix = "";
                    
                    $binary   =  trx::where('type', 'binary_comission')->where('user_id', $user_id)->get();
                    
                    foreach($binary as $data){
                                if($data->moneda == 1)  $monto_c = $data->amount;
                                else            $monto_c = $data->amount_con;
                                $fecha = substr($data->created_at, 0,10);
                                $cal = Cripto_price::where('fecha', $fecha)->where('moneda_id',$data->moneda)->first();
                                $tasa_dia = @$cal->price;
                                $precio_usdt = $monto_c * $tasa_dia;
                                $total_usdt += $precio_usdt;
                    }
                    $binary = "";
                    
                    $referral =  trx::where('type', 'referral_commision')->where('user_id', $user_id)->get();
                    
                    foreach($referral as $data){
                                if($data->moneda == 1)  $monto_c = $data->amount;
                                else            $monto_c = $data->amount_con;
                                $fecha = substr($data->created_at, 0,10);
                                $cal = Cripto_price::where('fecha', $fecha)->where('moneda_id',$data->moneda)->first();
                                $tasa_dia = @$cal->price;
                                $precio_usdt = $monto_c * $tasa_dia;
                                $total_usdt += $precio_usdt;
                    }
                    $referral = "";
                    $residual =  trx::where('type', 'residual_bonus')->where('user_id', $user_id)->get();
                    
                    foreach($residual as $data){
                                if($data->moneda == 1)  $monto_c = $data->amount;
                                else            $monto_c = $data->amount_con;
                                $fecha = substr($data->created_at, 0,10);
                                $cal = Cripto_price::where('fecha', $fecha)->where('moneda_id',$data->moneda)->first();
                                $tasa_dia = @$cal->price;
                                $precio_usdt = $monto_c * $tasa_dia;
                                $total_usdt += $precio_usdt;
                    }
                    $residual = "";

                    $n_trx = new trx();
                    $n_trx->user_id         = $user_id;
                    $n_trx->amount_con      = $total_usdt;
                    $n_trx->main_amo_con    = $total_usdt;
                    $n_trx->balance         = $balance;
                    $n_trx->moneda          = 3;
                    $n_trx->type            = 'migration';
                    $n_trx->title           = 'Migration USDT';
                    $n_trx->trx             = getTrx();

                    print_r(json_decode($n_trx));

                    echo "<br>";

                    echo $total_usdt;
                    echo "<hr>";
                    $n_trx->save();

                    return $total_usdt;

        }
  
      
        public function contratos_trx_mn($fecha, $user_id, $moneda, $tasa = 0, $cobrado){
                        
                    echo $fecha;
                    $contratos =  Share::where('type',1)->where('user_id', $user_id)->where('migrado','0')->orderBy('id')->
                    get();
                            
                    $new_monto  = 0;
                    $new_max    =0;
                    $new_return = 0;
                    $new_total = 0;
                    $new_monto_original = 0;
                    $diferen = 0;

                        foreach($contratos as $data){
                               
                            
                            if($data->moneda == 2)  $tasa = 0.08;
                            if($data->moneda == 1)  $tasa = 2200;

                            print_r(json_decode($data));
                            echo "<br><br>";
                            $fech_consulta = substr($data->created_at,0,10);
                                                           

                             
                                                            $cal = Cripto_price::where('fecha', $fech_consulta)->
                                                            where('moneda_id',$data->moneda)->first();
                                 echo "<br>".$fech_consulta."<br>";
                                                            $tasa_dia = @$cal->price;
                                                            $tasa_dia2 = @$cal->price;
                                                            $cal = "";
                                                    
                                                 if($fech_consulta > '2021-02-28' && $fech_consulta  < '2021-05-01'){
                                                                
                                                        if($data->moneda == 2 && $tasa_dia > 0.08 )  $tasa_dia = $tasa;
                                                        if($data->moneda == 2 && $tasa_dia > 2200 )  $tasa_dia = $tasa;
                                                       
                                                       echo "<br>".$fech_consulta." = ".$tasa_dia."<br>"; 
                                                 }
                                                    
                                        
                                            $new_monto      += $data->amount * $tasa_dia;
                                            $new_total      += $data->total_share; 

                                            $new_monto_original += $data->amount * $tasa_dia;
                                        
                                            if($data->type ==0 )    $new_max += ($data->amount * $tasa_dia) * 3;
                                            else                    $new_max += ($data->amount * $tasa_dia) * 2;
                                            $new_return   += $data->return_profit *  $tasa_dia;
                                            $data->migrado = 1;
                                            $data->status = 2;
                                            $data->save();

                                        echo $data->amount * $tasa_dia2."  y ahora es ".$data->amount * $tasa_dia." y lo ganado hasta ahora es ".$data->return_profit *  $tasa;
                                        echo "<br><br>";
                            }
                            echo "<br>Monto ::".$new_monto."<br>";
                            if($new_monto > 0 )
                            {
                                if($cobrado > $new_max)
                                {
                                    $return = $new_max;
                                    $diferen =  $cobrado - $new_max; 
                                    $status = 2;
                                }else{
                                    $return = $cobrado;
                                    $status = 1;
                                } 
                                echo "===========================================================================<br>";

                                        $nueva = new Share();
                                        $nueva->user_id       = $user_id;
                                        $nueva->total_share   = $new_total;
                                        $nueva->price_share   = 10;
                                        $nueva->type          = 1;
                                        $nueva->moneda        = 3;
                                        $nueva->status        = $status;
                                        $nueva->start_date    = '2021-06-03';
                                        $nueva->amount        = $new_monto;
                                        $nueva->max_earning   = $new_max;
                                        $nueva->return_profit = $return;
                                        $nueva->price_dolar   = 1;

                                        print_r(json_decode($nueva));
                                        $nueva->save();
                                    echo "===========================================================================<br>";

                            }else{
                                $diferen = $cobrado;
                            }

                            return $diferen;

        }


        public function contratos_trx_vip($fecha, $user_id, $moneda,  $tasa = 0, $diferencia){
                                        
                        $contratos =  Share::where('type',0)->where('user_id', $user_id)->where('migrado','0')->orderBy('id')->
                        get();
                        $new_monto  = 0;
                        $new_monto_original = 0;
                        $new_max    =0;
                        $new_return = 0;
                        $new_total = 0;
                        echo "<hr>";
                            foreach($contratos as $data){
                                print_r(json_decode($data));
                                echo "<br><br>";

                                if($data->moneda == 2)  $tasa = 0.08;
                                if($data->moneda == 1)  $tasa = 2200;

                                        $fech_consulta = substr($data->created_at,0,10);

                                            $cal = Cripto_price::where('fecha', $fech_consulta)->where('moneda_id',$data->moneda)->first();
                                            echo "<br>".$fech_consulta."<br>";
                                            $tasa_dia = @$cal->price;
                                            $tasa_real = $tasa_dia;
                                             
                                            if($fech_consulta > '2021-02-28' && $fech_consulta  < '2021-05-01'){
                                                  
                                                if($data->moneda == 2 && $tasa_dia > 0.08 )  $tasa_dia = $tasa;
                                                if($data->moneda == 2 && $tasa_dia > 2200 )  $tasa_dia = $tasa;

                                                  echo "<br>".$fech_consulta." = ".$tasa_dia."<br>"; 
                                             }
                                        
                                            $new_monto += $data->amount * $tasa_dia;
                                            $new_monto_original += $data->amount * $tasa_dia;

                                            if($data->type ==0 )    $new_max += ($data->amount * $tasa_dia) * 3;
                                            else                    $new_max += ($data->amount * $tasa_dia) * 2;
                                        
                                             $new_return   += $data->return_profit *  $tasa;
                                            
                                            echo $data->amount * $tasa_real."  y ahora es ".$data->amount * $tasa_dia." y lo ganado hasta ahora es ".$data->return_profit *  $tasa_dia;
                                            echo "<br><br>";
                                          
                                            $data->migrado = 1;
                                            $data->status = 2;
                                            $data->save();
                                }
                            

                        echo "<br>Monto ::".$new_monto."<br>";

                            if($new_monto > 0 )
                            {
                                echo "<br> diferencia :: ".$diferencia."<==>".$new_max;
                                if($diferencia >= $new_max)
                                {
                                    $new_return = $new_max;
                                    $status = 2;
                                }else{
                                    $new_return = $diferencia;
                                    $status = 3;
                                }
                                echo "===========================================================================<br>";
                                            $nueva = new Share();
                                            $nueva->user_id       = $user_id;
                                            $nueva->type          = 0;
                                            $nueva->product_id    = 1;
                                            $nueva->moneda        = 3;
                                            $nueva->status        = $status;
                                            $nueva->total_share   = 1;
                                            $nueva->amount        = $new_monto;
                                            $nueva->max_earning   = $new_max;
                                            $nueva->return_profit = $new_return;
                                            $nueva->price_dolar   = 1;
                                            print_r(json_decode($nueva));
                                            $nueva->save();
                        
                                echo "===========================================================================<br>";
                            }

        }

        public function  insertar_tasa(){
                 
                $ether = array();
              
                $ether[29] = '2279.51';
                $ether[28] = '2419.91';
                $ether[27] = '2736.49';
                $ether[26] = '2888.70';
                $ether[25] = '2706.63'; 
                $ether[24] = '2643.59'; 
                $ether[23] = '2109.58'; 
                $ether[22] = '2295.71'; 
                $ether[21] = '2430.62'; 
                $ether[20] = '2784.29'; 
                $ether[19] = '2460.68'; 
                $ether[18] = '3380.07'; 
                $ether[17] = '3282.40'; 
                $ether[16] = '3587.51'; 
                $ether[15] = '3638.12'; 
                $ether[14] = '4079.06'; 
                $ether[13] = '3715.15'; 


                $tron = array();

                $tron['29'] = '0.07';
                $tron['28']   = '0.07'; 
                $tron['27']   = '0.08'; 
                $tron['26']   = '0.08'; 
                $tron['25']   = '0.08'; 
                $tron['24']   = '0.08'; 
                $tron['23']   = '0.06'; 
                $tron['22']   = '0.08'; 
                $tron['21']   = '0.08';   
                $tron['20']   = '0.09'; 
                $tron['19']   = '0.08'; 
                $tron['18']   = '0.12'; 
                $tron['17']   = '0.11'; 
                $tron['16']   = '0.12'; 
                $tron['15']   = '0.12'; 
                $tron['14']   = '0.12'; 
                $tron['13']   = '0.12'; 
                  

                print_r($tron);

              for($i=13; $i < 30; $i++ )
              {
                   $fecha = '2021-05-'.$i;
                   $new = new cripto_price();
                   $new->fecha = $fecha;
                   $new->price = $tron[$i];
                   $new->moneda_id = 2;

                   print_r(json_decode($new));
                   echo "<br>";
                   $new->save();
              }

              for($i=13; $i<30; $i++)
              {
                   $fecha = '2021-05-'.$i;

                   $new = new cripto_price();
                   $new->fecha = $fecha;
                   $new->price = $ether[$i];
                   $new->moneda_id = 1;

                   print_r(json_decode($new));
                   echo "<br>";
                   $new->save();
              }
        
        }
    

        








} 