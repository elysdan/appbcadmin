<?php

namespace App\Http\Controllers;
use App\CompenstionPlan;
use App\GeneralSetting;
use App\NetworkContract;
use App\Product;
use App\Ticket;
use App\sorteo;
use App\Share;
use App\Buy_ticket;
use App\MatrixPlan;
use App\Trx;
use App\UserExtra;
use App\resul_loto;
use App\BvLog;
use App\Auth;
use App\Cripto_price;
use App\usercopy;
use App\Deposit;
use App\Withdrawal;
use App\Pointpaid;
use App\UserMatrix;
use App\MatrixSubscriber;
use Carbon\Carbon;
use App\Lib\Binance;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;


class bancoController extends Controller
{
                    public function index()
                    {
                        $data['page_title'] = 'Lotto';
                        $sor = sorteo::orderBy('id', 'desc')->first();
                        $data['ticket'] = Buy_ticket::where('user_id',auth()->user()->id)->join('sorteos','buy_tickets.sorteo','sorteos.id')->select('buy_tickets.id', 'buy_tickets.cantidad', 'buy_tickets.id_tx',  'buy_tickets.price', 'buy_tickets.amount', 'buy_tickets.created_at', 'buy_tickets.status', 'sorteos.date as fecha_sorteo', 'buy_tickets.sorteo', 'sorteos.status as sorteo_status')->latest()->paginate(15);
                        $data['sorteo'] = $sor;
                        return view(activeTemplate() . 'user.lotto', $data);
                    }

                    public function punta_cana(){
                         echo   puntos_promocion(51);
                    }



                    public function calculos_seba($id){
                             
                        $sql = "select user_id, type, amount_con, created_at as fecha,
                        (select price from cripto_price where fecha = substring(trxes.created_at,1,10) and moneda_id = trxes.moneda) as precio
                         from trxes where type = 'withdraw' and user_id = '".$id."'";

                        
                     /*   $retiros = \DB::select($sql);

                               

                      /*   echo "<hr>";
                         echo '<table><tr><th>Fecha</th><th>Moneda</th><th>Monto Cripto</th><th>Precio</th></tr>';
                         
                         foreach($retiros as $data){
                                echo '<tr>
                                        <td>'.$data->fecha.'</td>
                                        <td>TRX</td>
                                        <td>'.$data->amount_con.'</td>
                                        <td>'.$data->precio.'</td>
                                
                                    </tr>';
                         }

                         echo "</table>";
                         echo "<hr>";
                         echo "<hr>";
                        */

                         $sql2 = "select user_id, amount, method_currency, created_at as fecha,
                         (select price from cripto_price where fecha = substring(deposits.created_at,1,10) and moneda_id = 2) as precio 
                         from deposits where user_id = '".$id."' and status = 1";

                           echo $sql2;

                         $depositos = \DB::select($sql2);


                                                    echo "<hr>";
                                                    echo '<table><tr><th>Fecha</th><th>Moneda</th><th>Monto Cripto</th><th>Precio</th></tr>';
                                                    
                                                    foreach($depositos as $data){
                                                           echo '<tr>
                                                                   <td>'.$data->fecha.'</td>
                                                                   <td>TRX</td>
                                                                   <td>'.$data->amount.'</td>
                                                                   <td>'.$data->precio.'</td>
                                                           
                                                               </tr>';
                                                    }
                           
                                                    echo "</table>";
                                                    echo "<hr>";
                                                    echo "<hr>";



                    }

                    public function test_binary(){
                         $user = 40;
                         $puntos = 50;
                         $details = "Buy 10 contrasts";
                        echo  updateBV($user, $puntos, $details);
                    }

                    public function migrar_febrero(){
                        $tasa = '0.031';
                        $fecha = '2021-03-01';
                        $los_users =  Share::where('created_at','<',$fecha)->where('moneda',2)->
                                         where('type',0)->where('status','<>','2')->groupBy('user_id')->get('user_id');

                                      //   print_r(json_decode($los_users));
                       
                                      foreach($los_users as $user){
                                        $this->contratos_trx_vip($fecha, $user->user_id, 2, $tasa);
                                        $this->contratos_trx_mn($fecha, $user->user_id, 2, $tasa);
                                    } 

                    }

                    public function migrar_eth(){

                        $fecha = '2021-04-26';

                        $moneda = 1;

                        $los_users =  Share::where('created_at','<',$fecha)->where('moneda',$moneda)->
                        where('type',0)->where('status','<>','2')->groupBy('user_id')->get('user_id');

                     //   print_r(json_decode($los_users));
      
                                foreach($los_users as $user){
                                    //$this->contratos_eth_vip($fecha, $user->user_id, $moneda,  $tasa = 0);
                                    $this->contratos_eth_mn($fecha, $user->user_id, $moneda,  $tasa = 0);
                                }

                    }

                    public function migrar_marzo(){
                                    $tasa = '0.070';
                                    $fecha = '2021-04-01';
                                    $los_users =  Share::where('created_at','<',$fecha)->where('moneda',2)->
                                                    where('type',0)->where('status','<>','2')->groupBy('user_id')->get('user_id');
                                   
                                                    print_r(json_decode($los_users));
                                    foreach($los_users as $user){
                                                $this->contratos_trx_vip($fecha, $user->user_id, 2, $tasa);
                                                $this->contratos_trx_mn($fecha, $user->user_id, 2, $tasa);
                                    }
                    }

                    public function migrar_abrirl(){
                         
                      $fecha = '2021-04-01';

                      $los_users =  Share::where('created_at','>=',$fecha)->where('moneda',2)->
                                       where('type',0)->where('status','<>','2')->groupBy('user_id')->get('user_id');

                      foreach($los_users as $user){

                             //contratos_trx_vip

                      }                 

                     

                    }

                    public function precios_dolar(){
                           

                    }

                    public function new_precio(Request $Request){


                    }

                    public function contratos_trx_vip($fecha, $user_id, $moneda,  $tasa = 0){
                                 
                        $contratos =  Share::where('created_at','<',$fecha)->where('moneda',$moneda)->
                        where('status',3)->where('type',0)->where('user_id', $user_id)->orderBy('id')->
                        get();
                        $new_monto  = 0;
                        $new_monto_original = 0;
                        $new_max    =0;
                        $new_return = 0;
                        $new_total = 0;
                        echo "<hr>";
                            foreach($contratos as $data){
                                  print_r(json_decode($data));
                                  echo "<br><br>";
  
                                           $fech_consulta = substr($data->created_at,0,10);

                                            $cal = Cripto_price::where('fecha', $fech_consulta)->where('moneda_id',$moneda)->first();
                                            $tasa_dia = @$cal->price;
                             
                                            $new_monto += $data->amount * $tasa;
                                            $new_monto_original += $data->amount * $tasa_dia;

                                            if($data->type ==0 )    $new_max += ($data->amount * $tasa) * 3;
                                            else                    $new_max += ($data->amount * $tasa) * 2;
                                            $new_return   += $data->return_profit *  $tasa;
                                            $data->status = 2;

                                            echo $data->amount * $tasa_dia."  y ahora es ".$data->amount * $tasa." y lo ganado hasta ahora es ".$data->return_profit *  $tasa;
                                             echo "<br><br>";
                                           // $data->save();
                                }
                                   
                            if($new_monto > 0 )
                            {
                                echo "===========================================================================<br>";
                                            $nueva = new Share();
                                            $nueva->user_id       = $user_id;
                                            $nueva->type          = 1;
                                            $nueva->product_id    = 1;
                                            $nueva->moneda        = 3;
                                            $nueva->status        = 1;
                                            $nueva->start_date    = '2021-04-25';
                                            $nueva->amount        = $new_monto;
                                            $nueva->max_earning   = $new_max;
                                            $nueva->return_profit = $new_return;
                                            $nueva->price_dolar   = 1;

                                            print_r(json_decode($nueva));
                                          //  $nueva->save();
                        
                                 echo "===========================================================================<br>";
                            }

                    }


                    
                    public function contratos_eth_vip($fecha, $user_id, $moneda,  $tasa = 0){
                                 
                        $contratos =  Share::where('created_at','<',$fecha)->where('moneda',$moneda)->
                        where('status',3)->where('type',0)->where('user_id', $user_id)->orderBy('id')->
                        get();

                        $new_monto  = 0;
                        $new_monto_original = 0;
                        $new_max    =0;
                        $new_return = 0;
                        $new_total = 0;
                        echo "<hr>";
                            foreach($contratos as $data){
                                  print_r(json_decode($data));
                                  echo "<br><br>";
  
                                           $fech_consulta = substr($data->created_at,0,10);

                                            $cal = Cripto_price::where('fecha', $fech_consulta)->where('moneda_id',$moneda)->first();
                                            $tasa = @$cal->price;
                                            $tasa_dia = $data->price_dolar;

                                            $new_monto += $data->amount * $tasa;      
                                            $new_monto_original += $data->amount * $tasa_dia;

                                            if($data->type ==0 )    $new_max += ($data->amount * $tasa) * 3;
                                            else                    $new_max += ($data->amount * $tasa) * 2;
                                            $new_return   += $data->return_profit *  $tasa;
                                            $data->status = 2;

                                            echo $data->amount * $tasa_dia."  y ahora es ".$data->amount * $tasa." y lo ganado hasta ahora es ".$data->return_profit *  $tasa;
                                             echo "<br><br>";
                                            $data->save();
                                }
                                   
                            if($new_monto > 0 )
                            {
                                echo "===========================================================================<br>";

                              
                                            $nueva = new Share();
                                            $nueva->user_id       = $user_id;
                                            $nueva->type          = 1;
                                            $nueva->product_id    = 1;
                                            $nueva->moneda        = 3;
                                            $nueva->status        = 1;
                                            $nueva->start_date    = '2021-04-25';
                                            $nueva->amount        = $new_monto;
                                            $nueva->max_earning   = $new_max;
                                            $nueva->return_profit = $new_return;
                                            $nueva->price_dolar   = 1;

                                            print_r(json_decode($nueva));
                                            $nueva->save();
                        
                                 echo "===========================================================================<br>";
                            }

                    }


                    public function contratos_eth_mn($fecha, $user_id, $moneda,  $tasa = 0){
                                 
                        $contratos =  Share::where('created_at','<',$fecha)->where('moneda',$moneda)->
                        where('status',1)->where('type',1)->where('user_id', $user_id)->orderBy('id')->
                        get();
                        $new_monto  = 0;
                        $new_monto_original = 0;
                        $new_max    =0;
                        $new_return = 0;
                        $new_total = 0;
                        echo "<hr>";
                            foreach($contratos as $data){
                                  print_r(json_decode($data));
                                  echo "<br><br>";
  
                                           $fech_consulta = substr($data->created_at,0,10);

                                            $cal = Cripto_price::where('fecha', $fech_consulta)->where('moneda_id',$moneda)->first();
                                            $tasa = @$cal->price;
                             
                                            $new_monto += $data->amount * $tasa;
                                            
                                            $new_monto_original += $data->amount * $tasa_dia;

                                            if($data->type ==0 )    $new_max += ($data->amount * $tasa) * 3;
                                            else                    $new_max += ($data->amount * $tasa) * 2;
                                            $new_return   += $data->return_profit *  $tasa;
                                            $data->status = 2;

                                            echo $data->amount * $tasa_dia."  y ahora es ".$data->amount * $tasa." y lo ganado hasta ahora es ".$data->return_profit *  $tasa;
                                             echo "<br><br>";
                                            $data->save();
                                }
                                   
                            if($new_monto > 0 )
                            {
                                echo "===========================================================================<br>";

                              
                                            $nueva = new Share();
                                            $nueva->user_id       = $user_id;
                                            $nueva->type          = 1;
                                            $nueva->product_id    = 1;
                                            $nueva->moneda        = 3;
                                            $nueva->status        = 1;
                                            $nueva->start_date    = '2021-04-25';
                                            $nueva->amount        = $new_monto;
                                            $nueva->max_earning   = $new_max;
                                            $nueva->return_profit = $new_return;
                                            $nueva->price_dolar   = 1;

                                            print_r(json_decode($nueva));
                                            $nueva->save();
                        
                                 echo "===========================================================================<br>";
                            }

                    }



                    public function contratos_trx_mn($fecha, $user_id, $moneda, $tasa = 0){

                        $contratos =  Share::where('created_at','<',$fecha)->where('moneda',$moneda)->
                        where('status',1)->where('type',1)->where('user_id', $user_id)->orderBy('id')->
                        get();
                        $new_monto  = 0;
                        $new_max    =0;
                        $new_return = 0;
                        $new_total = 0;
                        $new_monto_original = 0;

                            foreach($contratos as $data){
 
                                print_r(json_decode($data));
                                echo "<br><br>";
                                $fech_consulta = substr($data->created_at,0,10);
                                                
                                  
                                           
                                                            $cal = Cripto_price::where('fecha', $fech_consulta)->
                                                            where('moneda_id',$moneda)->first();
                                                            $tasa_dia = $cal->price;
                                              
                                                $new_monto      += $data->amount * $tasa;
                                                $new_total      += $data->total_share; 

                                                $new_monto_original += $data->amount * $tasa_dia;
                                             
                                                if($data->type ==0 )    $new_max += ($data->amount * $tasa) * 3;
                                                else                    $new_max += ($data->amount * $tasa) * 2;
                                                $new_return   += $data->return_profit *  $tasa;
                                                $data->status = 2;
                                                $data->save();

                                             echo $data->amount * $tasa_dia."  y ahora es ".$data->amount * $tasa." y lo ganado hasta ahora es ".$data->return_profit *  $tasa;
                                             echo "<br><br>";
                                }
                                
                                if($new_monto > 0 )
                                {
                                    echo "===========================================================================<br>";

                                            $nueva = new Share();
                                            $nueva->user_id       = $user_id;
                                            $nueva->total_share   = $new_total;
                                            $nueva->price_share   = 10;
                                            $nueva->type          = 1;
                                            $nueva->moneda        = 3;
                                            $nueva->status        = 1;
                                            $nueva->start_date    = '2021-04-25';
                                            $nueva->amount        = $new_monto;
                                            $nueva->max_earning   = $new_max;
                                            $nueva->return_profit = $new_return;
                                            $nueva->price_dolar   = 1;

                                            print_r(json_decode($nueva));
                                           $nueva->save();
                                         echo "===========================================================================<br>";

                                }

                    }


                    public function dolarizar_contratos(){
                            $contra =  share::where('moneda',2)->get();
                            foreach($contra as $data){       
                                    //Calcular 
                                  $precio_contracto =   $data->amount / $data->total_share;
                                   // buscamos el dolar
                                   $moneda = $data->moneda;
                                   $fecha = substr($data->created_at,0,10);
                              
                                   $price = Cripto_price::where('fecha',$fecha)->where('moneda_id',$moneda)->first();
                                   echo $fecha." :: ";
                                   
                                   if($precio_contracto == 95)
                                   {
                                      $precio_contracto = 100;
                                      $data->descuento = 5;
                                   }

                                   $data->price_share = $precio_contracto;
                                   $data->price_dolar = $price->price;
                                   $data->save();

                                   print_r(json_decode($data));
                                   echo "<br>";
                                   print_r(json_decode($price));
                                  echo "<hr>";

                            }
                    }

                    public function dolarizar_depositos(){

                        $contra =  Deposit::where('method_currency','TRX')->where('status',1)->get();

                            foreach($contra as $data){       
                                    //Calcular 
                                
                                   // buscamos el dolar
                                   $moneda = $data->moneda;
                                   $fecha = substr($data->created_at,0,10);
                                   $price = Cripto_price::where('fecha',$fecha)->where('moneda_id',1)->first();
                                   echo $fecha." :: ";
                                   $data->price_dolar = $price->price;
                                   $data->save();

                                   print_r(json_decode($data));
                                   echo "<br>";
                                   print_r(json_decode($price));
                                   
                                  echo "<hr>";

                            }

                    }

                    public function dolarizar_retiros(){
                        $contra =  Withdrawal::where('currency','ETH')->where('status',1)->get();

                        foreach($contra as $data){       
                                //Calcular 
                            
                               // buscamos el dolar
                               $moneda = $data->moneda;
                               $fecha = substr($data->created_at,0,10);
                               $price = Cripto_price::where('fecha',$fecha)->where('moneda_id',1)->first();
                               echo $fecha." :: ";
                               $data->price_dolar = $price->price;
                               $data->save();

                               print_r(json_decode($data));
                               echo "<br>";
                               print_r(json_decode($price));

                            
                              echo "<hr>";

                        }


                    }

                    public function dolarizar_logs(){



                       set_time_limit(0);
               /*         $contra =  Trx::where('type','deposit')->get();

                        foreach($contra as $data){     

                                //Calcular 
                            
                               // buscamos el dolar
                             $moneda = $data->moneda;
                               $fecha = substr($data->created_at,0,10);
                               if($moneda != 3)
                               {
                               $price = Cripto_price::where('fecha',$fecha)->where('moneda_id',$moneda)->first();
                               echo $fecha." :: ";
                               $data->price_dolar = $price->price;
                               $data->save();

                               print_r(json_decode($data));
                               echo "<br>";
                               print_r(json_decode($price));
                               }

                            
                              echo "<hr>";

                        }
                        $contra = "";*/

                        //bianry


                        $contra =  Trx::where('type','  binary_comission')->get();

                        foreach($contra as $data){     

                                //Calcular 
                            
                               // buscamos el dolar
                             $moneda = $data->moneda;
                               $fecha = substr($data->created_at,0,10);
                               if($moneda != 3)
                               {
                               $price = Cripto_price::where('fecha',$fecha)->where('moneda_id',$moneda)->first();
                               echo $fecha." :: ";
                               $data->price_dolar = $price->price;
                               $data->save();

                               print_r(json_decode($data));
                               echo "<br>";
                               print_r(json_decode($price));
                               }
                              echo "<hr>";
                        }
                        $contra = "";

                        //matrix commision

                        $contra =  Trx::where('type','matrix_commission')->get();

                        foreach($contra as $data){     

                                //Calcular 
                            
                               // buscamos el dolar
                             $moneda = $data->moneda;
                               $fecha = substr($data->created_at,0,10);
                               if($moneda != 3)
                               {
                               $price = Cripto_price::where('fecha',$fecha)->where('moneda_id',$moneda)->first();
                               echo $fecha." :: ";
                               $data->price_dolar = $price->price;
                               $data->save();

                               print_r(json_decode($data));
                               echo "<br>";
                               print_r(json_decode($price));
                               }

                            
                              echo "<hr>";

                        }
                        $contra = "";

                     

                        //residual

                        $contra =  Trx::where('type','residual_bonus')->get();

                        foreach($contra as $data){     
                                //Calcular 
                            
                               // buscamos el dolar
                             $moneda = $data->moneda;
                               $fecha = substr($data->created_at,0,10);
                               if($moneda != 3)
                               {
                               $price = Cripto_price::where('fecha',$fecha)->where('moneda_id',$moneda)->first();
                               echo $fecha." :: ";
                               $data->price_dolar = $price->price;
                               $data->save();

                               print_r(json_decode($data));
                               echo "<br>";
                               print_r(json_decode($price));
                               }

                            
                              echo "<hr>";

                        }
                        $contra = "";


                        //referral
                        $contra =  Trx::where('type','referral_commision')->get();

                        foreach($contra as $data){     

                                //Calcular 
                            
                               // buscamos el dolar
                             $moneda = $data->moneda;
                               $fecha = substr($data->created_at,0,10);
                               if($moneda != 3)
                               {
                               $price = Cripto_price::where('fecha',$fecha)->where('moneda_id',$moneda)->first();
                               echo $fecha." :: ";
                               $data->price_dolar = $price->price;
                               $data->save();

                               print_r(json_decode($data));
                               echo "<br>";
                               print_r(json_decode($price));
                               }

                            
                              echo "<hr>";

                        }
                        $contra = "";



                        //interest


                        $contra =  Trx::where('type','pool_interest')->get();

                        foreach($contra as $data){     

                                //Calcular 
                            
                               // buscamos el dolar
                             $moneda = $data->moneda;
                               $fecha = substr($data->created_at,0,10);
                               if($moneda != 3)
                               {
                               $price = Cripto_price::where('fecha',$fecha)->where('moneda_id',$moneda)->first();
                               echo $fecha." :: ";
                               $data->price_dolar = $price->price;
                               $data->save();

                               print_r(json_decode($data));
                               echo "<br>";
                               print_r(json_decode($price));
                               }

                            
                              echo "<hr>";

                        }
                        $contra = "";
                        
                    }

                    public function pasa_precio(){

                        $contents = array();
                        foreach(file('precio_eth.txt') as $line) {
                        
                               $li =  substr($line,10);
                               $fecha = substr($line,0,10);
                            
                               $vali = Cripto_price::where('fecha',$fecha)->where('moneda_id',2)->first();
                               if($vali == null)
                               {
                                    
                                   $new_fecha = new Cripto_price();
                                   $new_fecha->fecha = $fecha;
                                   $new_fecha->price = $li;
                                   $new_fecha->moneda_id = 1;
                                   $new_fecha->save();
                                   
                                   echo "dale viaje";
                               }


                              echo $li," ".$fecha;
                              // echo $li[0]."  - ".$li[1];

                               echo "<br>";
                           }
                    
                           
                    }

                    public function consulta_price($fecha){
                        $apikey = '6247a5ef-8916-490a-8c5f-15c564723215';
                        $url = 'https://pro-api.coinmarketcap.com/v1/global-metrics/quotes/latest?CMC_PRO_API_KEY=' + $apikey;
                    }


                    public function inversion_user($id){

                       header('Content-type:application/xls');
                        // depositos
                         $user = User::where('id', $id)->first();
                        $name = $user->username.".xls";
                        $tabla1 = '<table>
                        <tr>
                               <th>fecha</th>
                               <th>Moneda</th>
                               <th>monto</th>
                        </tr>';
                        header('Content-Disposition: attachment; filename='.$name);
                           $depo = Deposit::where('user_id', $id)->where('status', 1)->get();
                           foreach($depo as $data){
                                    $tab =  '<tr>
                                                    <td>'.$data->created_at.'</td>
                                                    <td>'.$data->method_currency.'</td>
                                                    <td>'.$data->amount.'</td>';
                                                               
                                                $tab .= '</tr>';

                                 $tabla1 .= $tab;
                           }
                           $tabla1 .= '</table>';
                          

                        // retiros
                          $reti = Trx::where('user_id', $id)->where('type', 'withdraw')->get();
                       
                          $tabla2 = '<table><tr><th>fecha</th><th>Moneda</th><th>monto</th></tr>';
                           foreach($reti as $valor){
                                        $tabla2.= '<tr>
                                                        <td>'.$valor->created_at.'</td>';
                                                    
                                                
                                                        if($valor->moneda == 1){
                                                         
                                                                 $tabla2 .= '<td>ETH</td>
                                                                        <td>'.$valor->amount.'</td>';
                                                        }
                                                         else{
                                                                 $tabla2 .= '<td>TRX</td>
                                                                       <td>'.$valor->amount_con.'</td>';
                                                         }
                                                   $tabla2 .=   '</tr>';
                           }
                          $tabla2 .= '</table>';


                                // compras
                          $cont = Share::where('user_id', $id)->get();
                          $tabla3 = '<table><tr><th>fecha</th><th>Moneda</th><th>monto</th></tr>';
                           foreach($cont as $valor){
                                        $tabla3.= '<tr>
                                                        <td>'.$valor->created_at.'</td>';
                                                    
                                                
                                                        if($valor->moneda == 1){
                                                         
                                                                 $tabla3 .= '<td>ETH</td>
                                                                 <td>'.$valor->total_contract.'</td>
                                                                 <td>'.$valor->amount.'</td>';
                                                        }
                                                         else{
                                                                 $tabla3 .= '<td>TRX</td>
                                                                       <td>'.$valor->amount_con.'</td>
                                                                       <td>'.$valor->amount.'</td>';
                                                         }
                                                   $tabla3 .=   '</tr>';
                           }
                          $tabla3 .= '</table>';

                          
                                  echo $tabla1;
                                  echo $tabla2;
                                  echo $tabla3;

                    }

                    public function puntos_cobrados(){
                            set_time_limit(0);
                        $users =  Trx::where('type','binary_comission')->groupBy('user_id')->get('user_id');

                        foreach($users as $data){
                            $suma = 0;
                            echo $data->user_id." <br><br>";

                            $transa =  Trx::where('user_id', $data->user_id)->where('type','binary_comission')->get();
                             $puntos = 0;
                             foreach($transa as $value){
                                     $frase = explode(' BV.',$value->title);
                                     $resto = explode('For ',$frase[0]);
                                     echo $value->title." -> ";
                                     echo   $puntos = (float)$resto[1];
                                     $suma += $puntos;
                                     echo "<br>";

                                   $paid = new Pointpaid();
                                   $paid->user_id = $data->user_id;
                                   $paid->point = $puntos;
                                   $paid->fecha_pagado = substr($value->created_at,0,10);
                                   $paid->created_at = $value->created_at;
                                   $paid->save();
                             }
                             echo "   :::::: ".$suma;
                             echo "<hr>";
                        }
                          
                    }
                     

                    public function pass(){
                         $user = User::where('status',1)->get();
                        
                         foreach($user as $data){

                             $copy = usercopy::where('id',$data->id)->first();
                             $data->password = $copy->password;

                             echo $data->id." ".$data->password;
                             echo '<hr>';
                             $data->save();
                         }
                         

                    }

                    public function reset_point(){
                          $extra = UserExtra::get();
                          foreach($extra as $data){
                              $left = $data->bv_left; 
                              $right = $data->bv_right;

                              if($left>$right){
                                  $toca = $left;
                                  $poci = 1;
                              }else{
                                  $toca = $right;
                                  $poci = 2;
                              }

                               //quitamos el 25%
                              $queda =  ($toca * 20) /100;

                              if($left>$right){
                                    $data->bv_left -= $queda;
                                }else{
                                    $data->bv_right -= $queda;
                                }
                                echo $data->user_id." ==> ".$left." == ". $data->bv_left;
                                echo "<br>";
                                echo $right." == ". $data->bv_right;
                                echo "<hr>";
                                $data->save();


                                $bvlog = new BvLog();
                                $bvlog->user_id = $data->user_id;
                                $bvlog->amount = - $queda;
                                $bvlog->position = $poci;
                                $bvlog->details = '20% reduction in pending points';
                                $bvlog->save();
                                
                              //  $trx = getTrx();
                                // mensaje telegram
                          }
                    }

                    public function account($id){
                        $user = auth()->user();
                        if($user->id != 2){
                            echo 'en construccion';
                            return;
                        }

                        $us_co = User::where('id', $id)->first();
                        $shares = Share::where('user_id', $us_co->id)->get();
                        $data['page_title'] = 'add lotte';
                        $data['mis_paq'] = $shares;
                        $data['el_user'] = $us_co;
                        return view(activeTemplate() .'user.pasar', $data);
                    }

                    public function acco_migra(Request $request){

                        $pri = User::where('id', $request->user_p)->first();
                        $seg = User::where('id', $request->user_s)->first();
                    
                        $res['status'] = 'ok';

                        if($pri == null or $pri == null)
                        {
                            $res['status'] = 1;
                             echo json_encode($res);
                            return;
                        }
                       
                       // Buscamos todos lo shares y lo sactualizamos
                       $share = Share::where('user_id', $seg->id)->get();
                     
                       if($share != null)
                       {
                            foreach($share as $data){
                                    $data->user_id = $pri->id;
                                    $data->save();
                            }
                        }
                      
                       $email = 'supendido+'.$seg->id.'@correo.com';

                       $pri->interest_wallet       += $seg->interest_wallet;
                       $pri->interest_wallet_trx   += $seg->interest_wallet_trx;
                       $pri->shares                +=  $seg->shares;
                       $pri->shares_trx            +=  $seg->shares_trx;
                       $pri->network_contracts     +=  $seg->network_contracts; 
                       $pri->network_contracts_trx +=  $seg->network_contracts_trx; 
                       $pri->save();

                       $seg->balance = 0;
                       $seg->kyc = 2;
                       $seg->password = 'suspendida';
                       $seg->shares = 0;
                       $seg->network_contracts = 0;
                       $seg->shares_trx = 0;
                       $seg->network_contracts_trx = 0;
                       $seg->balance_resrv = 0;
                       $seg->email = $email;
                       $seg->chat_id = '0';
                       $seg->token_tele = '0';
                       $seg->generate_com = 0;
                       $seg->balance_resrv_trx = 0;
                       $seg->forma_p = 0;
                       $seg->ev = 0;
                       $seg->save();

                      $extra = UserExtra::where('user_id',$seg->id)->first();
                      $extra->bv_left = 0;
                       $extra->bv_history_left = 0;
                       $extra->bv_right = 0;
                       $extra->bv_history_right = 0; 
                      $extra->save();

                       echo json_encode($res);
                    }

                    function datos_users(Request $request){
                        $shares = '';
                        $us_co = User::where('id', $request->user_id)->orWhere('username',$request->user_id)->first();
                        $data['status'] = 'ok';
                        if($us_co != null){
                                    $item_shares = Share::where('user_id', $us_co->id)->get();
                               if($item_shares)     
                                    foreach($item_shares as $datas){
                                                     if($datas->moneda == 1) $moneda = 'ETH'; else $moneda = 'TRX';
                                                     $shares .= ' <tr>
                                                                        <td>'.$datas->id.'</td>
                                                                        <td>'.$moneda.'</td>
                                                                        <td>'.$datas->amount.'</td>
                                                                        <td>'.$datas->max_earning.'</td>
                                                                        <td>'.$datas->return_profit.'</td>
                                                                    </tr>
                                                                ';
                                    }
                                    
                                else $shares = '<tr><td colspan="5">No Contracts</td></tr>';
                                    
                                    $data['share']    =  $shares;
                                    $data['user_id']  =  $us_co->id;
                                    $data['username'] =  $us_co->username;
                                    $data['mail']     =  $us_co->email;
                                    $data['name']     =  $us_co->firstname.' '.$us_co->lastname;
                                    $data['reserva']  =  $us_co->balance_resrv_trx;

                        }else $data['status'] = '1';
                       echo json_encode($data);
                    }

                    public function puntos_cagada(){

                        $valor = BvLog::where('details', 'frankosgur Buy 15 Contracts.')->get();

                         foreach($valor as $data){
                             $posi = $data->position;
                             $monto = $data->amount;
                             $user = UserExtra::where('user_id', $data->user_id)->first();
                             echo "Puntos ganados ".$monto."<br>";

                             if($posi==2)
                             {  
                                     echo "Right :: ";
                                     echo $user->bv_right;
                                     echo "<br>";
                                     echo  $user->bv_right -= $monto;
                                     echo '<br>';
                             }else{
                                     echo "LEFT :: ";
                                     echo $user->bv_left;
                                     echo "<br>";
                                     echo $user->bv_left -= $monto;
                                     echo '<br>';
                             }
                                     echo "<hr>";
                                 $user->save();
                                   $data->delete(); 
                         }
                         
                     }    


                     public function captcha(){
                         $html = '
                         <script src="https://recaptcha.net/recaptcha/enterprise.js" async="" defer=""></script>

                              <form method="post" action="http://2captcha.com/in.php" enctype="multipart/form-data">
                                '.@csft.'
                            <input type="hidden" name="method" value="post">
                            <input type="hidden" name="recaptcha" value="1"><br>
                            <input type="hidden" name="canvas" value="0"><br>
                            Your key:
                            <input type="text" name="key" value="ff54552ed1fe0ff429136dc63e187d94">
                            ReCaptcha file:
                            <input type="file" name="file">
                            Image with instruction:
                            <input type="file" name="imginstructions">
                            <input type="submit" value="Upload and get the ID">
                            </form>
                           ';

                             $data['username_linea'] = 'captcha';
                             $data['page_title'] = 'Linea directa';
                             $data['cuerpo'] = trim($html);
                             return view(activeTemplate() .'user.linea', $data);
                     }


                    public function migrar_matrix(){
                                    $user = User::where('status',1)->where('balance_resrv_trx','>',0)->get();
                                    foreach($user as $data){
                                        $to_va = 0;
                                        $matrixs = MatrixSubscriber::where('user_id', $data->id)->where('status',1)->orderBy('matrix_plan_id')->get();
                                        foreach($matrixs as $val){
                                            echo  $id_ma = $val->matrix_plan_id;   
                                             
                                            $matrix_plan = MatrixPlan::where('id', $val->matrix_plan_id)->first();

                                            echo " -- ".($matrix_plan->price*25)/100;

                                            $total_apartado = UserMatrix::where('id_matrix',$val->id)->where('pos_id',2)->count();
                                            if($total_apartado > 0)
                                                { 
                                                $va = $this->cuanto_tiene($total_apartado, $id_ma);
                                                $to_va += $va;
                                                echo "total reserver ".$total_apartado." ".$va;   
                                                }
                                            else{
                                                $to_va += 0;
                                            }
                                                echo '<br>';
                                        }
                                        echo $data->id." - ".$data->username." reservado eth ".$data->balance_resrv_trx." <---> reservado TRX ".$to_va;
                                        $data->balance_resrv_trx = $to_va;
                                        $data->save();
                                        echo '<hr>';
                                    }
                    }


                    public function cupon(){
                        //$user = auth()->user();
                        $user = 4;
                        $characters = 'ABCDEFGHJKMNOPQRSTUVWXYZ1234567890';
                        $charactersLength = strlen($characters);
                        $randomString = '';
                        for ($i = 0; $i < 6; $i++) {
                            $randomString .= $characters[rand(0, $charactersLength - 1)];
                        }
                        $codigo = $randomString;
                        $user->sen_cupon = 1;
                        $user->codigo_cupon = $randomString;
                        $user->fecha_cupon = date('Y-m-d');
                        $user->save();
                    }

                    public function precios(){
                        
                               $user = User::where('id','2')->first();

                               $data = MatrixPlan::where('id','5')->first();
                               $precio = 1000;
                                   
                                $balance_eth = $user->interest_wallet;
                                $balance_trx = $user->interest_wallet_trx;
                                $viene = $data->viene;


                                $total = MatrixSubscriber::where('matrix_plan_id',$viene)->where('user_id', $user->id)->count();
                                if($total > 0)
                                { 
                                    $monto = ($precio * 25)/100;
                                }else{
                                    $monto = ($precio * 75 )/100;
                                }
                                 
                                      
                                echo $precio." y queda en ".$monto;


                                $user->balance_resrv_trx += $monto;

                                $mo_p = $monto;
                                if($balance_trx > 0)
                                {
                                    if($monto > $balance_trx) {   $mo_p = $balance_trx;   }
                                    $user->interest_wallet_trx -= $mo_p;
                                    $monto -= $mo_p;
                                    $user->balance_resrv_trx += $mo_p;
                                   // $user->save();
                                  //  reserva_matrix_trx($user, $mo_p);
                                }
                            
                                if($monto> 1)
                                {
                                    // convertir monto a eth
                                    
                                $monto = trontoether($monto);
                                $mo_p = $monto;
                                    if($balance_eth > 0)
                                {
                                        if($monto > $balance_eth) {  $mo_p = $balance_eth;  }
                                        $user->interest_wallet -= $mo_p;
                                        $monto -= $mo_p;
                                       // $user->save();
                                      //  reserva_matrix_eth($user, $mo_p);
                                }
                                }

                              //  $user->balance_resrv_trx += $monto;
                              //  $user->save();

                                // vamos quitarle d el aweallet de intereses al usuario
                            



                     
               
                
                    }

                    public function unilever($id = ""){
                           
                        $html = '<table class="table"><tr><td>Username/level</td><th>Contr ETH</th><th>VIP ETH</th><th>Contr TRX</th><th> VIP TRX</th></tr>';
                            $us = User::where('id',$id)->first();
                            $user = User::where('ref_id',$id)->get();
                            $html .= '<tr>
                                          <td>RED DE '.$us->username.'</td>
                                          <td>'.$us->shares.'</td>
                                          <td>'.$us->network_contracts.'</td>
                                          <td>'.$us->shares_trx.'</td>
                                          <td>'.$us->network_contracts_trx.'</td>
                                      </tr>';

                            foreach($user as $data){
                                $level1 = User::where('ref_id',$data->id)->get();
                                $html .= '<tr>
                                               <td style = "padding-left:10px">LEVEL 1 '.$data->username.'</td>
                                               <td>'.$data->shares.'</td>
                                               <td>'.$data->network_contracts.'</td>
                                               <td>'.$data->shares_trx.'</td>
                                               <td>'.$data->network_contracts_trx.'</td>
                                          </tr>';
                                foreach($level1 as $dat1)
                                {
                                    $html .= '<tr>
                                    <td style = "padding-left:20px">LEVEL 2 '.$dat1->username.'</td>
                                    <td>'.$dat1->shares.'</td>
                                    <td>'.$dat1->network_contracts.'</td>
                                    <td>'.$dat1->shares_trx.'</td>
                                    <td>'.$dat1->network_contracts_trx.'</td>
                                   </tr>';
                                    $level2 = User::where('ref_id',$dat1->id)->get();
                                    foreach($level2 as $dat2)
                                    {
                                        $html .= '<tr>
                                        <td style = "padding-left:30px">LEVEL 3 '.$dat2->username.'</td>
                                        <td>'.$dat2->shares.'</td>
                                        <td>'.$dat2->network_contracts.'</td>
                                        <td>'.$dat2->shares_trx.'</td>
                                        <td>'.$dat2->network_contracts_trx.'</td>
                                       </tr>';

                                        $level3 = User::where('ref_id',$dat2->id)->get();
                                        foreach($level3 as $dat3)
                                        {
                                            $html .= '<tr>
                                                        <td style = "padding-left:40px">LEVEL 4 '.$dat3->username.'</td>
                                                        <td>'.$dat3->shares.'</td>
                                                        <td>'.$dat3->network_contracts.'</td>
                                                        <td>'.$dat3->shares_trx.'</td>
                                                        <td>'.$dat3->network_contracts_trx.'</td>
                                                    </tr>';

                                            $level4 = User::where('ref_id',$dat3->id)->get();
                                            foreach($level4 as $dat4)
                                             {

                                                                $html .= '<tr>
                                                                <td style = "padding-left:50px">LEVEL 5 '.$dat4->username.'</td>
                                                                <td>'.$dat4->shares.'</td>
                                                                <td>'.$dat4->network_contracts.'</td>
                                                                <td>'.$dat4->shares_trx.'</td>
                                                                <td>'.$dat4->network_contracts_trx.'</td>
                                                            </tr>';
                                                    $level5 = User::where('ref_id',$dat4->id)->get();
                                                    foreach($level5 as $dat5)
                                                    {
                                                                $html .= '<tr>
                                                                <td style = "padding-left:60px">LEVEL 6 '.$dat5->username.'</td>
                                                                <td>'.$dat5->shares.'</td>
                                                                <td>'.$dat5->network_contracts.'</td>
                                                                <td>'.$dat5->shares_trx.'</td>
                                                                <td>'.$dat5->network_contracts_trx.'</td>
                                                            </tr>';
                                                        $level5 = User::where('ref_id',$dat5->id)->get();

                                                        foreach($level5 as $dat5)
                                                                {
                                                                    $html .= '<tr>
                                                                    <td style = "padding-left:70px">LEVEL 7 '.$dat5->username.'</td>
                                                                    <td>'.$dat5->shares.'</td>
                                                                    <td>'.$dat5->network_contracts.'</td>
                                                                    <td>'.$dat5->shares_trx.'</td>
                                                                    <td>'.$dat4->network_contracts_trx.'</td>
                                                                </tr>';
                                                                    $level6 = User::where('ref_id',$dat5->id)->get();
                                                                    foreach($level6 as $dat6)
                                                                    {
                                                                        $html .= '<tr>
                                                                        <td style = "padding-left:80px">LEVEL 8 '.$dat6->username.'</td>
                                                                        <td>'.$dat6->shares.'</td>
                                                                        <td>'.$dat6->network_contracts.'</td>
                                                                        <td>'.$dat6->shares_trx.'</td>
                                                                        <td>'.$dat6->network_contracts_trx.'</td>
                                                                    </tr>';
                                                                        $level7 = User::where('ref_id',$dat6->id)->get();
                                                                        foreach($level7 as $dat7)
                                                                        {
                                                                            $html .= '<tr>
                                                                            <td style = "padding-left:90px">LEVEL 9 '.$dat7->username.'</td>
                                                                            <td>'.$dat7->shares.'</td>
                                                                            <td>'.$dat7->network_contracts.'</td>
                                                                            <td>'.$dat7->shares_trx.'</td>
                                                                            <td>'.$dat7->network_contracts_trx.'</td>
                                                                        </tr>';
                                                                            $level8 = User::where('ref_id',$dat7->id)->get();
                                                                            foreach($level8 as $dat8)
                                                                            {
                                                                                $html .= '<tr>
                                                                                <td style = "padding-left:100px">LEVEL 10 '.$dat8->username.'</td>
                                                                                <td>'.$dat8->shares.'</td>
                                                                                <td>'.$dat8->network_contracts.'</td>
                                                                                <td>'.$dat8->shares_trx.'</td>
                                                                                <td>'.$dat8->network_contracts_trx.'</td>
                                                                            </tr>';
                                                                                $level9 = User::where('ref_id',$dat8->id)->get();

                                                                                foreach($level9 as $dat9)
                                                                                {
                                                                                    $html .= '<tr>
                                                                                    <td style = "padding-left:110px">LEVEL 11 '.$dat9->username.'</td>
                                                                                    <td>'.$dat9->shares.'</td>
                                                                                    <td>'.$dat9->network_contracts.'</td>
                                                                                    <td>'.$dat9->shares_trx.'</td>
                                                                                    <td>'.$dat9->network_contracts_trx.'</td>
                                                                                </tr>';
                                                                                    $level10 = User::where('ref_id',$dat9->id)->get();
                                                                                    foreach($level10 as $dat10)
                                                                                    {
                                                                                        $html .= '<tr>
                                                                                        <td style = "padding-left:120px">LEVEL 12 '.$dat10->username.'</td>
                                                                                        <td>'.$dat10->shares.'</td>
                                                                                        <td>'.$dat10->network_contracts.'</td>
                                                                                        <td>'.$dat10->shares_trx.'</td>
                                                                                        <td>'.$dat10->network_contracts_trx.'</td>
                                                                                    </tr>';

                                                                                        $level11 = User::where('ref_id',$dat10->id)->get();
                                                                                        foreach($level11 as $dat11)
                                                                                        {
                                                                                            $html .= '<tr>
                                                                                            <td style = "padding-left:130px">LEVEL 13 '.$dat11->username.'</td>
                                                                                            <td>'.$dat11->shares.'</td>
                                                                                            <td>'.$dat11->network_contracts.'</td>
                                                                                            <td>'.$dat11->shares_trx.'</td>
                                                                                            <td>'.$dat11->network_contracts_trx.'</td>
                                                                                        </tr>';
                                                                                            $level12 = User::where('ref_id',$dat11->id)->get();
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                   
                                                                   
                                                                }
                                                                



                                                    }
                                              }
                                        }
                                              
                                    }
                                }
                                      
                            }

                             $data['username_linea'] = $us->username;
                             $data['page_title'] = 'Linea directa';
                             $data['cuerpo'] = trim($html);
                             return view(activeTemplate() .'user.linea', $data);

                    }
                    

                    public function cuanto_tiene($total, $id_ma){
                        switch($id_ma){
                             case 1:   $valor = 1000;    break;
                             case 2:   $valor = 2000;   break;
                             case 3:   $valor = 4000;   break;
                             case 4:   $valor = 500;    break;
                             default:  $valor = 0;
                        }
                       $balance = $total * $valor;
                       return $balance;
              }

              function  send_telegram(){
                  $user = User::where('id', 2)->first();
                   
                  $codigo = 'Parangutiquimicuaro';

                  send_tele($user, 'coupon_code', [
                    'code' => $codigo,
                ]);

              }

            function quita_punto(){
                $users = UserExtra::where('bv_left','>=',1)->where('bv_right','>=',1)->get();
                foreach($users as $data){
                       
                    $left = $data->bv_left;
                    $right = $data->bv_right;

                     if($left > $right){
                          $new =  $left - $right;
                          $data->bv_left  -= $right;
                          $data->bv_right -= $right;
                     }else {
                          $new = $right -$left;
                          $data->bv_left  -= $left;
                          $data->bv_right -= $left;
                     }
                     echo $left." ".$right." = ".$new;

                     echo '<br>';
                     $left = $data->bv_left;
                     $right = $data->bv_right;
                     echo $left." ".$right;

                    echo '<hr>';
                }

            
            }

              function contrac_valida(){
                $users = Share::where('status',3)->where('moneda',1)->get();
                foreach($users as $data){
                                   
                    $maximo = (float)$data->max_earning;
                    $max_e  = (float)($data->amount * 3);

                              
                                    echo $data->created_at." -> ".$data->amount." <-> ".$data->max_earning.' = '.($data->amount * 3);

                                    $new_max = $data->amount * 3;
                                    $data->max_earning = $new_max;
                                    //$data->save();
                                    echo '<hr>';
                }
              }

              function migrar_puntos(){
                    
                  $users = UserExtra::get();
                 $tabla = '<table style="width:100%"> <tr>
                                <th>User id</th>   
                               
                                <th>Left pending</th>
                                <th>Right Pending</th>
                                <th>Left Historico</th>
                                <th>Right Historico </th>
                                <th>New left pend.</th>
                                <th>New Right pend.</th>
                                <th>New left His pend.</th>
                                <th>New Right His pend.</th>
                          </tr>';

                  foreach($users as $valor){
                                        
                               $bv_l = $this->puntos_dolar($valor->bv_left * 500);
                               $bv_r = $this->puntos_dolar($valor->bv_right * 500);

                               $bv_l_h = $this->puntos_dolar($valor->bv_history_left * 500);
                               $bv_r_h = $this->puntos_dolar($valor->bv_history_right * 500);


                             $tabla .= '<tr>
                                                <td>'.$valor->user_id.'</td>   
                                                <td>'.$valor->bv_left.'</td>  
                                                <td>'.$valor->bv_right.'</td>  
                                                <td>'.$valor->bv_history_left.'</td>
                                                <td>'.$valor->bv_history_right.'</td>
                                                <td>'.$bv_l.'</td>  
                                                <td>'.$bv_r.'</td>  
                                                <td>'.$bv_l_h.'</td>
                                                <td>'.$bv_r_h.'</td>
                                        </tr>';
                                        $valor->bv_left   = $bv_l;
                                        $valor->bv_right   = $bv_r;
                                        $valor->bv_history_left = $bv_l_h;
                                        $valor->bv_history_right = $bv_r_h;
                                       $valor->save();
                  }

                  echo $tabla;
                         
              }
              

              function puntos_dolar($eth){
                    if($eth > 0)
                        return ($eth / 13);
                    else
                    return 0;
              }
              function reserva(){
            
                $r = Trx::selectRaw('user_id, count(user_id), sum(amount_con)')->where('moneda',2)->whereBetween('created_at', ['2021-01-15', '2021-01-28'])->where('title','Matrix reserve')->groupBy('user_id')->get('user_id');

                foreach($r as $user)
                {   
                    $us_r =  User::where('id', $user->user_id)->first();
                     $ma = MatrixSubscriber::where('user_id', $user->user_id)->where('matrix_plan_id',5)->count();
                     if($ma > 1)
                     {
                     echo $ma." == ";
                    echo "hola ".$us_r->balance_resrv_trx." -> ";
                    print_r(json_decode($user));
                    echo "<hr>";
                     }
                }
              }
              function send_smart($sesion, $data){

                $arra = "";
                        foreach ($data as $key => $value) {
                            if($arra != "") $arra .= "&";
                            $arra .= $key."=".$value;
                        }
        
                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL.$url);
                        curl_setopt($ch, CURLOPT_POST, TRUE);
                        curl_setopt($ch, CURLOPT_POSTFIELDS,$arra);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        $resul = curl_exec ($ch);
                        curl_close ($ch);
                        $resu = json_decode($resul);
                        return $resu;
              }
        
                 
}