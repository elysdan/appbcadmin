<?php

namespace App\Http\Controllers;
use App\CompenstionPlan;
use App\GeneralSetting;
use App\Product;
use App\Trx;
use App\User;
use App\Share;
use App\pago;
use App\Prew_withdraw;
use App\UserExtra;
use Carbon\Carbon;
use App\Deposit;
use App\Buy_ticket;
use App\Ticket;
use App\sorteo;
use App\Withdrawal;
use App\Http\base58;
use App\WithdrawMethod;
use App\NetworkContract;
use Illuminate\Http\Request;
use App\GatewayCurrency;
use Illuminate\Support\Facades\Auth;

class confirmW extends Controller
{
      public function validar(){
                    set_time_limit(0);
                    $lotes = pago::where('status',1)->get();
                    foreach($lotes as $pag){
                        $this->valida_trans($pag);
                    }
      }

      public function valida_trans($pag){
                             $res['status'] = 'ok';
                             $url = "https://api.trongrid.io/v1/transactions/".$pag->id_tx."/events";
                             $res =   file_get_contents($url);
                             $res =json_decode($res);

                             $tota_send = Prew_withdraw::where('pago_id',$pag->id)->count();
                             $fecha_pago = $pag->updated_at;
                             $fechaActual = Carbon::now();
                             $diferencia = $fechaActual->diffInMinutes($fecha_pago);
                             $i = 0;
                               echo  count($res->data);
                            if(count($res->data) > 0)
                            {
                                   foreach($res->data as $data )
                                    {   

                                        $total = $this->contar($res->data[0]);
                                       if($total == 9)
                                        {
                                            $contr_user = $data->result->user;
                                            $contr_status = $res->success;
                                            $monto = $data->result->amount/1000000;
                                                        if( $contr_status == "1" )
                                                        {
                                                            $i++;
                                                        }
                                        }else{
                                            return;
                                        }
                                    }
                                   echo "<br>";
                                    echo $i." ".$tota_send;
                                   echo '<br>===========';
                                    if($tota_send  == $i )
                                    {
                                        $this->send_register($pag);
                                    }
                             }
                             else{
                                    if($diferencia > 7200){
                                        $pag->status = 2;
                                        $pag->save();
                                    }
                             }   
                    
                            return $res;
      }   


      public function send_register($pago){
           $method = WithdrawMethod::where('id',2)->first();
           $pago->status = 3;
           $pago->save();
           $pay = Prew_withdraw::where('pago_id',$pago->id)->get();   
           $hash = (string)$pago->id_tx;

           foreach($pay as $pa){
           
                            $wdamo            = $pa['solicitud_eth'];
                            $charge           = $pa['carga_eth'];
                            $amountSend       = $pa['enviado_eth'];
                            $wdamo_con        = $pa['solicitud_trx'];
                            $charge_con       = $pa['carga_trx'];
                            $amountSend_con   = $pa['enviado_trx'];
                            $interes_wallet   = $pa['balance'];
                            $wdamo_trx        = $pa['balance'];
                            $wdamo_eth        = $pa['balance_trx'];
                            $tnxnum           = $pa['trx'];
                            $user = User::findOrFail($pa['user_id']);
                            
                            $tnxnum =  getTrx();
                            $withdraw = new Withdrawal();
                            $withdraw->method_id = $method->id;
                            $withdraw->user_id = $user->id;
                            $withdraw->amount = formatter_money($wdamo);
                            $withdraw->charge = formatter_money($charge);
                            $withdraw->rate = 1;
                            $withdraw->currency = 'TRX';
                            $withdraw->delay = 0;
                            $withdraw->final_amo = $amountSend;
                            $withdraw->status = 1;
                            $withdraw->email_code = verification_code(6);
                            $withdraw->trx = $tnxnum;
                            $withdraw->save();

                            $trx = new Trx();
                            $trx->user_id = $user->id;
                            $trx->amount = $wdamo;
                            $trx->charge = formatter_money($charge);
                            $trx->main_amo = formatter_money($amountSend);
                            $trx->balance = formatter_money($pa['balance']);
                            $trx->charge_con = formatter_money($charge_con);
                            $trx->main_amo_con = formatter_money($amountSend_con);
                            $trx->amount_con = $wdamo_con;
                            $trx->type = 'withdraw';
                            $trx->trx = $tnxnum;
                            $trx->hash =  $hash;
                            $trx->moneda = 2;
                            $trx->title = 'withdraw Via Smart Contract TRX';
                            $trx->save();
                
                      $general = GeneralSetting::first();
                        send_tele($user, 'WITHDRAW_TRON_APPROVE', [
                            'trx' => $hash,
                            'amount' =>  formatter_money($trx->amount_con)."  ".$withdraw->currency." (".formatter_money($withdraw->amount)."  ETH)",
                            'receive_amount' =>  formatter_money($withdraw->amount_con - $withdraw->charge_con)."  ".$withdraw->currency." (".formatter_money($withdraw->amount_con - $withdraw->charge_con)." ETH)",
                            'charge' =>  formatter_money($withdraw->charge_con)." ".$withdraw->currency." (".formatter_money($withdraw->charge). " ETH)",
                            'method' => $withdraw->method->name,
                        ]);

                        send_sms($user, 'WITHDRAW_TRON_APPROVE', [
                            'trx' => $hash,
                            'amount' => $general->cur_sym . formatter_money($withdraw->amount),
                            'receive_amount' => $general->cur_sym . formatter_money($withdraw->amount - $withdraw->charge),
                            'charge' => $general->cur_sym . formatter_money($withdraw->charge),
                            'method' => $withdraw->method->name,
                        ]);
                      
             
           }
        
      }

      function contar($obj){
        $i=0;
        foreach($obj as $value){
            $i++;
        }
        return $i;
    }
}