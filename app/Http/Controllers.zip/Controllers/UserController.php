<?php

namespace App\Http\Controllers;
use App\BvLog;
use App\Deposit;
use App\GeneralSetting;
use App\Lib\GoogleAuthenticator;
use App\MatrixPlan;
use App\MatrixSubscriber;
use App\Plan;
use App\Rules\FileTypeValidate;
use App\Trx;
use App\User;
use App\UserExtra;
use App\UserLogin;
use App\UserMatrix;
use App\Withdrawal;
use App\WithdrawMethod;
use App\Share;
use App\PoolInterest;
use App\pop;
use App\kyc;
use App\GatewayCurrency;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use  Auth;
use  Session;
use Illuminate\Support\Str;
use App\Lib\CoinPaymentHosted;
use App\DB;



class UserController extends Controller

{

    public function home()
    {
        $user = Auth::user();
        $data['page_title']        = "Dashboard";
        $data['total_deposit']     =    Deposit::whereUserId($user->id)->where('status', 1)->where('isact', 0)->sum('amount');
        $data['balance_reservado'] = round($user->balance_resrv,4);
        $data['total_withdraw']    = Withdrawal::whereUserId($user->id)->whereStatus(1)->sum('amount');
        $data['complete_withdraw'] = Withdrawal::whereUserId($user->id)->whereStatus(1)->count();
        $data['pending_withdraw']  = Withdrawal::whereUserId($user->id)->whereStatus(2)->count();
        $data['reject_withdraw']   = Withdrawal::whereUserId($user->id)->whereStatus(3)->count();
        $data['ref']               = User::where('ref_id', $user->id)->count();
        $data['pool_interest']     = Trx::whereUserId($user->id)->where('type', 'pool_interest')->where('moneda',1)->sum('amount');
        $data['ref_com']           = Trx::whereUserId($user->id)->where('type', 'referral_commision')->where('moneda',1)->sum('amount');
        $data['binary_com']        = Trx::whereUserId($user->id)->where('type', 'binary_comission')->where('moneda',1)->sum('amount');
        $data['gana_matrix']       = Trx::whereUserId($user->id)->where('type', 'matrix_commission')->where('moneda',1)->sum('amount');
        $data['residual_bonus']    = Trx::whereUserId($user->id)->where('type', 'residual_bonus')->where('moneda',1)->sum('amount');
        $data['pool_interest_tx']  = Trx::whereUserId($user->id)->where('type', 'pool_interest')->where('moneda',2)->sum('amount_con');
        $data['ref_com_tx']        = Trx::whereUserId($user->id)->where('type', 'referral_commision')->where('moneda',2)->sum('amount_con');
        $data['binary_com_tx']     = Trx::whereUserId($user->id)->where('type', 'binary_comission')->where('moneda',2)->sum('amount_con');
        $data['gana_matrix_tx']    = Trx::whereUserId($user->id)->where('type', 'matrix_commission')->where('moneda',2)->sum('amount_con');
        $data['residual_bonus_tx'] = Trx::whereUserId($user->id)->where('type', 'residual_bonus')->where('moneda',2)->sum('amount_con');
        $data['cont_comprado']     = @inversion_contract($user->id);
        $data['aspira_ganar']      = @limite_contract($user->id);
        $data['total_ganado']      = @avance_contract($user->id);
        $data['total_con_eth']     = Share::where('user_id',$user->id)->where('moneda',1)->sum('total_share');
        $data['total_con_trx']     = Share::where('user_id',$user->id)->where('moneda',2)->sum('total_share');
        $data['cont_comprado_trx'] = @inversion_contract_trx($user->id);
        $data['aspira_ganar_trx']  = @limite_contract_trx($user->id);
        $data['total_ganado_trx']  = @avance_contract_trx($user->id);
        $data['pop']               = @pop::first();

        if($data['total_ganado']>0){
            $data['porcentaje']    = @number_format(($data['total_ganado']*100)/ $data['aspira_ganar'],2);
        }else{
             $data['porcentaje']   = 0;
        }
        if($data['total_ganado_trx']>0){
            $data['porcentaje_trx'] = @number_format(($data['total_ganado_trx']*100)/ $data['aspira_ganar_trx'],2);
        }else{
            $data['porcentaje_trx'] = 0;
        }
        $data['earning_eth'] = number_format($data['ref_com']+$data['binary_com']+$data['residual_bonus']+$data['pool_interest']+$data['gana_matrix'],8,'.','')+0;
        $data['earning_trx'] = number_format($data['ref_com_tx']+$data['binary_com_tx']+$data['residual_bonus_tx']+$data['pool_interest_tx']+$data['gana_matrix_tx'],6,'.','')+0;
        
       /* $precio_dolar        =    dolar_eth();
        $precio_tron         =    dolar_tron();
        $us_eth              =    number_format($data['earning_eth'] * $precio_dolar,2,'.','');
        $us_trx              =    number_format($data['earning_trx'] * $precio_tron,2,'.',''); */
       // $data['earning_usd'] =    $us_eth + $us_trx;

         $data['earning_usd'] =    'Weiting blockhain';
        $data['logs']        =    Trx::where('user_id',$user->id)->orderBy('id','Desc')->take(10)->get();
        $data['pool_trx']    =    PoolInterest::where('moneda',2)->take(10)->latest()->get();
        $data['pool_eth']    =    PoolInterest::where('moneda',1)->take(10)->latest()->get();
        
        return view(activeTemplate() . 'user.dashboard', $data);
    }

    public function profile_edit(){

        $user = Auth::user();

        @$kyc = kyc::where('user_id',$user->id)->latest()->first();

        if($kyc == null){
            $notify[] = ['success', 'You must complete the kyc in order to edit your profile']; 
            return redirect()->route('user.kyc')->withNotify($notify);
        }


        $page_title = 'Profile';
        $us = User::where("id",$user->ref_id)->first();
        $sponsor =@$us->username;

        
         try{ $data = array('id'=>$user->id);   $result = $this->send_smart('/eth/wallet', $data);
                $wallet_smart = @$result->result;
          }catch(exception $ex){ $wallet_smart = "";  }

        $status = 1;

       if($wallet_smart == "" or $wallet_smart == '0x0000000000000000000000000000000000000000'){
            $status = 0;
            $wallet_smart = "";
        }
        try{
                $data = array('id'=>$user->id);
                $result = $this->send_smart('/tron/wallet', $data);
                $wallet_tron = @$result->result;

              

        }catch(exception $ex){ 
            $wallet_tron = "";
         }

         if($wallet_tron == "" or $wallet_tron == 'T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb'){
            $status_tron = 0;
            $wallet_tron = "";
         }

           $status_tron = 1;
           $set = WithdrawMethod::Where('id',1)->first();
           $minimo_retiro = $set->min_limit;

        $set = WithdrawMethod::Where('id',2)->first();

        $minimo_retiro_trx = $set->min_limit;

        return view(activeTemplate() . 'user.editprofile', compact('page_title',
            'sponsor','wallet_smart','status','minimo_retiro', 'minimo_retiro_trx', 'wallet_tron'));

    }


    public function profile_pos($valor){

        if($valor == 1 || $valor == 2)
        {
            $user = auth()->user();
            $user->config_posi = $valor;
            $user->save();
            $notify[] = ['success', 'Your side binary update']; 
            return back()->withNotify($notify);
        }
        $notify[] = ['error', 'Your side binary no update']; 
        return back()->withNotify($notify);
    }


    public function wallets_retiro(){
        $user = auth()->user();
        $wallet_smart = ver_wallet($user->id);
        if($wallet_smart == ""){ $status = 0; $wallet_smart = "No Asigna"; }
        $wallet_tron = wallet_tron($user->id);
        if($wallet_tron == ""){ $status_tron = 0; $wallet_tron = "No Asigna"; }
        $data['w_eth']  = $wallet_smart;
        $data['w_trx'] = $wallet_tron;
        echo json_encode($data); 
    }

    public function new_account(Request $request){
        //proceso de registrar aqui y validacciones.
       
            $request->validate([
                'username' => 'required|max:30',
                'lado' => 'required|max:160',
                'pass' => 'required|max:160',
                'reply'=> 'required|min:6|max:20'
            ]);
           if($request->reply != $request->pass)
           {
            $notify[] = ['error', 'The password does not matche']; 
            return back()->withNotify($notify);
           }
           $user_vali =  User::where('username',$request->username)->count();
           if($user_vali > 0){
                $notify[] = ['error', 'User already exists']; 
                return back()->withNotify($notify);
           }

           if($user->kyc != 1){
                    $notify[] = ['error', 'You must complete the kyc to perform this process']; 
                    return back()->withNotify($notify);
           }

           $user = auth()->user(); 
           $total_cuenta = user::where('asociada',$user->id)->count();
           if($total_cuenta < 2){
                        if($total_cuenta == 0)
                        $precio = 25; else $precio = 50;

                        $precio = number_format($precio / dolar_tron(),6,'.','');
                  
                           if($precio > $user->balance_trx){
                                $notify[] = ['error', 'Insufficient balance']; 
                                return back()->withNotify($notify);
                           }
                        
                           //crear el nuevo correo
                        
                           $pos = getPosition($user->id, $request->lado);
                           $pos_id = $pos['pos_id'];

                           $mail = $user->email;
                           $div = explode('@', $mail);

                           $comi = explode("+",$div[0]);
                           $email_new = $comi[0].'+9'.(int)$precio."@".$div[1];

                        User::create([
                            'ref_id' => $user->id,
                            'pos_id' => $pos_id,
                            'position' => $request->lado,
                            'firstname' => $user->firstname,
                            'lastname' => $user->lastname,
                            'email' => $email_new,
                            'password' => Hash::make($request->pass),
                            'username' => str_replace(' ','',$request->username),
                            'etherium_wallet_code' => '',
                            'account_type' => 1,
                            'active_status'=>1,
                            'address' => [
                                'address' => '',
                                'state' => '',
                                'zip' => '',
                                'country' => '',
                                'city' => '',
                            ],
                            'status' => 1,
                            'ev' => 1,
                            'sv' => 1,
                            'ts' => 0,
                            'tv' => 1,
                            'kyc' => 1,
                            'asociada' => $user->id,
                            'token_tele' => 0,
                            'condicion' => 1
                        ]);
                        
                        $user_new = User::where('username', $request->username)->first();
                        $user_extras = new UserExtra();
                        $user_extras->user_id = $user_new->id;
                        $user_extras->save();
                      
                        $user->balance_trx -= $precio;
                        $user->save();

                        $trx = new TRX();
                        $trx->user_id = $user->id;
                        $trx->trx = getTrx();
                        $trx->amount_con = $precio;
                        $trx->main_amo_con = $precio;
                        $trx->type = 'asocia_cuenta';
                        $trx->balance = $user->balance_trx;
                        $trx->title = 'Associated account '.$request->username;
                        $trx->moneda = 2;
                        $trx->save();

                        $notify[] = ['success', 'New Associated account']; 
                            return back()->withNotify($notify);

           }else{
           $notify[] = ['error', 'You cannot associate more accounts']; 
           return back()->withNotify($notify);
           }

    }

     

    public function asocia(){
        $user = Auth::user();
        $page_title = 'Associated account';
        $cuentas =  user::where('asociada',$user->id)->get();
        $total_cuenta = user::where('asociada',$user->id)->count();

        $data['total_cuenta'] = $total_cuenta;
        $data['page_title']   = $page_title;
        $data['cuentas']      = $cuentas;

        if($total_cuenta == 0)
         $precio = 25;
         else {
            $precio = 50;
         }
         $data['precio'] = $precio;

        return view(activeTemplate() . 'user.asocia', $data);
    }

    public function kyc()
    {
        
        return redirect()->route('user.wallets.index');

        $user = Auth::user();
        $data['page_title'] = 'Forms Kyc';

        if($user->chat_id=='0'){
            $notify[] = ['success', 'First you must associate your account to the telegram bot']; 
           return redirect()->route('user.profile')->withNotify($notify);
        }

        @$kyc = kyc::where('user_id',$user->id)->latest()->first();

        $data['kyc_status'] = 'Pending';
        $data['status'] = '';
        if(@$kyc != null)
        { 
           if(@$kyc->status == 0 or @$kyc->status ==1)
                $data['status'] = 'disabled';
               else{ 
              $data['status'] = '';
            }
           switch(@$kyc->status){
               case 0:  $res  = 'Sent';     break;
               case 1:  $res  = 'Approved'; break;
               case 2:  $res  = 'Rejected'; break;
           }
           $data['kyc_status'] = $res;
        }
        if($user->kyc == 1){   
               $data['status'] = 'disabled';
               $data['kyc_status'] = 'Approved';
        }

         return view(activeTemplate() . 'user.kyc', $data);
    }
    

    public function profile()
    {
        $user = Auth::user();
        $page_title = 'Profile';
        $us = User::where("id",$user->ref_id)->first();
        if($user->ref_id == 2 or $user->ref_id == 1)
        $sponsor = 'Mastercode';
        else
        $sponsor =@$us->username;

        $set = WithdrawMethod::Where('id',1)->first();
        $minimo_retiro = $set->min_limit;
        $set = WithdrawMethod::Where('id',2)->first();
        $minimo_retiro_trx = $set->min_limit;
        $status = 1; $status_tron = 1;

        $status = 0;
        $wallet_smart = "Waiting for blockchaim ..... "; 
        $status_tron  = 0; 
        $wallet_tron  = "Waiting for blockchaim ..... ";

        if($user->token_tele == '' or $user->token_tele == "0")
        {
            //genera el token
            $valor = rand('1000000','9999999');
            $token = $user->id.$valor;
            $user->token_tele = $token;
            $user->save();
        }

        return view(activeTemplate() . 'user.profile', compact('page_title',

                    'sponsor','wallet_smart','status','minimo_retiro', 'minimo_retiro_trx', 'wallet_tron'));

    }


    public function wallet(){
        $user = Auth::user();
        try{ 
              $data = array('id'=>$user->id);   $result = $this->send_smart('/eth/wallet', $data); $wallet_smart = @$result->result;
           }catch(exception $ex){ $wallet_smart = "";  }
  
        if($wallet_smart == "" or $wallet_smart == '0x0000000000000000000000000000000000000000'){  $wallet_smart = "";  }

         try{
                    $data = array('id'=>$user->id);  $result = $this->send_smart('/tron/wallet', $data);  $wallet_tron = @$result->result;
         }catch(exception $ex){ 

                $wallet_tron = "";
        }
        $data['page_title'] = "Wallets";
        $data['wallet_smart'] = $wallet_smart;
        $data['wallet_tron']  = $wallet_tron;
        return view(activeTemplate().'user.change_wallet', $data);
    }
    
    public function wallet_change(Request $request){

        $user = auth()->user();

        try{ 
            $data = array('id'=>$user->id);   $result = $this->send_smart('/eth/wallet', $data); $wallet_smart = @$result->result;
         }catch(exception $ex){ $wallet_smart = "";  }

      if($wallet_smart == "" or $wallet_smart == '0x0000000000000000000000000000000000000000'){  $wallet_smart = "";  }

       try{
                  $data = array('id'=>$user->id);  
                  $result = $this->send_smart('/tron/wallet', $data);  
                  $wallet_tron = @$result->result;
       }catch(exception $ex){
             $wallet_tron = "";
       } 

      $paso = 0;
        $new_eth = $request->wallet_eth;
        $new_tron = $request->wallet_tron;
          
        
        if($request->wallet_eth != "")
        {
                if($new_eth != $wallet_smart)
                { 
                    $paso = 1;

                            if(0.015 > $user->balance ){
                                $notify[] = ['error', 'insufficient balance eth'];
                                return back()->withNotify($notify);
                            }
                      
                        try{
                                    $data = array('id'=>trim($user->id),
                                                'dire'=>trim($new_eth),
                                                'name'=>trim($user->username)
                                                );
                                    $result = $this->send_smart('/eth/update', $data);
                                        $wallet_smart = @$result->result;
                                        
                                        if($wallet_smart == 'ok')
                                        {
                                            $user->balance -= 0.015;
                                            $user->smart = 1;
                                            $user->save();
                                            $trx = new TRX();
                                            $trx->user_id = $user_id;
                                            $trx->trx = getTrx();
                                            $trx->amount = 0.015;
                                            $trx->type = 'change'; 
                                            $trx->main_amo = 0.015;
                                            $trx->balance = $user->balance;
                                            $trx->title = 'Wallet ETH  Change '.$new_eth;
                                            $trx->moneda = 1;
                                            $trx->save();
                                        }

                                    $notify[] = ['success', 'Your ETH wallet has been exchanged!'];
                            }catch(exception $ex){
                                $notify[] = ['error', 'Ethereum wallet invalid!'];
                            }  
                }
        }

    
        if($request->wallet_tron != "")
        {
                            if($new_tron != $wallet_tron)
                            {
                                $paso = 1;
                                    if(25 > $user->balance_trx ){
                                        $notify[] = ['error', 'insufficient balance Tron'];
                                        return back()->withNotify($notify);
                                    }
                               
                                    try{
                                            $data = array('id'=>trim($user->id),
                                                        'dire'=>trim($new_tron),
                                                        'name'=>trim($user->username)
                                                        );
                                               $result = $this->send_smart('/tron/update', $data);
                                            $wallet_smart = @$result->result;
                                            
                                            if($wallet_smart == 'ok')
                                            {
                                                   $user->balance_trx -= 25;
                                                   $user->wallet_tron = $new_tron;
                                                   $user->save();
                                                    $trx = new TRX();
                                                    $trx->user_id = $user->id;
                                                    $trx->trx = getTrx();
                                                    $trx->amount_con = 25;
                                                    $trx->type = 'change'; 
                                                    $trx->main_amo_con = 25;
                                                    $trx->balance = $user->balance_trx;
                                                    $trx->title = 'Wallet TRX  Change '.$new_tron;
                                                    $trx->moneda = 2;
                                                    $trx->save();
                                            }

                                            $notify[] = ['success', 'Your Tron wallet has been changed!'];

                                    }catch(exception $ex){
                                        $notify[] = ['error', 'Tron wallet invalid!'];
                                    }  
                            }
        }
        
        if($paso == 1)
        {
          return back()->withNotify($notify);
        }else
        {
            $notify[] = ['error', 'No changes were identified in their wallets'];
            return back()->withNotify($notify);
        }

    }
    
    public function cupon(){
                $user = auth()->user();
                $characters = 'ABCDEFGHJKMNOPQRSTUVWXYZ1234567890';
                $charactersLength = strlen($characters);
                if($user->sen_cupon == 0)
                {
                        $randomString = '';
                        for ($i = 0; $i < 6; $i++) {
                            $randomString .= $characters[rand(0, $charactersLength - 1)];
                        }

                        $codigo = $randomString;
                        $user->sen_cupon = 1;
                        $user->codigo_cupon = $codigo;
                        $user->fecha_cupon = date('Y-m-d');
                        $user->save();

                        send_tele(auth()->user(), 'coupon_code', [
                            'code' => $codigo.", este cupón es valido para una sola compra. Asegurese de comprar la cantidad de contratos Vip que desee",
                        ]);

                        $notify[] = ['success', 'Your coupon has been sent!'];
                        return back()->withNotify($notify);
                        
                }else{
                     $notify[] = ['error', 'Your coupon has expired!'];
                     return back()->withNotify($notify);
                }
    }
   


    public function kyc_update(Request $request){
        ini_set('memory_limit', '128M');
          
        $mi_kyc = kyc::where('user_id',auth()->user()->id )->where('status','<>',2)->first(); 
        if(@$mi_kyc != null)
        {
            $notify[] = ['error', 'you have a pending kyc form!'];
            return back()->withNotify($notify);
        }
       
        $request->validate([
            'firstname' => 'required|max:160',
            'lastname' => 'required|max:160',
            'phone'  =>   'required|max:15',
            'id_personal'  =>   'required|max:20',
            'address' => 'required|max:160',
            'city' => 'required|max:160',
            'state' => 'required|max:160',
            'zip' => 'required|max:160',
            'country' => 'required|max:160',
          /*  'imagen_id' => ['required', 'image', new FileTypeValidate(['jpeg', 'jpg', 'png'])],
            'imagen_address' => ['required', 'image', new FileTypeValidate(['jpeg', 'jpg', 'png'])],
            'image_legal' => ['required', 'image', new FileTypeValidate(['jpeg', 'jpg', 'png'])], */
        ]);
         
        if($request->parentesco == 0){
            $notify[] = ['error', 'Select the address of the place'];
            return back()->withNotify($notify);
        }
         
        $mainreq = $request;  
        auth()->user()->update([
            'identity' => $mainreq->id_personal,
            'firstname' => $mainreq->firstname,
            'lastname' =>  $mainreq->lastname,
            'mobile'       => $mainreq->phone,
            'address' => [
                'address' => $mainreq->address,
                'city' => $mainreq->city,
                'state' => $mainreq->state,
                'zip' => $mainreq->zip,
                'country' => $mainreq->country,
            ],
        ]);

        //crea la orden de kyc    
         
        $user = auth()->user();

        if ($mainreq->hasFile('imagen_id')) {
            try {
                   $imagen = $request->imagen_id;
                $filename_personal = rand(1000, 9999) . time() . '.' . $imagen->getClientOriginalExtension();
                $imagen->move('assets/images/user/kyc', $filename_personal);
            }
            catch (\Exception $exp){
                $notify[] = ['success', 'Image personal id could not be uploaded'];
                return back()->withNotify($notify);
            }
        }
    
        if ($request->hasFile('imagen_address')) {
            try {
                $imagen = $request->imagen_address;
                $filename_address = rand(1000, 9999) . time() . '.' . $imagen->getClientOriginalExtension();
                $imagen->move('assets/images/user/kyc', $filename_address);
            }
            catch (\Exception $exp){
                $notify[] = ['success', 'Image address could not be uploaded'];
                 return back()->withNotify($notify);
            }
        }
        
        if ($request->hasFile('image_legal')) {
            try {
                $imagen = $request->image_legal;
                $filename_selfi = rand(1000, 9999) . time() . '.' . $imagen->getClientOriginalExtension();
                $imagen->move('assets/images/user/kyc', $filename_selfi);
            }
            catch (\Exception $exp){
                $notify[] = ['success', 'Image selfi could not be uploaded'];
                return back()->withNotify($notify);
            }
        }

        if ($request->hasFile('imagen_r_id')) {
            try {
                $imagen = $request->imagen_r_id;
                $filename_imagen_re = rand(1000, 9999) . time() . '.' . $imagen->getClientOriginalExtension();
                $imagen->move('assets/images/user/kyc', $filename_imagen_re);
            }
            catch (\Exception $exp){
                $notify[] = ['success', 'Image selfi could not be uploaded'];
                return back()->withNotify($notify);
            }
        }

        $kyc =new kyc();
        $kyc->user_id = $user->id;
        $kyc->identity = $filename_personal;
        $kyc->direccion = $filename_address;
        $kyc->firma = $filename_selfi;
        $kyc->reverso = $filename_imagen_re;
        $kyc->pro_address = $request->parentesco;
        $kyc->save();

        $notify[] = ['success', 'Kyc has been received.'];
        return back()->withNotify($notify);
    }

    public function profileUpdate(Request $request)
    {

        if (!$request->oldreq) {

            $request->validate([
                'id_personal' => 'required',
                'phone'=> 'required',
                'firstname' => 'required|max:160',
                'lastname' => 'required|max:160',
                'address' => 'nullable|max:160',
                'city' => 'nullable|max:160',
                'state' => 'nullable|max:160',
                'zip' => 'nullable|max:160',
                'country' => 'nullable|max:160',
                'image' => ['nullable', 'image', new FileTypeValidate(['jpeg', 'jpg', 'png'])],
            ]);


            $filename = auth()->user()->image;

            if ($request->hasFile('image')) {

                try {
                    $path = config('constants.user.profile.path');
                    $size = config('constants.user.profile.size');
                    $filename = upload_image($request->image, $path, $size, $filename);
                }

                catch (\Exception $exp){

                    $notify[] = ['success', 'Image could not be uploaded'];

                    return back()->withNotify($notify);

                }

            }



            $oldreq = $request->except('_token', '_method');

            $oldreq['filename'] = $filename;

            $oldreq = json_encode($oldreq);



            if (auth()->user()->ts) {

                $tfa['type'] = 'google';

            } else {

                $tfa['type'] = 'email';
                $code = verification_code(6);
                $sig = hash_hmac('sha256', $code, auth()->user()->email);
                $tfa['hash'] = $sig;
                send_email(auth()->user(), 'profile_2fa', [
                    'code' => $code,
                ]);
                send_tele(auth()->user(), 'profile_2fa', [
                    'code' => $code,
                ]);

            }

            $page_title = '2 Factor Authentication';

            return view(activeTemplate() . 'user.profile-2fa', compact('page_title', 'tfa', 'oldreq'));

        } else {

            $request->validate([

                'code' => 'required',

            ]);


            if (auth()->user()->ts) {

                $ga = new GoogleAuthenticator();

                $oneCode = $ga->getCode(auth()->user()->tsc);

                $userCode = $request->code;

                if ($oneCode != $userCode) {

                    $notify[] = ['error', '2FA NOT MATCHED!!!'];

                   return redirect()->route('user.profile')->withNotify($notify);

                }

            } else {

                $sig = hash_hmac('sha256', $request->code, auth()->user()->email);

                if ($request->hash != $sig) {

                    $notify[] = ['error', 'OTP NOT MATCHED!!!'];

                   // return redirect()->route('user.profile')->withNotify($notify);

                }

            }



            $user = auth()->user();

            $mainreq = json_decode($request->oldreq);



            if(@$mainreq->wallet_tron != "")

            {

                        $data = array('id'=>$user->id);

                        $result = $this->send_smart('/tron/wallet', $data);

                        $tron_smart = @$result->hex;

                        if($tron_smart == "410000000000000000000000000000000000000000")

                        {

                                        try{

                                                $data = array('id'=>trim($user->id),
                                                            'dire'=>trim($mainreq->wallet_tron),
                                                            'name'=>trim($user->username)
                                                            );

                                                $result = $this->send_smart('/tron/register', $data);
                                                $wallet_smart = @$result->result;


                                                if($wallet_smart == 1){
                                                    $notify[] = ['error', 'Tron wallet invalid!'];
                                                    return redirect()->route('user.profile')->withNotify($notify);
                                                }else{
                                                    $trx = new TRX();
                                                    $trx->user_id = $user->id;
                                                    $trx->trx = getTrx();
                                                    $trx->amount = 0;
                                                    $trx->type = 'wallet';
                                                    $trx->main_amo = 0;
                                                    $trx->balance = $user->balance_trx;
                                                    $trx->title = 'Wallet TRX  Change '.$mainreq->wallet_tron;
                                                    $trx->moneda = 2;
                                                    $trx->save();
                                    
                                                }    

                                                auth()->user()->update([

                                                    'wallet_tron' => $mainreq->wallet_tron

                                                ]);    

                                        }catch(exception $ex){

                                            $notify[] = ['error', 'Tron wallet invalid!'];

                                            return redirect()->route('user.profile')->withNotify($notify);

                                        }  

                        } 

            }

             

            $tron = $this->valida_wallet_eth($user->id);

            auth()->user()->update([

                'firstname' => $mainreq->firstname,
                'identity' => $mainreq->id_personal,
                'mobile'     => $mainreq->phone,     

                'lastname' => $mainreq->lastname,

                'image' => $mainreq->filename,

                'address' => [

                    'address' => $mainreq->address,

                    'city' => $mainreq->city,

                    'state' => $mainreq->state,

                    'zip' => $mainreq->zip,

                    'country' => $mainreq->country,

                ],

                'forma_p' => $mainreq->forma_pago,

                'smart' => $tron,

            ]);

            

            // change password
              if($request->old_password != "" )
              {
                    $request->validate([
                        'password' => 'required|confirmed|max:160|min:6'
                    ]);
                    

                    if($request->password_confirmation !=  $request->password)
                     {
                        $notify[] = ['error', 'Your old password doesnt match'];
                        return back()->withNotify($notify);
                     }

            
                    if (!Hash::check($request->old_password, auth()->user()->password)) {
            
                        $notify[] = ['error', 'Your old password doesnt match'];
            
                        return back()->withNotify($notify);
            
                    }
            
                    auth()->user()->update([
            
                        'password' => bcrypt($request->password)
                         
                    ]);

                    $notify[] = ['success', 'Your profile has been updated'];
              }
           

            $notify[] = ['success', 'Your password has been updated'];

            return back()->withNotify($notify);

        }

    }





    public function passwordChange()

    {

        $page_title = 'Password Change';

        return view(activeTemplate() . 'user.password', compact('page_title'));

    }



    public function passwordUpdate(Request $request)

    {

        $request->validate([

            'old_password' => 'required',

            'password' => 'required|confirmed|max:160|min:6'

        ]);



        if (!Hash::check($request->old_password, auth()->user()->password)) {

            $notify[] = ['error', 'Your old password doesnt match'];

            return back()->withNotify($notify);

        }

        auth()->user()->update([

            'password' => bcrypt($request->password)

        ]);

        $notify[] = ['success', 'Your password has been updated'];

        return back()->withNotify($notify);

    }



    public function show2faForm()

    {

        $gnl = GeneralSetting::first();

        $ga = new GoogleAuthenticator();

        $user = auth()->user();

        $secret = $ga->createSecret();

        $qrCodeUrl = $ga->getQRCodeGoogleUrl($user->username . '@' . $gnl->sitename, $secret);

        $prevcode = $user->tsc;

        $prevqr = $ga->getQRCodeGoogleUrl($user->username . '@' . $gnl->sitename, $prevcode);

        $page_title = 'Google 2FA Auth';



        return view(activeTemplate() . 'user.go2fa', compact('page_title', 'secret', 'qrCodeUrl', 'prevcode', 'prevqr'));

    }



    public function create2fa(Request $request)

    {

        $user = auth()->user();

        $this->validate($request, [

            'key' => 'required',

            'code' => 'required',

        ]);



        $ga = new GoogleAuthenticator();

        $secret = $request->key;

        $oneCode = $ga->getCode($secret);



        if ($oneCode === $request->code) {

            $user->tsc = $request->key;

            $user->ts = 1;

            $user->tv = 1;

            $user->save();

            send_tele($user, '2FA_ENABLE', [
                'code' => $user->ver_code
            ]);

            send_sms($user, '2FA_ENABLE', [
                'code' => $user->ver_code
            ]);



            $notify[] = ['success', 'Google Authenticator Enabled Successfully'];

            return back()->withNotify($notify);

        } else {

            $notify[] = ['danger', 'Wrong Verification Code'];

            return back()->withNotify($notify);

        }

    }





    public function disable2fa(Request $request)

    {

        $this->validate($request, [

            'code' => 'required',

        ]);



        $user = auth()->user();

        $ga = new GoogleAuthenticator();



        $secret = $user->tsc;

        $oneCode = $ga->getCode($secret);

        $userCode = $request->code;



        if ($oneCode == $userCode) {

            $user->tsc = null;

            $user->ts = 0;

            $user->tv = 1;

            $user->save();

            send_email($user, '2FA_DISABLE');

            send_sms($user, '2FA_DISABLE');

            $notify[] = ['success', 'Two Factor Authenticator Disable Successfully'];

            return back()->withNotify($notify);

        } else {

            $notify[] = ['error', 'Wrong Verification Code'];

            return back()->with($notify);

        }

    }



    public function depositHistory()

    {

        $page_title = 'Deposit History';

        $empty_message = 'No history found.';

        $logs = auth()->user()->deposits()->where('status', '!=', 0)->where('isact', 0)->with(['gateway'])->latest()->paginate(config('constants.table.default'));

        return view(activeTemplate() . 'payment.deposit_history', compact('page_title', 'empty_message', 'logs'));

    }



    public function withdrawHistory()
    {

        $page_title = 'Withdraw History';

        $empty_message = 'No history found.';

        $logs = Trx::where('user_id',auth()->user()->id)->where('type','withdraw')->paginate(15);

        return view(activeTemplate() . 'user.withdraw_history', compact('page_title', 'empty_message', 'logs'));

    }



    public function withdraw()

    {

        $page_title = 'Withdraw';

        $method = WithdrawMethod::first();

        return view(activeTemplate() . 'user.withdraw', compact('page_title', 'method'));

    }



    public function withdrawInsert(Request $request)

    {

        $request->validate([

            'amount' => 'required|numeric',

        ]);

        $withdraw = WithdrawMethod::first();



        if ($request->amount < $withdraw->min_limit || $request->amount > $withdraw->max_limit) {

            $notify[] = ['error', 'Please follow the limit'];

            return back()->withNotify($notify);

        }

        if ($request->amount > auth()->user()->balance) {

            $notify[] = ['error', 'You do not have sufficient balance'];

            return back()->withNotify($notify);

        }

        $charge = $withdraw->fixed_charge + (($request->amount * $withdraw->percent_charge) / 100);

        $withoutCharge = $request->amount - $charge;

        $final_amo = $withoutCharge;



        $data = new Withdrawal();

        $data->method_id = $withdraw->id;

        $data->user_id = auth()->id();

        $data->amount = formatter_money($request->amount);

        $data->charge = formatter_money($charge);

        $data->rate = 1;

        $data->currency = 'ETH';

        $data->delay = 0;

        $data->final_amo = $final_amo;

        $data->status = 0;

        $data->email_code = verification_code(6);

        $data->trx = getTrx();

        $data->save();

        Session::put('Track', $data->trx);



        $general = GeneralSetting::first();



        // send_email(auth()->user(), 'WITHDRAW_VERIFY', [

        //     'amount' => $general->cur_sym . ' ' . formatter_money($data->amount),

        //     'method' => $data->method->name,

        //     'code' => $data->email_code,

        //     'charge' => $general->cur_sym . ' ' . $withdraw->charge,

        // ]);



        return redirect()->route('user.withdraw.preview');



    }



    public function withdrawPreview()

    {

        $track = Session::get('Track');

        $data = Withdrawal::where('user_id', auth()->id())->where('trx', $track)->where('status', 0)->first();

        if (!$data) {

            return redirect()->route('user.withdraw');

        }

        $page_title = "Withdraw Preview";



        return view(activeTemplate() . 'user.withdraw_preview', compact('data', 'page_title'));

    }



    public function withdrawStore(Request $request)
    {
        $track = Session::get('Track');
        $withdraw = Withdrawal::where('user_id', auth()->id())->where('trx', $track)->orderBy('id', 'DESC')->first();

        if ($withdraw->status != 0) {
            $notify[] = ['error', 'Enough :) . Please....'];
            return redirect()->route('user.withdraw')->withNotify($notify);
        }

        $ga = new GoogleAuthenticator();
        $oneCode = $ga->getCode(auth()->user()->tsc);
        $userCode = $request->code;
        if ($oneCode != $userCode) {
            $notify[] = ['error', '2FA NOT MATCHED!!!'];
            return redirect()->route('user.withdraw')->withNotify($notify);
        }
        // if ($withdraw->email_code != $request->code)

        // {

        //     $notify[] = ['error', 'Invalid email authorize code.'];

        //     return redirect()->route('user.withdraw')->withNotify($notify);

        // }
        $withdraw_method = WithdrawMethod::first();
        $balance = auth()->user()->balance - $withdraw->amount;

        auth()->user()->update([
            'balance' => formatter_money($balance),
        ]);

        $withdraw->status = 2;
        $withdraw->save();

        $trx = new Trx();
        $trx->user_id = auth()->id();
        $trx->amount = $withdraw->amount;
        $trx->charge = formatter_money($withdraw->charge);
        $trx->main_amo = formatter_money($withdraw->final_amo);
        $trx->balance = formatter_money(auth()->user()->balance);
        $trx->type = 'withdraw';
        $trx->trx = $withdraw->trx;
        $trx->title = 'withdraw Via ' . $withdraw->method->name;
        $trx->save();

////////////////////////AUTOMATED

        if ($withdraw_method->status) {

            $cps = new CoinPaymentHosted();
            $cps->Setup($withdraw_method->val2, $withdraw_method->val1);
            $result = $cps->CreateWithdrawal($withdraw->final_amo, 'ETH', auth()->user()->etherium_wallet_code, '1');

            if ($result['error'] == 'ok') {

                $withdraw->status = 1;
                $withdraw->save();
                $general = GeneralSetting::first();


                send_email(auth()->user(), 'WITHDRAW_APPROVE', [
                    'trx' => $withdraw->trx,
                    'amount' => $general->cur_sym . formatter_money($withdraw->amount),
                    'receive_amount' => $general->cur_sym . formatter_money($withdraw->amount - $withdraw->charge),
                    'charge' => $general->cur_sym . formatter_money($withdraw->charge),
                    'method' => $withdraw->method->name,
                ]);


                send_sms(auth()->user(), 'WITHDRAW_APPROVE', [
                    'trx' => $withdraw->trx,
                    'amount' => $general->cur_sym . formatter_money($withdraw->amount),
                    'receive_amount' => $general->cur_sym . formatter_money($withdraw->amount - $withdraw->charge),
                    'charge' => $general->cur_sym . formatter_money($withdraw->charge),
                    'method' => $withdraw->method->name,
                ]);
                $notify[] = ['success', 'Withdraw Completed Successfully!'];
                return redirect()->route('user.home')->withNotify($notify);
            }
        }



////////////////////////AUTOMATED
        $general = GeneralSetting::first();

        send_email(auth()->user(), 'WITHDRAW_PENDING', [
            'trx' => $withdraw->trx,
            'amount' => $general->cur_sym . ' ' . formatter_money($withdraw->amount),
            'method' => $withdraw->method->name,
            'charge' => $general->cur_sym . ' ' . $withdraw->charge,
        ]);

        send_sms(auth()->user(), 'WITHDRAW_PENDING', [
            'trx' => $withdraw->trx,
            'amount' => $general->cur_sym . ' ' . formatter_money($withdraw->amount),
            'method' => $withdraw->method->name,
            'charge' => $general->cur_sym . ' ' . $withdraw->charge,

        ]);
        $notify[] = ['success', 'You withdraw request has been taken.'];

        return redirect()->route('user.home')->withNotify($notify);

    }
    


    public function point_binary()
    {
        $page_title = 'Binary Points';
        $logs = BvLog::where('user_id',auth()->user()->id)->orderBy('id', 'DESC')->paginate(15);
        $empty_message = 'No transaction history';
        return view(activeTemplate() . 'user.puntos', compact('page_title', 'logs', 'empty_message'));
    }


    public function transactions()
    {
        $page_title = 'Transactions';
        $logs = auth()->user()->transactions()->orderBy('id', 'DESC')->paginate(config('constants.table.default'));
        $empty_message = 'No transaction history';
        return view(activeTemplate() . 'user.transactions', compact('page_title', 'logs', 'empty_message'));
    }





    function loginHistory()
    {
        $data['page_title'] = "Login History";
        $data['history'] = UserLogin::where('user_id', Auth::id())->latest()->paginate(15);
        return view(activeTemplate() . '.user.login_history', $data);
    }



    function indexTransfer()
    {
        $page_title = 'Balance Transfer';
        $user = auth()->user();
        $balance = $user->balance;
        $ganancia = $user->interest_wallet;
        return view(activeTemplate() . '.user.balance_transfer', compact('page_title','balance','ganancia'));

    }



      function transfer_balance()

    {

        $page_title = 'Balance Transfer';

        $user = auth()->user();

        $balance = $user->balance;

        $ganancia = $user->interest_wallet;

        

        $notify[] = ['success', 'Balance Transferred Successfully.'];

      return back()->withNotify($notify);

       // return view(activeTemplate() . '.user.balance_transfer', compact('page_title','balance','ganancia'));

    }



      function transfer_ganancia()

    {

        $page_title = 'Balance Transfer';

        

        $user = auth()->user();

        $balance = $user->balance;

        $ganancia = $user->interest_wallet;



        return view(activeTemplate() . '.user.balance_transfer', compact('page_title','balance','ganancia'));

    }

    



    function bala_Transfer(Request $request){

         $this->validate($request, [

            'amount_balance' => 'required|numeric|min:0',

        ]);

         

          $user = auth()->user();        

             

          if($request->amount_balance <= $user->balance )

          { 

           $gnl = GeneralSetting::first();

            

            $amount = $request->amount_balance;

            $new_balance = $user->balance  - $amount;

            $new_interes = $user->interest_wallet + $amount;

        

            $user->interest_wallet = $new_interes;

            $user->balance = $new_balance;

            $user->save();



            $trx = getTrx();



            Trx::create([

                'trx' => $trx,

                'user_id' => $user->id,

                'type' => 'balance_transfer',

                'title' => 'balance Transferred To wallet Interest',

                'amount' => $request->amount,

                'main_amo' => $user->interest_wallet,

                'balance' => $user->interest_wallet

            ]);

        

           $notify[] = ['success', 'Balance Transferred Successfully.'];

            return back()->withNotify($notify);

        } else {

            $notify[] = ['error', 'Insufficient Balance.'];

            return back()->withNotify($notify);



        }

    }



    function interestTransfer(Request $request){

         $this->validate($request, [

            'amount' => 'required|numeric|min:0',

        ]);

         

          $user = auth()->user();

         

    

          if($request->amount <= $user->interest_wallet )

          { 

              

           

           $gnl = GeneralSetting::first();

          

           $amount = $request->amount;



           $new_interes = $user->interest_wallet - $amount;

           $charge = $gnl->bal_trans_fixed_charge + ($amount * $gnl->bal_trans_per_charge) / 100;

           $total_enviar = $amount - $charge;

           $new_balance = $user->balance  + $total_enviar;

           $user->interest_wallet = $new_interes;

           $user->balance = $new_balance;

           $user->save();



           $trx = getTrx();



           Trx::create([

                'trx' => $trx,

                'user_id' => $user->id,

                'type' => 'interest_transfer',

                'title' => 'Interest Transferred To wallet Depósito',

                'amount' => $request->amount,

                'main_amo' => $total_enviar,

                'balance' => $user->balance,

                'charge' => $charge

           ]);

        

           $notify[] = ['success', 'Balance Transferred Successfully.'];

            return back()->withNotify($notify);

        } else {

            $notify[] = ['error', 'Insufficient Balance.'];

            return back()->withNotify($notify);

        }

    }








    function balanceTransfer(Request $request)

    {

        $this->validate($request, [

            'username' => 'required',

            'amount_send' => 'required|numeric|min:0',

        ]);



        $gnl = GeneralSetting::first();

        $user = User::find(auth()->id());

        $trans_user = User::where('username', $request->username)->orwhere('email', $request->username)->first();

        if ($trans_user == '') {

            $notify[] = ['error', 'Username Not Found'];

            return back()->withNotify($notify);

        }

         $charge = 0;

        if ($trans_user->username == $user->username) {



            $notify[] = ['error', 'Balance Transfer Not Possible In Your Own Account'];

            return back()->withNotify($notify);

        }




        $amount = $request->amount_send;

        

        if ($user->balance >= $amount) {

            $new_balance = $user->balance - $amount;

            $user->balance = $new_balance;

            $user->save();



            $trx = getTrx();

            Trx::create([
                'trx' => $trx,
                'user_id' => $user->id,
                'type' => 'balance_transfer',
                'title' => 'Balance Transferred To ' . $trans_user->username,
                'amount' => $request->amount,
                'main_amo' => $amount,
                'balance' => $user->balance,
                'charge' => $charge

            ]);



            send_tele($user, 'BAL_SEND', [
                'amount' => formatter_money($request->amount_send) . '' . $gnl->cur_text,
                'name' => $trans_user->username,
                'charge' => formatter_money($charge) . ' ' . $gnl->cur_text,
                'balance_now' => formatter_money($new_balance) . ' ' . $gnl->cur_text,

            ]);



            send_sms($user, 'BAL_SEND', [

                'amount' => formatter_money($request->amount_send) . '' . $gnl->cur_text,

                'name' => $trans_user->username,

                'charge' => formatter_money($charge) . ' ' . $gnl->cur_text,

                'balance_now' => formatter_money($new_balance) . ' ' . $gnl->cur_text,

            ]);





            $trans_new_bal = $trans_user->balance + $request->amount_send;

            $trans_user->balance = $trans_new_bal;

            $trans_user->save();



            Trx::create([

                'trx' => $trx,

                'user_id' => $trans_user->id,

                'type' => 'balance_transfer',

                'title' => 'Balance receive From ' . $user->username,

                'amount' => $request->amount_send,

                'main_amo' => $request->amount_send,

                'balance' => $trans_new_bal,

                'charge' => 0

            ]);





            send_email($trans_user, 'bal_receive', [



                'amount' => formatter_money($request->amount_send) . '' . $gnl->cur_text,

                'name' => $user->username,

                'charge' => 0 . ' ' . $gnl->cur_text,

                'balance_now' => formatter_money($trans_new_bal) . ' ' . $gnl->cur_text,



            ]);



            send_sms($trans_user, 'bal_receive', [

                'amount' => formatter_money($request->amount_send) . '' . $gnl->cur_text,

                'name' => $user->username,

                'charge' => 0 . ' ' . $gnl->cur_text,

                'balance_now' => formatter_money($trans_new_bal) . ' ' . $gnl->cur_text,

            ]);



            $notify[] = ['success', 'Balance Transferred Successfully.'];

            return back()->withNotify($notify);

        } else {

            $notify[] = ['error', 'Insufficient Balance.'];

            return back()->withNotify($notify);



        }

    }





    function searchUser(Request $request)

    {

        $trans_user = User::where('id', '!=', Auth::id())->where('username', $request->username)

            ->orwhere('email', $request->username)->count();

        if ($trans_user == 1) {

            return response()->json(['success' => true, 'message' => 'Correct User']);

        } else {

            return response()->json(['success' => false, 'message' => 'User Not Found']);

        }



    }





      public function earnings()

    {

        $page_title = 'Earnings';

        $logs = auth()->user()->transactions()->where('type', ['referral_commision', 'binary_comission', 'residual_bonus', 'pool_interest'])->orderBy('id', 'DESC')->paginate(config('constants.table.default'));

        $empty_message = 'No transaction history';

        return view(activeTemplate() . 'user.transactions', compact('page_title', 'logs', 'empty_message'));

    }




    public function referralCom()

    {

        $data['page_title'] = "Referral Commission Log";

        $data['logs'] = Trx::where('user_id', auth()->id())->where('type', 'referral_commision')->latest()->paginate(config('constants.table.default'));

        $data['empty_message'] = 'No data found';

        return view(activeTemplate() . '.user.referralCom', $data);

    }



    public function binaryCom()

    {

        $data['page_title'] = "Binary Commission Log";

        $data['logs'] = Trx::where('user_id', auth()->id())->where('type', 'binary_comission')->latest()->paginate(config('constants.table.default'));

        $data['empty_message'] = 'No data found';

        return view(activeTemplate() . '.user.binaryCom', $data);

    }



    public function residualCom()

    {

        $data['page_title'] = "Residual Commission Log";

        $data['logs'] = Trx::where('user_id', auth()->id())->where('type', 'residual_bonus')->latest()->paginate(config('constants.table.default'));

        $data['empty_message'] = 'No data found';

        return view(activeTemplate() . '.user.binaryCom', $data);

    }



    public function interestLog()

    {

        $data['page_title'] = "Interest Log";

        $data['logs'] = Trx::where('user_id', auth()->id())->where('type', 'balance_transfer')->latest()->paginate(config('constants.table.default'));

        $data['empty_message'] = 'No data found';

        return view(activeTemplate() . '.user.transactions', $data);

    }



    public function transferLog()

    {

        $data['page_title'] = "Pool Interest";

        $data['logs'] = Trx::where('user_id', auth()->id())->where('moneda',1)->where('type', 'pool_interest')->latest()->paginate(config('constants.table.default'));

        $data['empty_message'] = 'No data found';

        return view(activeTemplate() . '.user.transactions', $data);

    }

    

    

    public function transferLog_trx()
    {
        $data['page_title'] = "Pool Interest";
        $data['logs'] = Trx::where('user_id', auth()->id())->where('moneda',2)->where('type', 'pool_interest')->latest()->paginate(config('constants.table.default'));
        $data['empty_message'] = 'No data found';
        return view(activeTemplate() . '.user.transactions', $data);
    }





    public function matrixLog()
    {
        $data['page_title'] = "Matrix Commission";
        $data['logs'] = Trx::where('user_id', auth()->id())->where('type', 'matrix_commission')->latest()->paginate(config('constants.table.default'));
        $data['empty_message'] = 'No data found';
        return view(activeTemplate() . '.user.transactions', $data);

    }



    public function binarySummery()
    {
        $data['page_title'] = "Binary Summery";
        $data['logs'] = UserExtra::where('user_id', auth()->id())->first();
        return view(activeTemplate() . '.user.binary_summery', $data);
    }



    public function bvlog()
    {
        $data['page_title'] = "BV LOG";
        $data['logs'] = BvLog::where('user_id', auth()->id())->orderBy('id', 'desc')->paginate(config('constants.table.default'));
        $data['empty_message'] = 'No data found';
        return view(activeTemplate() . '.user.bv_log', $data);
    }


    public function myRefLog()
    {
        set_time_limit(0);
        $user = auth()->user();
        $data['page_title'] = "My Referrals";
        $data['empty_message'] = 'No data found';

        //$data['refers'] =  \DB::table('users')->where('ref_id', $user->id)->paginate(15);
        $data['refers'] = User::where('ref_id', $user->id)->latest()->paginate(10);
        return view(activeTemplate() . 'user.my_ref', $data);
    }



    public function myTree()
    {
        $data['tree'] = showTreePage(Auth::id());
        $ref = User::where('id', auth()->user()->ref_id)->first('username');
        $data['ref_by'] = ucfirst($ref->username);
        $data['page_title'] = "My Tree";
        return view(activeTemplate() . 'user.my_tree', $data);
    }

    public function otherTree(Request $request, $username = null)
    {
        if ($request->username) {
            $user = User::where('username', $request->username)->first();
        } else {
            $user = User::where('username', $username)->first();
        }
        if($user == null)
        {
            $notify[] = ['error', 'User Invalid!!'];
            return redirect()->route('user.my.tree')->withNotify($notify);
        }   
        if(treeAuth($user->id, auth()->id())){
            $data['tree'] = showTreePage($user->id);
            $data['page_title'] = "Tree of " . $user->fullname;
            $ref = User::where('id', $user->ref_id)->first('username');
            $data['ref_by'] = ucfirst($ref->username);
            return view(activeTemplate() . 'user.my_tree', $data);
        }
        $notify[] = ['error', 'Tree Not Found or You do not have Permission to view that!!'];
        return redirect()->route('user.my.tree')->withNotify($notify);
    }


    public function exchange(){
        $data['page_title'] = 'Exchange';
        return view(activeTemplate() . 'user.exchange', $data);
    }


    public function accountActive()
    {
        $gnl = GeneralSetting::first(['active_charge', 'investor_active_charge']);

        if (auth()->user()->account_type == 1) {

            $charge = $gnl->active_charge;

        } else {

            $charge = $gnl->investor_active_charge;

        }

        $charge_in_eth = eth_rate2() * $charge;



        if ($charge_in_eth > auth()->user()->balance) {

            $gate = GatewayCurrency::where('method_code', 506)->where('currency', 'ETH')->first();

            if (!$gate) {

                $notify[] = ['error', 'Invalid Gateway'];

                return back()->withNotify($notify);

            }



            $charge = formatter_money($gate->fixed_charge + ($charge_in_eth * $gate->percent_charge / 100));

            $withCharge = $charge_in_eth + $charge;

            $final_amo = formatter_money($withCharge * $gate->rate);



            $depo['user_id'] = Auth::id();

            $depo['method_code'] = $gate->method_code;

            $depo['method_currency'] = strtoupper($gate->currency);

            $depo['amount'] = formatter_money($charge_in_eth);

            $depo['charge'] = $charge;

            $depo['rate'] = $gate->rate;

            $depo['final_amo'] = $final_amo;

            $depo['btc_amo'] = 0;

            $depo['btc_wallet'] = "";

            $depo['trx'] = getTrx();

            $depo['try'] = 0;

            $depo['status'] = 0;

            $depo['isact'] = 1;

            $track = Deposit::create($depo);



            Session::put('Track', $track->trx);

            return redirect()->route('user.deposit.confirm');



        }



        if (auth()->user()->active_status == 0) {

            $user = auth()->user();

            $user->balance -= $charge_in_eth;

            $user->active_status = 1;

            $user->save();



            send_email($user, 'account_active', [



                'active_time' => show_datetime($user->updated_at),

            ]);

            send_sms($user, 'account_active', [

                'active_time' => show_datetime($user->updated_at),

            ]);





            $notify[] = ['success', 'Account activated successfully '];

            return back()->withNotify($notify);

        }



        $notify[] = ['error', 'Invalid Request'];

        return redirect()->route('user.deposit')->withNotify($notify);





    }



    public function accountActiveBTC()

    {

        $gnl = GeneralSetting::first(['active_charge', 'investor_active_charge']);

        if (auth()->user()->account_type == 1) {

            $amount = $gnl->active_charge;

        } else {

            $amount = $gnl->investor_active_charge;

        }

        $ethAmo = eth_rate2() * $amount;







        $gate = GatewayCurrency::where('method_code', 506)->where('currency', 'ETH')->first();



        $depo['user_id'] = Auth::id();

        $depo['method_code'] = $gate->method_code;

        $depo['method_currency'] = 'BTC';

        $depo['amount'] = formatter_money($ethAmo);

        $depo['charge'] = 0;

        $depo['rate'] = $gate->rate;

        $depo['final_amo'] = $ethAmo;

        $depo['btc_amo'] = 0;

        $depo['btc_wallet'] = "";

        $depo['trx'] = getTrx();

        $depo['try'] = 0;

        $depo['status'] = 0;

        $depo['isact'] = 1;

        $track = Deposit::create($depo);

        Session::put('Track', $track->trx);

        return redirect()->route('user.deposit.confirm');

    }


   public function accelerationMatrix_fill($pl = "", $ma= ""){

           if($ma==0) {
              $user_new = auth()->user();
           }else{
              $dat_m =  MatrixSubscriber::where('id',$ma)->first();
              $user_new = User::where('id',$dat_m->user_id)->first();
              $pl  = $dat_m->matrix_plan_id;
           }
           $data = matriz_tree($user_new, $pl, $ma);
           $data['matrix_pendiente'] = @$this->matrix_pendiente($user_new->id);
           return view(activeTemplate() . 'user.user_matrix', $data);
   }


    public function accelerationMatrix()
    {
        $id_plan = 1;
        $id_matrix = "";
        $user = auth()->user();
        $data = matriz_tree($user, $id_plan);
        $data['matrix_pendiente'] = @$this->matrix_pendiente($user->id);
        return view(activeTemplate() . 'user.user_matrix', $data);
    }



    public function data_pocisiones($valores){
        for($i=0;$i<=6; $i++) {
             $poci[] = array('id_user'=>'',
                              'id_matrix'=>'',
                              'imagen'=>'',
                              'username'=>'',
                              'sponsor'=>''
                              );
            }


        if( $valores != null)
                {
                        foreach($valores as $valor){
                            $usua = User::where('id',$valor->user_id)->first();
                            $spon = User::where('id',$usua->ref_id)->first();
                            $poci[$valor->position]['id_user'] =  $valor->user_id;
                            $poci[$valor->position]['id_matrix'] = $valor->viene;
                            $poci[$valor->position]['imagen']   =  $this->imagen_ma($valor->user_id);
                            $poci[$valor->position]['username'] =   $usua->username;
                            $poci[$valor->position]['sponsor']  =  $spon->username;
                        }
                }
                return $poci;

    }





    public function imagen_ma($user){
        $data = User::where("id",$user)->first();
        $imagen = $data->image;
        if($imagen == "") $imagen = "../../assets/images/default.png";
        else              $imagen = "../../assets/images/user/profile/".$imagen;
        return $imagen;
    }







    public function accelerationMatrixPost(Request $request, $id)
    {

        $user = auth()->user();
        $data = MatrixPlan::where('id', $id)->where('status', 1)->first();
        if ($data == null)
        {
            $notify[] = ['error', 'Invalid Request'];
            return back()->withNotify($notify);
        }
        
        $total_balance = $user->balance_trx; 
        
        if ($total_balance < $data->price)
        {
            $notify[] = ['error', 'Your do not have Sufficient Balance.'];
            return back()->withNotify($notify);
        }

        $ma = MatrixSubscriber::where('user_id',$user->id)->where('matrix_plan_id', $data->id)->where('status',1)->first();
        if($ma != null)
        {
            $notify[] = ['error', 'You Already Subscribed.'];
             return  back()->withNotify($notify);
        }


        if($data->condicion > 0)
        {
                $ma = MatrixSubscriber::where('user_id',$user->id)->where('matrix_plan_id', $data->condicion)->where('status',1)->first();
                if($ma==null)
                {
                    $fail = MatrixPlan::where('id', $data->condicion)->where('status', 1)->first();
                    $notify[] = ['error', 'You must subscribe to the '.$fail->name.' in order to purchase this.'];
                    return back()->withNotify($notify);
                }
        }

        $refer = $this->buscar_activo($user->id, $data->id);
        $id_ref    = $refer['id_ref'];
        $id_matrix = $refer['id_matrix'];
        if($refer['res'] == "ok")   $id_ref = 0;

        $user->balance_trx -= $data->price;
        $user->save();

        $matrix = new MatrixSubscriber();
        $matrix->user_id = $user->id;
        $matrix->matrix_plan_id = $data->id;
        $matrix->amount = $data->price;
        $matrix->viene  = $id_ref;
        $matrix->total += 1;
        $matrix->status = 1;
        $matrix->save();
        
        $matriz_gen = 0;
        $matriz_gen = $matrix->id;
        $actual = $user->balance_trx;

        $this->trx_compra($user, $data, $actual);

                if($refer['res'] == "ok")    $this->ubica_pocision($user,$id_matrix, $data, $matriz_gen);
                $notify[] = ['success', 'Invest Successfully.'];
        return back()->withNotify($notify);
    }


    public function accelerationMatrixUpdate(Request $request, $id)
    {
        $data = MatrixPlan::where('id', $id)->where('status', 1)->first();
        if ($data == null)
        {
            $notify[] = ['error', 'Invalid Request'];
            return back()->withNotify($notify);
        }

        $user = auth()->user();
        if (!userMatrixCheckStatus($user->id))
        {
             $notify[] = ['error', 'You Already Subscribed.'];
             return back()->withNotify($notify);
        }

        $getMatrix = getMatrixPosition($data->id);
        $matrix = MatrixSubscriber::where('user_id', $user->id)->first();
        $matrix->total += 1;
        $matrix->status = 1;
        $matrix->save();

        $matrix = new UserMatrix();
        $matrix->user_id = $user->id;
        $matrix->pos_id = $getMatrix['pos_id'];
        $matrix->position = $getMatrix['position'];
        $matrix->matrix_plan_id = $data->id;
        $matrix->save();

        $details = $user->username . ' Re-Subscribe Acceleration Matrix ' . $data->name;
        $notify[] = ['success', 'Invest Successfully.'];
        return back()->withNotify($notify);

    }



    function buscar_activo($id_user, $paquete = ""){

          $data['res'] = "error";
          $data['id_ref'] = "0";
          $data['id_matrix'] = "";
          $users = User::find($id_user);
          $id_buscar = $users->ref_id;

        for($i= 0; $i< 30; $i++)
        {
            if($id_buscar == 0 or $id_buscar == "")  return $data;
            $mat = MatrixSubscriber::where('user_id',$id_buscar)->where('matrix_plan_id', $paquete)->where('status',1)->first();
            if($mat != null)
                {
                    $data['res']       = 'ok';
                    $data['id_ref']    = $id_buscar;
                    $data['id_matrix'] = $mat->id;
                    return $data;
                }

            $users = User::find($id_buscar);
            $id_buscar = $users->ref_id;
        }
        return $data;
    }



    function ubica_pocision($user, $id_matriz, $data, $viene){
         $total_posi = UserMatrix::where('id_matrix', $id_matriz)->count();
         if($total_posi < 6)
         {
            $lista_dis = $this->pos_disponibles($id_matriz);
            $pocision = $lista_dis[0];
            $pos_id = $this->nivel($pocision);
            $matrix = new UserMatrix();
            $matrix->user_id = $user->id;
            $matrix->pos_id = $pos_id;
            $matrix->position = $pocision;
            $matrix->matrix_plan_id = $data->id;
            $matrix->id_matrix = $id_matriz;
            $matrix->viene = $viene;
            $matrix->save();

            $this->comision_matrix($user, $data, $pos_id, $id_matriz);
            if($pos_id  == 1)
             {
                     $resu =  $this->matriz_superior($id_matriz);
                     if($resu['res'] == 'ok')
                     {
                        $poci_f="";
                        $otro_ma = $resu['id_matrix'];
                        $poci    = $resu['poci'];
                        if($poci == 2) $poci_f = 5;
                        if($poci == 1) $poci_f = 3;
                        $this->generando_otra_poci($user, $otro_ma, $data, $viene, $poci_f);
                     }

             }
            else {
                    $resu = $this->matriz_primaria($id_matriz,$data->id, $pocision);
                    if($resu['res'] == 'ok'){
                    $otro_ma = $resu['id_matrix'];
                    $this->generando_otra_poci($user, $otro_ma, $data, $viene);
                  }

            }


            if($total_posi >= 5)
            {
                $con = MatrixSubscriber::find($id_matriz);
                $con->status = 2;
                $con->save();
                 $id_user = $con->user_id;
                 $user = User::find($id_user);
                 $this->ciclar_matrix($user,$data);
            }

         }

         return "error";

    }





    function generando_otra_poci($user, $id_matriz, $data, $viene, $poci = ''){
        $total_posi = UserMatrix::where('id_matrix', $id_matriz)->count();
        if($total_posi < 6)
        {
            if($poci == "")  $lista_dis = $this->pos_disponibles($id_matriz);
            else             $lista_dis = $this->pos_disponibles_2($id_matriz, $poci);

           $pocision = $lista_dis[0];
           $pos_id = $this->nivel($pocision);
           $matrix = new UserMatrix();
           $matrix->user_id = $user->id;
           $matrix->pos_id = $pos_id;
           $matrix->position = $pocision;
           $matrix->matrix_plan_id = $data->id;
           $matrix->id_matrix = $id_matriz;
           $matrix->viene = $viene;
           $matrix->save();
           $this->comision_matrix($user, $data, $pos_id, $id_matriz);

           if($total_posi >= 5)
           {
               $con = MatrixSubscriber::find($id_matriz);
               $con->status = 2;
               $con->save();
               $id_user = $con->user_id;
               $user = User::find($id_user);
               $this->ciclar_matrix($user,$data);

           }



        }

    }



    function matrix_pocision($pocision_generada){
        switch($pocision_generada){
            case 3 : $res = 1; break;
            case 4 : $res = 1; break;
            case 5 : $res = 2; break;
            case 6 : $res = 2; break;
            default : $res = "";
        }

        return $res;

    }



    function matriz_primaria($id_matrix, $paquete, $pocision){
            $find_poci = $this->matrix_pocision($pocision);
            $data['res']       = 'error';
            $data['id_matrix'] = '';
            $mat = UserMatrix::where('id_matrix',$id_matrix)->where('position', $find_poci)->first();
            if($mat != null)
            {
                $data['res'] = 'ok';
                $data['id_matrix'] = $mat->viene;
            }
            return $data;
    }



    function matriz_superior($id_matrix){
        $data['res']       = 'error';
        $data['id_matrix'] = '';
        $data['poci']      = '';
        $mat = UserMatrix::where('viene',$id_matrix)->orderBy('id_matrix', 'Desc')->first();

        if($mat != null)
        {
                $data['res']       = 'ok';
                $data['id_matrix'] = $mat->id_matrix;
                $data['poci']      = $mat->position;

        }
        return $data;

    }

    function localiza_matriz_primaria($id_matriz, $lider){
        $query = "select *from pocisiones where id_user = '".$lider."' and
                     matriz_viene = '".$id_matriz."' and nro_poicision > 6";
        $res = $this->con_direct($query);
        $id_matriz = $res[0]['id_matriz'];
        $this->principal_m = $id_matriz;
        return $id_matriz;
    }


    function nivel($poci){
        switch($poci){
              case 1: $res = 1; break;
              case 2: $res = 1; break;
              default: $res = 2;
        }
        return $res;

    }

    function buy_maytrix_resagada(Request $request){
            
        $viene = $request->viene;  
        $user = auth()->user();
        $new_data = MatrixPlan::where('id',$viene)->first();
        if($new_data == null) 
        {
            $notify[] = ['error', 'Invalid Request'];
            return back()->withNotify($notify);
        }
  
        $vali = MatrixSubscriber::where('user_id', $user->id)->where('matrix_plan_id', $viene)->count();
        if($vali == 0)
        {

            
                 if ($user->balance_resrv_trx < $new_data->price)  {  
                       $notify[] = ['error', 'Your do not have Sufficient Reserved Balance.'];
                       return back()->withNotify($notify);
                  }
                   
                    $refer = $this->buscar_activo($user->id, $new_data->id);
                    $id_ref    = $refer['id_ref'];
                    $id_matrix = $refer['id_matrix'];
                    if($refer['res'] == "ok")   $id_ref = 0;

                     $matrix = new MatrixSubscriber();
                     $matrix->user_id = $user->id;
                     $matrix->matrix_plan_id = $new_data->id;
                     $matrix->amount = $new_data->price;
                     $matrix->viene  = $id_ref;
                     $matrix->total += 1;
                     $matrix->status = 1;
                     $matrix->save();
                     $matriz_gen = $matrix->id;
                     $user->balance_resrv_trx -= $new_data->price;
                     $user->save();
                    if($refer['res'] == "ok")    $this->ubica_pocision($user,$id_matrix, $new_data, $matriz_gen);

                   $notify[] = ['success', 'Invest Successfully.'];
                   return back()->withNotify($notify);
        }else{
            $notify[] = ['error', 'You Already Subscribed.'];
            return back()->withNotify($notify);
        }
    }


    function ciclar_matrix($user, $data){
        $refer = $this->buscar_activo($user->id, $data->id);
        $id_ref    = $refer['id_ref'];
        $id_matrix = $refer['id_matrix'];
        if($refer['res'] == "ok")   $id_ref = 0;

        if ($user->balance_resrv_trx < $data->price)
        {
              return "";
        }
            $matrix = new MatrixSubscriber();
            $matrix->user_id = $user->id;
            $matrix->matrix_plan_id = $data->id;
            $matrix->amount = $data->price;
            $matrix->viene  = $id_ref;
            $matrix->total += 1;
            $matrix->status = 1;
            $matrix->save();

            $matriz_gen = $matrix->id;
            $user->balance_resrv_trx -= $data->price;
            $user->save();

        if($refer['res'] == "ok")    $this->ubica_pocision($user,$id_matrix, $data, $matriz_gen);

        // agregamos l aposibilidad de crear otra matriz de level superior
    
        $viene = $data->viene;
        $new_data = MatrixPlan::where('id',$viene)->first();
        if($new_data == null) return;
        // vemos si el usuario tiene la matrix
        $vali = MatrixSubscriber::where('user_id', $user->id)->where('matrix_plan_id', $viene)->count();
        if($vali == 0)
        {
                 if ($user->balance_resrv_trx < $new_data->price)  {  return "";  }
                    $refer = $this->buscar_activo($user->id, $new_data->id);
                    $id_ref    = $refer['id_ref'];
                    $id_matrix = $refer['id_matrix'];
                    if($refer['res'] == "ok")   $id_ref = 0;
                     $matrix = new MatrixSubscriber();
                     $matrix->user_id = $user->id;
                     $matrix->matrix_plan_id = $new_data->id;
                     $matrix->amount = $new_data->price;
                     $matrix->viene  = $id_ref;
                     $matrix->total += 1;
                     $matrix->status = 1;
                     $matrix->save();
                     $matriz_gen = $matrix->id;
                     $user->balance_resrv_trx -= $new_data->price;
                     $user->save();
                 if($refer['res'] == "ok")    $this->ubica_pocision($user,$id_matrix, $new_data, $matriz_gen);
        }
    }

    function  pos_disponibles_2($id_matrix, $poci){

        $lis_poci = $this->las_pocisiones($id_matrix);
        $i=0;
        foreach($lis_poci as  $key => $value)
        {
            if($value=="")
            {
               if($key >= $poci)
                $data[] = $key ;
            }
            $i++;
        }
        return $data;

    }

    function  pos_disponibles($id_matrix){
        $lis_poci = $this->las_pocisiones($id_matrix);
        $i=0;
        foreach($lis_poci as  $key => $value) {
            if($value=="") $data[] = $key ;
            $i++;
        }
        return $data;
    }

    function  las_pocisiones($id_matrix){
                $resu = UserMatrix::where('id_matrix', $id_matrix)->get();
                $data = array();
                        for($i=1; $i<=6;$i++){
                            $data[$i] = "";
                        }
                        if($resu != null)
                        {
                            foreach ($resu as $key => $value) {
                                $poci =  $value['position'];
                                $data[$poci] = 1;
                            }
                        }
            return $data;
     }

     function trx_compra($user,$data, $actual){

            $trxnum         = getTrx();
            $trx            = new Trx();
            $trx->user_id   = $user->id;
            $trx->amount_con    = $data->price;
            $trx->charge_con    = 0;
            $trx->main_amo_con  = formatter_money($data->price);
            $trx->balance   = formatter_money($user->balance_trx);
            $trx->type      = 'Buy_Matrix';
            $trx->moneda    = 2;
            $trx->trx       = $trxnum;
            $trx->title     = 'Buy '.$data->name;
            $trx->save();
        
     }
      
     public function matrix_pendiente($user){
                $user_id = $user;
                $plan_act = MatrixSubscriber::where('user_id',$user_id)->groupBy('matrix_plan_id')->get('matrix_plan_id');
                $plan_pendiente = null;
                foreach($plan_act as $data){
                    $id_plan =  $data->matrix_plan_id;
                    //verifica si la ultimamatrix esta cerrada o abierta
                    $valida  =  MatrixSubscriber::where('user_id', $user_id)->where('matrix_plan_id',$id_plan)->where('status',2)->latest('id')->first();
                    $new_plan = MatrixPlan::where('id', $id_plan)->first();
                    if($new_plan->viene > 0)
                        {
                            $plan_proximo = MatrixSubscriber::where('user_id',$user_id)->where('matrix_plan_id',$new_plan->viene)->count();
                            if($plan_proximo == 0)
                            {
                                if($valida->updated_at > '2021-01-14'){
                                    $plan_pendiente[$id_plan] = $new_plan->viene; 
                                }
                            }
                        }
                }
                return @$plan_pendiente;
     }
     

     function comision_matrix($user, $data, $id_pos, $matrix = ""){
         $details = $user->username . ' Re-Subscribe Acceleration Matrix ' . $data->name;
         $dat_matr = MatrixSubscriber::where('id',$matrix)->first();
         $user_r = User::where('id', $dat_matr->user_id)->first();
         comision_final($user_r, $data,$id_pos,$details);
        return;
     }



     function valida_wallet_eth($user){
              $smart = 1;
               $wallet_smart = "";
                try{
                    $data = array('id'=>$user);
                    $result = $this->send_smart('/eth/wallet', $data);
                    $wallet_smart = @$result->result;
                }catch(exception $ex){  }
                 if($wallet_smart == "" or $wallet_smart == '0x0000000000000000000000000000000000000000'){
                     $smart = 0;
                  }else{ $smart = 1; }
        return $smart;
     }

     function send_smart($sesion, $data){
        $arra = "";
                foreach ($data as $key => $value) {
                    if($arra != "") $arra .= "&";
                    $arra .= $key."=".$value;
                }

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,"http://labts.procashdream.com/test_smart".$sesion);
                curl_setopt($ch, CURLOPT_POST, TRUE);
                curl_setopt($ch, CURLOPT_POSTFIELDS,$arra);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $resul = curl_exec ($ch);
                curl_close ($ch);
                $resu = json_decode($resul);
                return $resu;
      }

   // reporte de pagos trx

    public function reportar(){
        $page_title = 'Report pending pay';
        $shares = Share::where('status',0)->where('act',0)->where('user_id',auth()->user()->id)->latest()->paginate(15);
        return view(activeTemplate() . 'user.reparar', compact('page_title', 'shares'));
    }


}

