<?php

namespace App\Http\Controllers;

use App\GeneralSetting;
use App\Trx;
use App\User;
use Carbon\Carbon;
use App\Deposit;
use App\Wallets;
use App\Withdrawal;
use App\Http\base58;
use App\WithdrawMethod;
use Illuminate\Http\Request;
use App\GatewayCurrency;
use Illuminate\Support\Facades\Auth;

class rpcController extends Controller
{
      protected  $url = 'http://rpcprocashdream.site';
      
      public function create_wallet($user_id, $username){

                $wall_user = wallets::where('user_id', $user_id)->count();

                if($wall_user == 0)
                {
                        $data = array('user_id'=> $user_id, 'username'=>$username);
                        $this->url = 'https://rpcprocashdream.site';
                        $wallet_eth = $this->apikey('/eth/crea_wallet',$data);
                         print_r($wallet_eth);
                        $this->url = 'https://rpcprocashdream2.com';
                        $wallet_trx = $this->apikey('/tron/crea_wallet',$data);
                       print_r($wallet_trx);
                        $wa = new Wallets();
                        $wa->user_id = $user_id;
                        $wa->wallet_eth = $wallet_eth->wall;
                        $wa->wallet_trx = $wallet_trx->wall;
                        $wa->save();
                      
                   }
      }

      public function wallets(){
            auth()->user()->id;
           $data = array('user_id'=> auth()->user()->id);
           $wallet = $this->apikey('/wallets',$data);
           print_r($wallet);
           return $wallet;
      }

      public function  uni_wallet($id){
                $data = User::where('status',1)->where('id',$id)->first();
                print_r(json_decode($data));
                "<br>";
                $this->create_wallet($data->id, $data->username);
                        echo '<hr>';
      }

      public function todos_wallets(){
          set_time_limit(0);
         $list_user = User::where('status',1)->get();
         foreach($list_user as $data){
                $this->create_wallet($data->id, $data->username);
                  echo '<hr>';
         }

      }

      public function insert_deposit($valores){   

         //    tran=6e095b7839a75704156e821208afdcb9376576190a2777822b87508283326194&from=wallet=TGekBP6VDBzvbRpb1Q2af2Spm9X9GyTCpo&amount=100&method_code=506&currency=TRX

                    $request =  [
                        'id_tx'       => $_GET['tran'],
                        'amount'      => $_GET['amount'],
                        'wallet'      => $_GET['wallet'],
                        'method_code' => $_GET['method_code'],
                        'currency'    => $_GET['currency'],
                        'from'        => $_GET['from']
                    ];
                    $request = json_decode(json_encode($request));
                  
                    switch($request->currency){
                        case 'ETH' : $campo = 'wallet_eth'; $moneda = 1; $campo_up  = 'balance'; break;
                        case 'TRX' : $campo = 'wallet_trx'; $moneda = 2;  $campo_up = 'balance_trx';  break;
                        default: return;
                    }

                    $valid = Deposit::where('id_tx',$request->id_tx)->count();

                    if($valid > 0){
                        echo "has ya existe";
                        return;
                    }

                    $wall = Wallets::where($campo, $request->wallet)->first();
                    if($wall == null){
                        $data['msj'] = 'Wallet no Exists!';
                        return $data;
                    }
                   
                    $gate = GatewayCurrency::where('method_code', $request->method_code)->where('currency', $request->currency)->first();                    
                    if (!$gate) {
                        $data['msj'] = 'Invalid Gateway';
                        return $data;
                    }
                
                    $user = User::where('id', $wall->user_id)->first();

                    $charge = formatter_money($gate->fixed_charge + ($request->amount * $gate->percent_charge / 100));
                    $withCharge = $request->amount + $charge;
                    $final_amo = formatter_money($withCharge * $gate->rate);

                    $depo = new Deposit();
                    $depo['user_id']            = $user->id;
                    $depo['method_code']        = $gate->method_code;
                    $depo['method_currency']    = strtoupper($gate->currency);
                    $depo['amount']             = formatter_money($request->amount);
                    $depo['charge']             = $charge;
                    $depo['rate']               = $gate->rate;
                    $depo['final_amo']          = $final_amo;
                    $depo['btc_amo']            = 0;
                    $depo['btc_wallet']         = "";
                    $depo['trx']                = getTrx();
                    $depo['id_tx']              = $request->id_tx;
                    $depo['try']                = 0;
                    $depo['status']             = 1;
                    $depo->save();
                    
                    $log['details']    = 'Deposit from '.$request->from;
                    $log['type']       = 'deposit';
                    $log['hash']       =  $request->id_tx;
                    $log['moneda']     =  $moneda;

                    switch($moneda)
                    {
                          case 1:
                                    $user->balance += $final_amo;
                                    $user->save();
                                    $log['amount']   =  $request->amount;
                                    $log['main_amo'] =  $final_amo;
                                    $log['charge']   =  $charge;
                                    $log['balance']  =  $user->balance;
                          break;
                          case 2:
                                    $user->balance_trx += $final_amo;
                                      $user->save();
                                    $log['amount_con']   =  $request->amount;
                                    $log['main_amo_con'] =  $final_amo;
                                    $log['charge_con']   =  $charge;
                                    $log['balance']      =  $user->balance_trx;
                          break;
                    }

                    $user->save();
                    transaction_log($log, $user);
                    $user->save();
                    send_email($user, 'DEPOSIT_APPROVE', [
                        'amount' => formatter_money($request->amount)." ".$request->currency,

                        'trx' => '<a href="https://tronscan.org/#/transaction/'.$request->id_tx.'">'.$request->id_tx.'</a>'
                    ]);

                    $data['res'] = 'ok';
                    echo json_decode($data);
                    
      }
      
      public function comple($moneda){
          switch($moneda)
          {
              case 1: $res = 'eth'; break;
              case 2: $res = 'tron'; break;
              default: $res = 'eth';
          }
          return $res;
      }

      public function validar(){
                    set_time_limit(0);
                    $lotes = Pago::where('status',1)->get();
                    foreach($lotes as $pag){
                        $this->valida_trans($pag);
                    }
      }

      public function valida_trans($pag){
                             $res['status'] = 'ok';
                             $url = "https://api.trongrid.io/v1/transactions/".$pag->id_tx."/events";
                             $res =   file_get_contents($url);
                             $res =json_decode($res);

                             $tota_send = Prew_withdraw::where('pago_id',$pag->id)->count();
                             $fecha_pago = $pag->updated_at;
                             $fechaActual = Carbon::now();
                             $diferencia = $fechaActual->diffInMinutes($fecha_pago);
                             $i = 0;
                               echo  count($res->data);
                            if(count($res->data) > 0)
                            {
                                   foreach($res->data as $data )
                                    {   
                                        $total = $this->contar($res->data[0]);
                                       if($total == 9)
                                        {
                                            $contr_user = $data->result->user;
                                            $contr_status = $res->success;
                                            $monto = $data->result->amount/1000000;
                                                        if( $contr_status == "1" )
                                                        {
                                                            $i++;
                                                        }
                                        }else{
                                            return;
                                        }
                                    }
                                   echo "<br>";
                                    echo $i." ".$tota_send;
                                   echo '<br>===========';
                                    if($tota_send  == $i )
                                    {
                                        $this->send_register($pag);
                                    }
                             }
                             else{
                                    if($diferencia > 7200){
                                        $pag->status = 2;
                                        $pag->save();
                                    }
                             }   
                    
                            return $res;
      }   


      public function send_register($pago){
          return 1;
      }

      function contar($obj){
        $i=0;
        foreach($obj as $value){  
        }
        return $i;
    }


    
    function apikey($sesion, $data){
                        $arra = "";
                        foreach ($data as $key => $value) {
                            if($arra != "") $arra .= "&";
                            $arra .= $key."=".$value;
                        }
                                   
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL,$this->url.$sesion);
                    curl_setopt($ch, CURLOPT_POST, TRUE);
                    curl_setopt($ch, CURLOPT_POSTFIELDS,$arra);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $resul = curl_exec ($ch);
                    curl_close ($ch);
                    $resu = json_decode($resul);
                    return $resu;
        }

      public  function transaction_log($data, $user){
          $data = json_decode(json_encode($data));
             $n = getTrx();
             $trx = new Trx();
             $trx->type         = $data->type;
             $trx->user_id      = $user->id;
             $trx->moneda       = $data->moneda;
             $trx->trx          = $n;
             $trx->hash         = $data->hash;
             $trx->amount       = $data->amount;
             $trx->main_amo     = $data->main_amo;
             $trx->charge       = $data->charge;
             $trx->balance      = $data->balance;
             $trx->amount_con   = $data->amount_con;
             $trx->main_amo_con = $data->main_amo_con;
             $trx->charge_con   = $data->charge_con;
             $trx->title        = $data->title;
             $trx->save();

             

      }


}